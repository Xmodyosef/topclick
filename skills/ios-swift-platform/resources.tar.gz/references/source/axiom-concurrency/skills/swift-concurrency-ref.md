
# Swift Concurrency API Reference

Complete Swift concurrency API reference for copy-paste patterns and syntax lookup.

Complements `skills/swift-concurrency.md` (which covers *when* and *why* to use concurrency — progressive journey, decision trees, @concurrent, isolated conformances).

**Related references**: `skills/swift-concurrency.md` (progressive journey, decision trees), `skills/synchronization.md` (Mutex, locks), `skills/assume-isolated.md` (assumeIsolated patterns)

## Part 1: Actor Patterns

### Actor Definition

```swift
actor ImageCache {
    private var cache: [URL: UIImage] = [:]

    func image(for url: URL) -> UIImage? {
        cache[url]
    }

    func store(_ image: UIImage, for url: URL) {
        cache[url] = image
    }
}

// Usage — must await across isolation boundary
let cache = ImageCache()
let image = await cache.image(for: url)
```

All properties and methods on an actor are isolated by default. Callers outside the actor's isolation domain must use `await` to access them.

### Actor Isolation Rules

Every actor's stored properties and methods are isolated to that actor. Access from outside the isolation boundary requires `await`, which suspends the caller until the actor can process the request.

```swift
actor Counter {
    var count = 0              // Isolated — external access requires await
    let name: String           // let constants are implicitly nonisolated

    init(name: String) {       // Actors get no memberwise init — declare one
        self.name = name
    }

    func increment() {         // Isolated — await required from outside
        count += 1
    }

    nonisolated func identity() -> String {
        name                   // OK: accessing nonisolated let
    }
}

let counter = Counter(name: "main")
await counter.increment()      // Must await across isolation boundary
let id = counter.identity()    // No await needed — nonisolated
```

### nonisolated Keyword

Opt out of isolation for synchronous access to non-mutable state.

```swift
actor MyActor {
    let id: UUID               // let constants are implicitly nonisolated

    nonisolated var description: String {
        "Actor \(id)"          // Can only access nonisolated state
    }

    nonisolated func hash(into hasher: inout Hasher) {
        hasher.combine(id)     // Only nonisolated properties
    }
}
```

`nonisolated` methods cannot access any isolated stored properties. Use this for protocol conformances (like `Hashable`, `CustomStringConvertible`) that require synchronous access.

### Actor Reentrancy

Suspension points (`await`) inside an actor allow other callers to interleave. State may change between any two `await` expressions.

```swift
actor BankAccount {
    var balance: Double = 0

    func transfer(amount: Double, to other: BankAccount) async {
        guard balance >= amount else { return }
        balance -= amount
        // REENTRANCY HAZARD: another caller could modify balance here
        // while we await the deposit on the other actor
        await other.deposit(amount)
    }

    func deposit(_ amount: Double) {
        balance += amount
    }
}
```

**Pattern**: Re-check state after every `await` inside an actor:

```swift
actor BankAccount {
    var balance: Double = 0

    func transfer(amount: Double, to other: BankAccount) async -> Bool {
        guard balance >= amount else { return false }
        balance -= amount

        await other.deposit(amount)

        // Re-check invariants after await if needed
        return true
    }
}
```

### Global Actors

A global actor provides a single shared isolation domain accessible from anywhere.

```swift
@globalActor
actor MyGlobalActor {
    static let shared = MyGlobalActor()
}

@MyGlobalActor
func doWork() { /* isolated to MyGlobalActor */ }

@MyGlobalActor
class MyService {
    var state: Int = 0         // Isolated to MyGlobalActor
}
```

### @MainActor

The built-in global actor for UI work. All UI updates must happen on `@MainActor`.

```swift
@MainActor
class ViewModel: ObservableObject {
    @Published var items: [Item] = []

    func loadItems() async {
        let data = await fetchFromNetwork()
        items = data           // Safe: already on MainActor
    }
}

// Annotate individual members
class MixedService {
    @MainActor var uiState: String = ""

    @MainActor
    func updateUI() {
        uiState = "Done"
    }

    func backgroundWork() async -> String {
        await heavyComputation()
    }
}
```

**Subclass inheritance**: If a class is `@MainActor`, all subclasses inherit that isolation.

### Actor Init

Actor initializers are NOT isolated to the actor. You cannot call isolated methods from init.

```swift
actor DataManager {
    var data: [String] = []

    init() {
        // Cannot call isolated methods here
        // self.loadDefaults()  // ERROR: actor-isolated method in non-isolated init
    }

    // Use a factory method instead
    static func create() async -> DataManager {
        let manager = DataManager()
        await manager.loadDefaults()
        return manager
    }

    func loadDefaults() {
        data = ["default"]
    }
}
```

### Actor Gotcha Table

| Gotcha | Symptom | Fix |
|---|---|---|
| Actor reentrancy | State changes between awaits | Re-check state after each await |
| nonisolated accessing isolated state | Compiler error | Remove nonisolated or make property nonisolated |
| Calling actor method from sync context | "Expression is 'async'" | Wrap in Task {} or make caller async |
| Global actor inheritance | Subclass inherits @MainActor | Be intentional about which methods need isolation |
| Actor init not isolated | Can't call isolated methods in init | Use factory method or populate after init |
| Actor protocol conformance | "Non-isolated" conformance error | Use nonisolated for protocol methods, or isolated conformance (Swift 6.2+) |
| Using actor for ViewModel | @Published won't work, UI updates require await | Use @MainActor class for UI-facing code, actor only for non-UI shared state |
| GCD queue-hopping inside actor | Breaks isolation guarantees, risks thread explosion | Remove GCD — actor isolation already serializes access |

### Custom Executors

Every actor runs on an **executor**. The default executor schedules the synchronous pieces of a task ("jobs") on the cooperative thread pool. `MainActor` has its own serial executor that runs jobs on the main thread. You rarely need to think about executors directly.

When you might implement a custom executor:
- You own a thread pool with specific tuning (a custom scheduler for a high-throughput service)
- You need to bridge an actor's work to a specific dispatch queue your team controls
- You're implementing an actor that must run on a particular thread (e.g., a graphics actor pinned to a specific GPU queue)

Conform to `SerialExecutor` and expose it from your actor via `unownedExecutor`:

```swift
final class CustomExecutor: SerialExecutor {
    private let queue: DispatchQueue

    init(queue: DispatchQueue) { self.queue = queue }

    func enqueue(_ job: UnownedJob) {
        queue.async {
            job.runSynchronously(on: self.asUnownedSerialExecutor())
        }
    }

    func asUnownedSerialExecutor() -> UnownedSerialExecutor {
        UnownedSerialExecutor(ordinary: self)
    }
}

actor PinnedWorker {
    private let executor: CustomExecutor

    init(queue: DispatchQueue) {
        self.executor = CustomExecutor(queue: queue)
    }

    nonisolated var unownedExecutor: UnownedSerialExecutor {
        executor.asUnownedSerialExecutor()
    }

    func doWork() { /* runs on `queue` */ }
}
```

**For most app code, never reach for custom executors.** They're a footgun — get one wrong and you'll see deadlocks, priority inversions, or unbounded thread growth. The default executor is well-tuned for general-purpose work.

---

## Part 2: Sendable Patterns

### Automatic Sendable Conformance

Value types are Sendable when all stored properties are Sendable.

```swift
// Structs: Sendable when all stored properties are Sendable
struct UserProfile: Sendable {
    let name: String
    let age: Int
}

// Enums: Sendable when all associated values are Sendable
enum LoadState: Sendable {
    case idle
    case loading
    case loaded(String)        // String is Sendable
}
```

### @Sendable Closures

Closures passed across isolation boundaries must be `@Sendable`. A `@Sendable` closure cannot capture mutable local state.

```swift
func runInBackground(_ work: @Sendable @escaping () -> Void) {
    Task.detached { work() }
}

// All captured values must be Sendable
var count = 0
runInBackground {
    // ERROR: capture of mutable local variable
    // count += 1
}

let snapshot = count
runInBackground {
    print(snapshot)            // OK: let binding of Sendable type
}
```

### @unchecked Sendable

Manual guarantee of thread safety. Use only when you provide synchronization yourself.

```swift
final class ThreadSafeCache: @unchecked Sendable {
    private let lock = NSLock()
    private var storage: [String: Any] = [:]

    func get(_ key: String) -> Any? {
        lock.lock()
        defer { lock.unlock() }
        return storage[key]
    }

    func set(_ key: String, value: Any) {
        lock.lock()
        defer { lock.unlock() }
        storage[key] = value
    }
}
```

#### Requirements for @unchecked Sendable
- Class must be `final`
- All mutable state must be protected by a synchronization primitive (lock, queue, Mutex)
- You are responsible for correctness — the compiler will not check

### Conditional Conformance

```swift
struct Box<T> {
    let value: T
}

// Box is Sendable only when T is Sendable
extension Box: Sendable where T: Sendable {}

// Standard library uses this extensively:
// Array<Element>: Sendable where Element: Sendable
// Dictionary<Key, Value>: Sendable where Key: Sendable, Value: Sendable
// Optional<Wrapped>: Sendable where Wrapped: Sendable
```

### sending Parameter Modifier (SE-0430)

Transfer ownership of a value across isolation boundaries. The caller gives up access.

```swift
func process(_ value: sending String) async {
    // Caller can no longer access value after this call
    await store(value)
}

// Useful for transferring non-Sendable types when caller won't use them again
func handOff(_ connection: sending NetworkConnection) async {
    await manager.accept(connection)
}
```

### Build Settings

Control the strictness of Sendable checking in Xcode:

| Setting | Value | Behavior |
|---|---|---|
| `SWIFT_STRICT_CONCURRENCY` | `minimal` | Only explicit Sendable annotations checked |
| `SWIFT_STRICT_CONCURRENCY` | `targeted` | Inferred Sendable + closure checking |
| `SWIFT_STRICT_CONCURRENCY` | `complete` | Full strict concurrency (Swift 6 default) |

### Pulling Sendable Pieces Out of a Non-Sendable Type

When you need data from a non-Sendable type (typically an `NSObject` subclass or legacy class) across isolation boundaries, you usually only need a few properties — not the whole object. Instead of trying to make the wrapper Sendable, **extract the Sendable pieces** at the source isolation and send only those.

```swift
// ❌ Trying to make the whole legacy type Sendable cascades through the codebase
final class LegacyImageRecord: NSObject {       // Inherits from NSObject; non-Sendable
    @objc dynamic var title: String
    @objc dynamic var url: URL
    @objc dynamic var thumbnailCache: NSCache<NSString, UIImage>   // Mutable shared state
}

actor ImageCatalog {
    func info(for id: String) -> LegacyImageRecord {  // ❌ Can't return non-Sendable across actor
        ...
    }
}

// ✅ Send only the Sendable pieces
struct ImageInfo: Sendable {
    let title: String
    let url: URL
}

actor ImageCatalog {
    private var records: [String: LegacyImageRecord] = [:]

    func info(for id: String) -> ImageInfo? {
        guard let record = records[id] else { return nil }
        return ImageInfo(title: record.title, url: record.url)   // Sendable snapshot
    }
}
```

This pattern lets you keep legacy non-Sendable types encapsulated within their isolation domain while still surfacing useful information to the rest of the program. Foundation uses this extensively during its own concurrency adoption — most consumers of Foundation types only need string/numeric/date pieces, not the whole reference object.

### Sendable Gotcha Table

| Gotcha | Symptom | Fix |
|---|---|---|
| Class can't be Sendable | "Class cannot conform to Sendable" | Make final + immutable, or @unchecked Sendable with locks |
| Closure captures non-Sendable | "Capture of non-Sendable type" | Copy value before capture, or make type Sendable |
| Protocol can't require Sendable | Generic constraints complex | Use `where T: Sendable` |
| @unchecked Sendable hides bugs | Data races at runtime | Only use when lock/queue guarantees safety |
| Array/Dictionary conditional | Collection is Sendable only if Element is | Ensure element types are Sendable |

---

## Part 3: Task Management

### Task { }

Creates an unstructured task that inherits the current actor context and priority.

```swift
// Inherits actor context — if called from @MainActor, runs on MainActor
let task = Task {
    try await fetchData()
}

// Get the result
let result = try await task.value

// Get Result<Success, Failure>
let outcome = await task.result
```

### Task.detached { }

Creates a task with no inherited context. Does not inherit the actor or priority.

```swift
Task.detached(priority: .background) {
    // NOT on MainActor even if created from MainActor
    await processLargeFile()
}
```

**When to use**: Background work that must NOT run on the calling actor. Prefer `Task {}` in most cases — `Task.detached` is rarely needed.

### Task Cancellation

Cancellation is cooperative. Setting cancellation is a request; the task must check and respond.

```swift
let task = Task {
    for item in largeCollection {
        // Option 1: Check boolean
        if Task.isCancelled { break }

        // Option 2: Throw CancellationError
        try Task.checkCancellation()

        await process(item)
    }
}

// Request cancellation
task.cancel()
```

#### withTaskCancellationShield (OS27)

Swift 6.4 adds `withTaskCancellationShield` to run a region to completion even when the surrounding task is cancelled — the shielded operation does not observe cancellation. Use it sparingly, for work that must finish atomically once started (a commit, a handshake); over-use defeats cooperative cancellation.

```swift
@available(anyAppleOS 27, *)
func commit() async throws {
    try await withTaskCancellationShield {
        try await database.write(pending)   // not interrupted mid-write by cancellation
    }
}
```

There is also a **synchronous overload**, `withTaskCancellationShield { }` with a non-`async`
operation, for shielding a blocking region. It behaves identically.

**The shield MASKS cancellation — it does not merely stop throws.** Measured on macOS 27 inside a
cancelled task:

| Query, inside the shield | Result |
|---|---|
| `Task.isCancelled` | `false` |
| `try Task.checkCancellation()` | does not throw |
| `try await Task.sleep(for:)` | completes normally |
| `Task.hasActiveCancellationShield` | `true` |

The trap follows directly: **a `while !Task.isCancelled` loop inside a shield never exits.** The
condition it polls is the one the shield is suppressing. Shield a bounded operation, never a poll
loop. Same for `withTaskCancellationHandler` — an `onCancel` registered *inside* a shield does not
fire for an already-pending cancellation.

Cancellation is masked for the duration of the region only. Once the shield exits, `Task.isCancelled`
reads `true` again, and a structured child that outlives the region observes the cancellation
normally — shielding a spawn does **not** permanently detach the child.

Nesting is safe: an inner shield popping leaves the outer one installed.

#### Detecting a shield: `hasActiveCancellationShield` (OS27)

`Task.hasActiveCancellationShield` (static) and `UnsafeCurrentTask.hasActiveCancellationShield`
(instance) report whether the **current task** has a shield installed. Use it in library code whose
cancellation contract changes under a shield — for example, to refuse to enter a poll loop that
could never terminate:

```swift
@available(anyAppleOS 27, *)
func drainUntilCancelled() async {
    guard !Task.hasActiveCancellationShield else {
        assertionFailure("drainUntilCancelled polls Task.isCancelled; a shield would hang it")
        return
    }
    while !Task.isCancelled { await Task.yield() }
}
```

**It is per-task, not per-region.** A structured child running inside the parent's shielded region
reports `hasActiveCancellationShield == false` — it has no shield of its own — even though it *does*
observe `isCancelled == false` while the region is active. Do not use it to ask "is cancellation
currently masked for me"; it answers only "did *this* task install a shield".

### Task.sleep

Suspends the current task for a duration. Supports cancellation — throws `CancellationError` if cancelled during sleep.

```swift
// Duration-based (preferred)
try await Task.sleep(for: .seconds(2))
try await Task.sleep(for: .milliseconds(500))

// Nanoseconds (older API)
try await Task.sleep(nanoseconds: 2_000_000_000)
```

### Task.yield

Voluntarily yields execution to allow other tasks to run. Use in long-running synchronous loops.

```swift
for i in 0..<1_000_000 {
    if i.isMultiple(of: 1000) {
        await Task.yield()
    }
    process(i)
}
```

### Task Priority

| Priority | Use Case |
|---|---|
| `.userInitiated` | Direct user action, visible result |
| `.high` | Same as .userInitiated |
| `.medium` | Default when not specified |
| `.low` | Prefetching, non-urgent work |
| `.utility` | Same as .low — long computation, progress shown |
| `.background` | Maintenance, cleanup, not time-sensitive |

```swift
Task(priority: .userInitiated) {
    await loadVisibleContent()
}

Task(priority: .background) {
    await cleanupTempFiles()
}
```

### @TaskLocal

Task-scoped values that propagate to child tasks automatically.

```swift
enum RequestContext {
    @TaskLocal static var requestID: String?
    @TaskLocal static var userID: String?
}

// Set values for a scope
RequestContext.$requestID.withValue("req-123") {
    RequestContext.$userID.withValue("user-456") {
        // Both values available here and in child tasks
        Task {
            print(RequestContext.requestID)  // "req-123"
            print(RequestContext.userID)     // "user-456"
        }
    }
}

// Outside scope — values are nil
print(RequestContext.requestID)  // nil
```

**Propagation rules**: `@TaskLocal` values propagate to child tasks created with `Task {}`. They do NOT propagate to `Task.detached {}`.

### Task Timeout Pattern

Enforce a deadline on any async operation using a task group race:

```swift
func withTimeout<T: Sendable>(
    _ duration: Duration,
    operation: @Sendable @escaping () async throws -> T
) async throws -> T {
    try await withThrowingTaskGroup(of: T.self) { group in
        group.addTask { try await operation() }
        group.addTask {
            try await Task.sleep(for: duration)
            throw TimeoutError()
        }
        guard let result = try await group.next() else {
            throw TimeoutError()
        }
        group.cancelAll()  // Cancel the loser — without this it keeps running
        return result
    }
}
```

`group.cancelAll()` is critical. Without it, the losing task (either the timeout or the operation) continues running until the group scope exits.

### Task Retain Cycles

Tasks capture variables like closures. Stored tasks that reference `self` create retain cycles.

```swift
// ❌ Retain cycle: self → task → self
task = Task {
    while true { await self.poll() }
}

// ✅ Weak capture breaks the cycle
task = Task { [weak self] in
    while let self, !Task.isCancelled {
        await self.poll()
    }
}
```

**Rule**: Use `[weak self]` when the Task is stored as a property or iterates an infinite async sequence. Short-lived Tasks that complete quickly can use strong captures.

### Thread.current in Swift 6

`Thread.current` is unavailable from async contexts in Swift 6 language mode:

```swift
// ❌ Compiler error in Swift 6 mode
func check() async { print(Thread.current) }

// ✅ Workaround for debugging only
extension Thread {
    static var currentThread: Thread { Thread.current }
}
```

Don't rely on thread identity for correctness — tasks move between threads at suspension points. Reason about isolation domains instead.

### Task Gotcha Table

| Gotcha | Symptom | Fix |
|---|---|---|
| Task never cancelled | Resource leak, work continues after view disappears | Store task, cancel in deinit/onDisappear |
| Ignoring cancellation | Task runs to completion even when cancelled | Check Task.isCancelled in loops, use checkCancellation() |
| Task.detached loses actor context | "Not isolated to MainActor" | Use Task {} when you need actor isolation |
| Capturing self in stored Task | Retain cycle, deinit never called | Use [weak self] for long-lived or stored tasks |
| Assuming async = background | Code stays on calling actor | Use @concurrent to force background execution |
| TaskLocal not propagated | Value is nil in detached task | TaskLocal only propagates to child tasks, not detached |
| Task priority inversion | Low-priority task blocks high-priority | System handles most cases; avoid awaiting low-priority from high |
| Thread.current in async context | Compiler error in Swift 6 mode | Don't rely on thread identity — use isolation domains |

---

## Part 4: Structured Concurrency

### async let

Run a fixed number of operations in parallel. All `async let` bindings are implicitly awaited when the scope exits.

```swift
async let images = fetchImages()
async let metadata = fetchMetadata()
async let config = loadConfig()

// All three run concurrently, await together
let (imgs, meta, cfg) = try await (images, metadata, config)
```

**Semantics**: If one `async let` throws, the others are cancelled. All must complete (or be cancelled) before the enclosing scope exits.

### TaskGroup — Non-Throwing

Dynamic number of parallel tasks where none throw.

```swift
let results = await withTaskGroup(of: String.self) { group in
    for name in names {
        group.addTask {
            await fetchGreeting(for: name)
        }
    }

    var greetings: [String] = []
    for await greeting in group {
        greetings.append(greeting)
    }
    return greetings
}
```

### TaskGroup — Throwing

Dynamic number of parallel tasks that can throw.

```swift
let images = try await withThrowingTaskGroup(of: (URL, UIImage).self) { group in
    for url in urls {
        group.addTask {
            let image = try await downloadImage(url)
            return (url, image)
        }
    }

    var results: [URL: UIImage] = [:]
    for try await (url, image) in group {
        results[url] = image
    }
    return results
}
```

### withDiscardingTaskGroup (iOS 17+)

For when you need concurrency but don't need to collect results. More memory-efficient than regular TaskGroup — no result storage.

```swift
try await withThrowingDiscardingTaskGroup { group in
    for connection in connections {
        group.addTask {
            try await connection.monitor()
            // Results are discarded — useful for long-running services
        }
    }
    // Group stays alive until all tasks complete or one throws
}
```

#### Real-world pattern — merge multiple notification streams

```swift
extension NotificationCenter {
    func notifications(named names: [Notification.Name]) -> AsyncStream<Void> {
        AsyncStream { continuation in
            let task = Task {
                await withDiscardingTaskGroup { group in
                    for name in names {
                        group.addTask {
                            for await _ in self.notifications(named: name) {
                                continuation.yield()
                            }
                        }
                    }
                }
                continuation.finish()
            }
            continuation.onTermination = { _ in task.cancel() }
        }
    }
}
```

### TaskGroup Control

```swift
await withTaskGroup(of: Data.self) { group in
    // Add tasks conditionally
    group.addTaskUnlessCancelled {
        await fetchData()
    }

    // Cancel remaining tasks
    group.cancelAll()

    // Wait without collecting
    await group.waitForAll()

    // Iterate one at a time
    while let result = await group.next() {
        process(result)
    }
}
```

### Task Tree Semantics

Structured concurrency forms a tree:
- **Parent cancellation cancels all children** — cancelling a task cancels all `async let` and TaskGroup children
- **Child error propagates to parent** — in throwing groups, a child error cancels siblings and propagates up
- **All children must complete before parent returns** — the scope awaits all children, even cancelled ones

```swift
// If fetchImages() throws, fetchMetadata() is automatically cancelled
async let images = fetchImages()
async let metadata = fetchMetadata()
let result = try await (images, metadata)
```

### Batching — When Task-Per-Item Is Wrong

For large input sets (thousands of files, large API result lists, big migration batches), the naive "spawn one Task per item" pattern is rarely optimal:

- The cooperative thread pool has a fixed size (typically core count). 10,000 tasks don't get 10,000 threads — they queue up and add scheduling overhead.
- Each task allocates context (stack, task-locals, isolation tracking). For trivial work, the overhead dwarfs the actual computation.
- Memory pressure: keeping 10,000 in-flight task contexts alive while results accumulate can spike memory.

**Profile first.** The naive approach may be fine for your scale. If it's not, batch:

```swift
// ✅ Bounded concurrency — N workers process items from a shared queue
func processAll(_ items: [Item], concurrency: Int = 8) async throws {
    try await withThrowingTaskGroup(of: Void.self) { group in
        var iterator = items.makeIterator()
        var inFlight = 0

        // Prime the pump
        while inFlight < concurrency, let item = iterator.next() {
            group.addTask { try await process(item) }
            inFlight += 1
        }

        // Replace each finished task with the next item
        for try await _ in group {
            if let next = iterator.next() {
                group.addTask { try await process(next) }
            }
        }
    }
}
```

Match `concurrency` to the work's profile: 2–4 for CPU-bound work, 8–16 for I/O-bound, much higher (32+) only if you've measured.

### Structured Concurrency Gotcha Table

| Gotcha | Symptom | Fix |
|---|---|---|
| async let unused | Work still executes; the only signal is a #NoUsage warning | Assign all async let results or use withDiscardingTaskGroup |
| TaskGroup accumulating memory | Memory grows with 10K+ tasks | Process results as they arrive, don't collect all |
| Capturing mutable state in addTask | "Mutation of captured var" | Use let binding or actor |
| Not handling partial failure | Some tasks succeed, some fail | Use group.next() and handle errors individually |
| async let never awaited | "initialization of immutable value was never used" (#NoUsage) | Await the binding, or use withDiscardingTaskGroup |
| Returning from group early | Remaining tasks still run | Call group.cancelAll() before returning |

---

## Part 5: Async Sequences

### AsyncStream

Non-throwing stream for producing values over time.

```swift
let stream = AsyncStream<Int> { continuation in
    for i in 0..<10 {
        continuation.yield(i)
    }
    continuation.finish()
}

for await value in stream {
    print(value)
}
```

### AsyncThrowingStream

Stream that can fail with an error.

```swift
let stream = AsyncThrowingStream<Data, Error> { continuation in
    let monitor = NetworkMonitor()
    monitor.onData = { data in
        continuation.yield(data)
    }
    monitor.onError = { error in
        continuation.finish(throwing: error)
    }
    monitor.onComplete = {
        continuation.finish()
    }

    continuation.onTermination = { @Sendable _ in
        monitor.stop()
    }

    monitor.start()
}

do {
    for try await data in stream {
        process(data)
    }
} catch {
    handleStreamError(error)
}
```

### Continuation API

```swift
let stream = AsyncStream<Value> { continuation in
    // Emit a value
    continuation.yield(value)

    // End the stream normally
    continuation.finish()

    // Cleanup when consumer cancels or stream ends
    continuation.onTermination = { @Sendable termination in
        switch termination {
        case .cancelled:
            cleanup()
        case .finished:
            finalCleanup()
        @unknown default:
            break
        }
    }
}

// For throwing streams
let stream = AsyncThrowingStream<Value, Error> { continuation in
    continuation.yield(value)
    continuation.finish()                  // Normal end
    continuation.finish(throwing: error)   // End with error
}
```

### Buffering Policies

Control what happens when values are produced faster than consumed.

```swift
// Keep all values (default) — memory can grow unbounded
let stream = AsyncStream<Int>(bufferingPolicy: .unbounded) { continuation in
    // ...
}

// Keep oldest N values, drop new ones when buffer is full
let stream = AsyncStream<Int>(bufferingPolicy: .bufferingOldest(100)) { continuation in
    // ...
}

// Keep newest N values, drop old ones when buffer is full
let stream = AsyncStream<Int>(bufferingPolicy: .bufferingNewest(100)) { continuation in
    // ...
}
```

| Policy | Behavior | Use When |
|---|---|---|
| `.unbounded` | Keeps all values | Consumer keeps up, or bounded producer |
| `.bufferingOldest(N)` | Drops new values when full | Order matters, older values have priority |
| `.bufferingNewest(N)` | Drops old values when full | Latest state matters (UI updates, sensor data) |

### Custom AsyncSequence

```swift
struct Counter: AsyncSequence {
    typealias Element = Int
    let limit: Int

    struct AsyncIterator: AsyncIteratorProtocol {
        var current = 0
        let limit: Int

        mutating func next() async -> Int? {
            guard current < limit else { return nil }
            defer { current += 1 }
            return current
        }
    }

    func makeAsyncIterator() -> AsyncIterator {
        AsyncIterator(limit: limit)
    }
}

// Usage
for await number in Counter(limit: 5) {
    print(number)  // 0, 1, 2, 3, 4
}
```

### AsyncSequence Operators

Standard operators work on any `AsyncSequence`:

```swift
// Map
for await name in users.map(\.name) { }

// Filter
for await adult in users.filter({ $0.age >= 18 }) { }

// CompactMap
for await image in urls.compactMap({ await tryLoadImage($0) }) { }

// Prefix
for await first5 in stream.prefix(5) { }

// first(where:)
let match = await stream.first(where: { $0 > threshold })

// Contains
let hasMatch = await stream.contains(where: { $0 > threshold })

// Reduce
let sum = await numbers.reduce(0, +)
```

### Built-in Async Sequences

```swift
// NotificationCenter
for await notification in NotificationCenter.default.notifications(named: .didUpdate) {
    handleUpdate(notification)
}

// URLSession bytes
let (bytes, response) = try await URLSession.shared.bytes(from: url)
for try await byte in bytes {
    process(byte)
}

// FileHandle bytes
for try await line in FileHandle.standardInput.bytes.lines {
    process(line)
}
```

### Async Sequence Gotcha Table

| Gotcha | Symptom | Fix |
|---|---|---|
| Continuation yielded after finish | Runtime warning, value lost | Track finished state, guard before yield |
| Stream never finishing | for-await loop hangs forever | Always call continuation.finish() in all code paths |
| No onTermination handler | Resource leak when consumer cancels | Set continuation.onTermination for cleanup |
| Unbounded buffer | Memory growth under load | Use .bufferingNewest(N) or .bufferingOldest(N) |
| Multiple consumers | Only first consumer gets values | AsyncStream is single-consumer; create separate streams per consumer |
| for-await on MainActor | UI freezes waiting for values | Use Task {} to consume off the main path |

---

## Part 6: Isolation Patterns

### @MainActor on Functions

```swift
@MainActor
func updateUI() {
    label.text = "Done"
}

// Call from async context
func doWork() async {
    let result = await computeResult()
    await updateUI()           // Hops to MainActor
}
```

### MainActor.run

Explicitly execute a closure on the main actor from any context.

```swift
func processData() async {
    let result = await heavyComputation()

    await MainActor.run {
        self.label.text = result
        self.progressView.isHidden = true
    }
}
```

### MainActor.assumeIsolated (iOS 13+, Swift 5.9 compiler)

Assert that code is already running on the main actor. Crashes at runtime if the assertion is false.

```swift
func legacyCallback() {
    // We KNOW this is called on main thread (UIKit guarantee)
    MainActor.assumeIsolated {
        self.viewModel.update()    // Access @MainActor state
    }
}
```

See `skills/assume-isolated.md` for comprehensive patterns.

### nonisolated

Opt out of the enclosing actor's isolation.

```swift
@MainActor
class ViewModel {
    let id: UUID                           // Implicitly nonisolated (let)

    nonisolated var analyticsID: String {   // Explicitly nonisolated
        id.uuidString
    }

    var items: [Item] = []                 // Isolated to MainActor
}
```

### nonisolated(unsafe)

Compiler escape hatch. Tells the compiler to treat a property as if it's not isolated, without any safety guarantees.

```swift
// Use only when you have external guarantees of thread safety
nonisolated(unsafe) var legacyState: Int = 0
```

**Warning**: `nonisolated(unsafe)` provides zero runtime protection. Data races will not be caught. Use only as a last resort for bridging legacy code.

### @preconcurrency

Suppress concurrency warnings for pre-concurrency APIs during migration.

```swift
// Suppress warnings for entire module
@preconcurrency import MyLegacyFramework

// Suppress for specific protocol conformance
class MyDelegate: @preconcurrency SomeLegacyDelegate {
    func delegateCallback() {
        // No Sendable warnings for this conformance
    }
}
```

### #isolation (Swift 6.0+)

Capture the caller's isolation context so a function runs on whatever actor the caller is on.

```swift
func doWork(isolation: isolated (any Actor)? = #isolation) async {
    // Runs on caller's actor — no hop if caller is already isolated
    performWork()
}

// Called from @MainActor — runs on MainActor
@MainActor
func setup() async {
    await doWork()             // doWork runs on MainActor
}

// Called from custom actor — runs on that actor
actor MyActor {
    func run() async {
        await doWork()         // doWork runs on MyActor
    }
}
```

### #isolation Capture in Task Closures (SE-0420)

When spawning `Task` closures that need to work with non-Sendable types, capture the isolation parameter to inherit the caller's context.

```swift
func process(
    delegate: NonSendableDelegate,
    isolation: isolated (any Actor)? = #isolation
) {
    Task {
        _ = isolation          // Forces capture — Task inherits caller's isolation
        delegate.doWork()      // ✅ Safe: running on caller's actor
    }
}
```

**Why `_ = isolation` is required**: Per SE-0420, `Task` closures only inherit isolation when a non-optional binding of an isolated parameter is captured by the closure. The `_ = isolation` statement forces this capture. Without it, the Task runs on the default executor and the non-Sendable capture is a compiler error.

**When to use**: Spawning Tasks that work with non-Sendable delegate objects, fire-and-forget async work that needs access to caller's state, or bridging callback-based APIs while keeping delegates alive.

### Isolation Gotcha Table

| Gotcha | Symptom | Fix |
|---|---|---|
| MainActor.run from MainActor | Unnecessary hop, potential deadlock risk | Check context or use assumeIsolated |
| nonisolated(unsafe) data race | Crash at runtime, corrupted state | Use proper isolation or Mutex |
| @preconcurrency hiding real issues | Runtime crashes in production | Migrate to proper concurrency before shipping |
| #isolation not available pre-6.0 | Compiler error | Use traditional @MainActor annotation |
| #isolation not captured in Task | Non-Sendable capture error | Add `_ = isolation` inside Task closure (SE-0420) |
| nonisolated on actor method | Can't access any isolated state | Only use for computed properties from non-isolated state |
| Thread.current in async context | Compiler error in Swift 6 mode | Don't rely on thread identity — reason about isolation domains |

---

## Part 7: Continuations

Bridge callback-based APIs to async/await.

### withCheckedContinuation

Non-throwing bridge.

```swift
func currentLocation() async -> CLLocation {
    await withCheckedContinuation { continuation in
        locationManager.requestLocation { location in
            continuation.resume(returning: location)
        }
    }
}
```

### withCheckedThrowingContinuation

Throwing bridge.

```swift
func fetchUser(id: String) async throws -> User {
    try await withCheckedThrowingContinuation { continuation in
        api.fetchUser(id: id) { result in
            switch result {
            case .success(let user):
                continuation.resume(returning: user)
            case .failure(let error):
                continuation.resume(throwing: error)
            }
        }
    }
}
```

### Continuation Resume Methods

```swift
// Return a value
continuation.resume(returning: value)

// Throw an error
continuation.resume(throwing: error)

// From a Result type
continuation.resume(with: result)    // Result<T, Error>
```

### Resume-Exactly-Once Rule

A continuation MUST be resumed exactly once:
- **Resuming twice** crashes with `"Continuation already resumed"` (checked) or undefined behavior (unsafe)
- **Never resuming** causes the awaiting task to hang forever — a silent leak

```swift
// DANGEROUS: callback might not be called
func riskyBridge() async throws -> Data {
    try await withCheckedThrowingContinuation { continuation in
        api.fetch { data, error in
            if let error {
                continuation.resume(throwing: error)
                return
            }
            if let data {
                continuation.resume(returning: data)
                return
            }
            // BUG: if both are nil, continuation is never resumed
            // Fix: add a fallback
            continuation.resume(throwing: BridgeError.noResponse)
        }
    }
}
```

### Bridging Delegates

```swift
class LocationBridge: NSObject, CLLocationManagerDelegate {
    private var continuation: CheckedContinuation<CLLocation, Error>?
    private let manager = CLLocationManager()

    func requestLocation() async throws -> CLLocation {
        try await withCheckedThrowingContinuation { continuation in
            self.continuation = continuation
            manager.delegate = self
            manager.requestLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        continuation?.resume(returning: locations[0])
        continuation = nil     // Prevent double resume
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        continuation?.resume(throwing: error)
        continuation = nil
    }
}
```

### Unsafe Continuations

Skip runtime checks for performance. Same API as checked, but misuse causes undefined behavior instead of a diagnostic crash.

```swift
func fastBridge() async -> Data {
    await withUnsafeContinuation { continuation in
        // No runtime check for double-resume or missing resume
        fastCallback { data in
            continuation.resume(returning: data)
        }
    }
}
```

**Use checked continuations during development, switch to unsafe only after thorough testing and when profiling shows the check is a bottleneck.**

### Single-Resume `Continuation` (OS27 — limited through 27.1)

Swift 6.4 adds `withContinuation`, vending a `~Copyable` `Continuation` whose `resume` methods are `consuming` — so a **double-resume is a build error** (`'c' consumed more than once`) rather than a runtime crash. It is the statically-checked successor to `withCheckedContinuation`.

**Not a drop-in replacement in 27.0 or 27.1.** Because the continuation is `~Copyable`, resuming it from an `@escaping` callback does not compile — `noncopyable 'c' cannot be consumed when captured by an escaping closure or borrowed by a non-Escapable type` — which is exactly the delegate / completion-handler bridging that `withCheckedContinuation` is for. Only synchronous resume inside the `withContinuation` body works today; never-resuming is **not** diagnosed.

```swift
@available(anyAppleOS 27, *)
func value() async -> Int {
    await withContinuation { (c: consuming Continuation<Int, Never>) in
        c.resume(returning: 42)                       // OK — resumed in-body
        // mgr.fetch { v in c.resume(returning: v) }  // ✗ won't compile: escaping capture
    }
}
```

Keep `withCheckedContinuation` for real callback bridging: Xcode 27.0 and 27.1 (swiftlang-6.4.0.34.1) ship with the escaping-closure limitation (re-probed at SIL on both builds). On a newer toolchain, compile the commented escaping line before relying on it.

### Continuation Gotcha Table

| Gotcha | Symptom | Fix |
|---|---|---|
| Resume called twice | "Continuation already resumed" crash | Set continuation to nil after resume |
| Resume never called | Task hangs indefinitely | Ensure all code paths resume — including error/nil cases |
| Capturing continuation | Continuation escapes scope | Store in property, ensure single resume |
| Unsafe continuation in debug | No diagnostics for misuse | Use withCheckedContinuation during development |
| Delegate called multiple times | Crash on second resume | Use AsyncStream instead of continuation for repeated callbacks |
| Callback on wrong thread | Doesn't matter for continuation | Continuations can be resumed from any thread |

---

## Part 8: Migration Patterns

Common migrations from GCD and completion handlers to Swift concurrency.

### DispatchQueue to Actor

```swift
// BEFORE: DispatchQueue for thread safety
class ImageCache {
    private let queue = DispatchQueue(label: "cache", attributes: .concurrent)
    private var cache: [URL: UIImage] = [:]

    func get(_ url: URL, completion: @escaping (UIImage?) -> Void) {
        queue.async { completion(self.cache[url]) }
    }

    func set(_ url: URL, image: UIImage) {
        queue.async(flags: .barrier) { self.cache[url] = image }
    }
}

// AFTER: Actor
actor ImageCache {
    private var cache: [URL: UIImage] = [:]

    func get(_ url: URL) -> UIImage? {
        cache[url]
    }

    func set(_ url: URL, image: UIImage) {
        cache[url] = image
    }
}
```

### DispatchGroup to TaskGroup

```swift
// BEFORE: DispatchGroup
let group = DispatchGroup()
var results: [Data] = []
for url in urls {
    group.enter()
    fetch(url) { data in
        results.append(data)
        group.leave()
    }
}
group.notify(queue: .main) { use(results) }

// AFTER: TaskGroup
let results = await withTaskGroup(of: Data.self) { group in
    for url in urls {
        group.addTask { await fetch(url) }
    }
    var collected: [Data] = []
    for await data in group {
        collected.append(data)
    }
    return collected
}
use(results)
```

### Completion Handler to async

```swift
// BEFORE
func fetchData(completion: @escaping (Result<Data, Error>) -> Void) {
    URLSession.shared.dataTask(with: url) { data, _, error in
        if let error { completion(.failure(error)); return }
        guard let data else { completion(.failure(FetchError.noData)); return }
        completion(.success(data))
    }.resume()
}

// AFTER
func fetchData() async throws -> Data {
    let (data, _) = try await URLSession.shared.data(from: url)
    return data
}
```

### @objc Delegates with @MainActor

```swift
@MainActor
class ViewController: UIViewController, UITableViewDelegate {
    // @objc delegate methods inherit @MainActor isolation from the class
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Already on MainActor — safe to update UI
        updateSelection(indexPath)
    }
}
```

### NotificationCenter to AsyncSequence

```swift
// BEFORE
let observer = NotificationCenter.default.addObserver(
    forName: .didUpdate, object: nil, queue: .main
) { notification in
    handleUpdate(notification)
}
// Must remove observer in deinit

// AFTER
let task = Task {
    for await notification in NotificationCenter.default.notifications(named: .didUpdate) {
        await handleUpdate(notification)
    }
}
// Cancel task in deinit — no manual observer removal needed
```

This still hands you an untyped `Notification`. For notifications a **framework** declares, prefer the typed API below.

### Typed Notifications (iOS 26+)

`Notification.userInfo` is `[AnyHashable: Any]?` — every read is a cast that can silently return `nil`, and the payload is not `Sendable`, so unpacking it under strict concurrency is where the errors start. iOS 26 replaced this for framework notifications with two protocols carrying **typed stored properties**:

| Protocol | Isolation and delivery | Use when |
|---|---|---|
| `NotificationCenter.MainActorMessage` | Observer closure is **already `@MainActor`-isolated**; delivered **synchronously** on post | UI-adjacent notifications (keyboard, lifecycle, orientation) |
| `NotificationCenter.AsyncMessage` | `Sendable`; observer is `async`, also consumable as an `AsyncSequence`; delivered **asynchronously** | Background/system signals (power state, thermal state) |

**Async delivery is not ordered against your own work.** Apple: *"Asynchronous delivery isn't suitable for messages with time-critical deliveries, such as a message that must have its observers called before a certain action takes place."* If observers must run before you proceed, `AsyncMessage` is the wrong protocol — that is the deciding factor between the two, not merely which isolation you prefer.

The payoff is clearest on keyboard avoidance — the most-written notification boilerplate in iOS:

```swift
// BEFORE — three casts, each of which can silently fail
NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillShowNotification,
                                       object: nil, queue: .main) { note in
    guard let frame = note.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect,
          let duration = note.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double
    else { return }
    animate(to: frame, over: duration)
}

// AFTER — typed properties, closure is already on the main actor
@available(iOS 26, *)
@MainActor
func observeKeyboard(on screen: UIScreen) -> NotificationCenter.ObservationToken {
    NotificationCenter.default.addObserver(of: screen,
                                          for: UIResponder.KeyboardWillShowMessage.self) { message in
        animate(to: message.endFrame, over: message.animationDuration)   // no casts, no optionals
    }
}
```

`KeyboardWillShowMessage` also carries `beginFrame`, `animationCurve`, `isLocal`, and `screen`. Do **not** reach for `UIScreen.main` as the subject — it is deprecated in iOS 26; take the screen from context (`view.window?.windowScene?.screen`).

**The isolation win is compiler-visible, not stylistic.** The BEFORE block warns — *"call to main actor-isolated global function in a synchronous nonisolated context"* — because `queue: .main` schedules on the main *thread* without making the closure main-actor *isolated*. The AFTER block compiles clean: `MainActorMessage` observers are `@MainActor` by signature, so the hop is expressed in the type system instead of assumed.

**`AsyncMessage` as a stream** — the typed replacement for `notifications(named:)`:

```swift
@available(iOS 26, *)
func watchPowerState() async {
    for await message in NotificationCenter.default.messages(
        of: ProcessInfo.processInfo,
        for: ProcessInfo.PowerStateDidChangeMessage.self
    ) {
        _ = message
    }
}
```

`messages(of:for:bufferSize:)` takes an explicit `bufferSize` that defaults to **10** — raise it if your consumer is slower than the post rate.

**Lifecycle — this is the part that actually changes.** `addObserver` returns a `NotificationCenter.ObservationToken`, and observation is tied to the token's lifetime: Apple states it *"automatically de-registers the observer if the token goes out of scope."* Retain the token for as long as you want the observation, and dropping it is a complete teardown. `removeObserver(_:)` still exists for stopping early, but it is no longer the thing standing between you and a leak — which is the opposite of the old `addObserver(forName:)` contract, where forgetting to remove leaked the observer.

**Posting** works both ways: `post(_ message:)` and `post(_ message:subject:)`. `MainActorMessage.post` is itself `@MainActor`.

#### Coverage — check before you migrate

The protocols are **iOS 26**, but each framework adopts them separately, and a framework that has not adopted them has no typed API to migrate to. Conforming frameworks as of 27:

| Cycle | Frameworks |
|---|---|
| 26 | UIKit (72 messages — all keyboard, app lifecycle, orientation, accessibility status), Foundation (31 — `ProcessInfo` power/thermal, `UndoManager`, `NSMetadataQuery`), GameController, HealthKit, EventKit, ManagedSettings, LiveCommunicationKit, AVFoundation (playback only, from 26.4) |
| 27 | Adds Accessibility, AVFAudio, CoreData, CoreTelephony, ExternalAccessory, MessageUI |

**AVFoundation's single conformer is playback-side** (`AVPlayerInterstitialEventMonitor.ScheduleRequestCompleted`, 26.4). **Capture has none** — `AVCaptureSession` interruption and runtime-error notifications are still untyped, as is all of PhotoKit. For those, keep `notifications(named:)`; there is nothing typed to adopt.

**Custom types**: conform your own payload to either protocol. Interop with existing `Notification` posters is what Apple calls "optional interoperability", and it works by **conversion**, not by sharing a post — `makeMessage(_:)` reads a `Notification`'s `userInfo` into your typed properties, and `makeNotification(_:)` writes them back out. Supply both and an observer of your message type receives posts made the old way, and vice versa, so migration can be incremental.

All three requirements have **default implementations**, which is the trap: take the default `name` and it will not match your existing `Notification.Name`, so the bridge silently never connects. Declaring `static var name` explicitly is what wires a typed message to notifications already being posted.

### Timer to AsyncSequence

```swift
// BEFORE
let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
    updateUI()
}
// Must invalidate in deinit

// AFTER
let task = Task {
    while !Task.isCancelled {
        await updateUI()
        try? await Task.sleep(for: .seconds(1))
    }
}
// Cancel task in deinit
```

### DispatchSemaphore to Actor

```swift
// BEFORE: Semaphore to limit concurrent operations
let semaphore = DispatchSemaphore(value: 3)
for url in urls {
    DispatchQueue.global().async {
        semaphore.wait()
        defer { semaphore.signal() }
        download(url)
    }
}

// AFTER: TaskGroup with limited concurrency
await withTaskGroup(of: Void.self) { group in
    var inFlight = 0
    for url in urls {
        if inFlight >= 3 {
            await group.next()   // Wait for one to finish
            inFlight -= 1
        }
        group.addTask { await download(url) }
        inFlight += 1
    }
    await group.waitForAll()
}
```

### Migration Gotcha Table

| Gotcha | Symptom | Fix |
|---|---|---|
| DispatchQueue.sync to actor | Deadlock potential | Remove .sync, use await |
| Global dispatch to actor contention | Slowdown from serialization | Profile with Concurrency Instruments |
| Legacy delegate + Sendable | "Cannot conform to Sendable" | Use @preconcurrency import or @MainActor isolation |
| Callback called multiple times | Continuation crash | Use AsyncStream instead of continuation |
| Semaphore.wait in async context | Thread starvation, potential deadlock | Use TaskGroup with manual concurrency limiting |
| DispatchQueue.main.async to MainActor | Subtle timing differences | MainActor.run is the equivalent — test edge cases |
| Replacing structured tasks with top-level Tasks | Losing cancellation propagation and error handling | Use async let or TaskGroup for related parallel work |
| Batch @unchecked Sendable to fix warnings | Hiding real data races throughout codebase | Fix one type at a time with proper Sendable, actor, or sending |

---

## Swift 6.4 Changes

Two concurrency changes shipped in Swift 6.4 (Xcode 27) and apply to code written today; one further proposal is still pending. Track the [Swift Evolution dashboard](https://www.swift.org/swift-evolution/) for status.

### Async defer

Swift 6.4 lifts the restriction that prevents `await` inside `defer` blocks. No new syntax — `defer { await cleanup() }` compiles, matching the cooperative-cancellation timing of structured concurrency.

### Task error-swallowing diagnostic

`Task { try ... }` let thrown errors disappear silently — no warning, no crash, just a dropped failure. Swift 6.4 diagnoses unstructured Tasks whose body can throw but where the caller never reads `task.value` or `task.result` (`#NoUseUnstructuredThrowingTask`). The two valid responses:
- Handle errors inside the Task body (`do { try ... } catch { ... }`).
- Store the Task handle and `await task.value` (which throws if the body threw).

The diagnostic fires on code that follows the "fire and forget" Task pattern with throwing functions.

### Still pending: `Task.withDeadline` (proposal name TBD)

A standard library task API that mirrors the homemade `withTimeout` pattern earlier in this file: kick off async work, cancel automatically if a duration is exceeded. The proposal is under review and naming is still being debated; Swift 6.4 ships no `Task.withDeadline` member. When it ships, prefer it over the manual `withThrowingTaskGroup` race pattern.

---

## API Quick Reference

| Task | API | Swift Version |
|---|---|---|
| Define isolated type | `actor MyActor { }` | 5.5+ |
| Run on main thread | `@MainActor` | 5.5+ |
| Mark as safe to share | `: Sendable` | 5.5+ |
| Mark closure safe to share | `@Sendable` | 5.5+ |
| Parallel tasks (fixed) | `async let` | 5.5+ |
| Parallel tasks (dynamic) | `withTaskGroup` | 5.5+ |
| Stream values | `AsyncStream` | 5.5+ |
| Bridge callback | `withCheckedContinuation` | 5.5+ |
| Check cancellation | `Task.checkCancellation()` | 5.5+ |
| Task-scoped values | `@TaskLocal` | 5.5+ |
| Assert isolation | `MainActor.assumeIsolated` | 5.9+ (iOS 13+) |
| Capture caller isolation | `#isolation` | 6.0+ |
| Lock-based sync | `Mutex` | 6.0+ (iOS 18+) |
| Discard results | `withDiscardingTaskGroup` | 5.9+ (iOS 17+) |
| Transfer ownership | `sending` parameter | 6.0+ |
| Force background | `@concurrent` | 6.2+ |
| Isolated conformance | `extension: @MainActor Proto` | 6.2+ |

## Resources

**WWDC**: 2021-10132, 2021-10134, 2022-110350, 2025-268

**Docs**: /swift/concurrency, /swift/actor, /swift/sendable, /swift/taskgroup

**Skills**: See `skills/swift-concurrency.md`, `skills/assume-isolated.md`, `skills/synchronization.md`, `skills/concurrency-profiling.md`
