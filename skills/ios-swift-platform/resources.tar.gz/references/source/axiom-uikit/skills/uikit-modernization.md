# UIKit App Modernization — Scene Lifecycle & Resizability

The 27 cycle makes the **scene-based life cycle mandatory** and assumes every app is resizable. This is the highest-impact UIKit change in years: it is a launch-time breaking change, not an opt-in.

## The breaking change — UIScene is required at 27

When you build against the 27 SDKs, **an app with only a `UIApplicationDelegate` (no `UISceneDelegate`) will no longer launch.** You must adopt the scene-based life cycle.

- Migration path: WWDC 2025 "Make your UIKit app more flexible" + Apple's doc "Transitioning to the UIKit scene-based life cycle."
- The SDK reflects this: `UIApplicationDelegate.application(_:supportedInterfaceOrientationsForWindow:)` and `UIApplication.supportedInterfaceOrientationsForWindow(_:)` are **deprecated at iOS 27** in favor of `UIWindowSceneDelegate.supportedInterfaceOrientations(for:)`.

This is a behavior/requirement change, so it carries no additive `OS27` marker — but it gates launch. Treat it as a must-fix before building against the 27 SDK.

#### The Info.plist side of the migration

- **Scene manifest** — `UIApplicationSceneManifest` declares the scenes. `UIApplicationSupportsMultipleScenes` (Bool) opts into simultaneous scenes (iPad multi-window, macOS windows); `UISceneConfigurations` holds the default configuration the system uses to create new scenes — under the `UIWindowSceneSessionRoleApplication` role, each entry carries `UISceneConfigurationName` and, conventionally, `UISceneDelegateClassName` (`UISceneStoryboardFile` for storyboard apps):
  ```xml
  <key>UIApplicationSceneManifest</key>
  <dict>
      <key>UIApplicationSupportsMultipleScenes</key><true/>
      <key>UISceneConfigurations</key>
      <dict>
          <key>UIWindowSceneSessionRoleApplication</key>
          <array>
              <dict>
                  <key>UISceneConfigurationName</key><string>Default</string>
                  <key>UISceneDelegateClassName</key><string>$(PRODUCT_MODULE_NAME).SceneDelegate</string>
              </dict>
          </array>
      </dict>
  </dict>
  ```
- **Launch screen is validated at upload** — apps built with the iOS 27 SDK or later must declare one of `UILaunchScreen`, `UILaunchStoryboardName`, `UILaunchScreens`, `UILaunchStoryboards` or the build fails validation at App Store Connect upload (TN3208; iPhone and iPad, App Store and alternative marketplaces). The storyboard-free path is a `UILaunchScreen` dict with `UIColorName`/`UIImageName`. Submission checklist: axiom-shipping (skills/app-store-submission.md).
- **Destinations, not device checks** — supported destinations/device families are target settings (`TARGETED_DEVICE_FAMILY`); runtime code adapts via size classes and scene geometry, never by re-deriving "what device am I on". Mac availability for iOS apps is an App Store Connect setting — see axiom-macos (skills/ios-apps-on-mac.md).

## Scene lifecycle edges

The connect/foreground/background arc is the easy part; these are the edges apps get wrong:

- **Teardown** — `sceneDidDisconnect(_:)` fires when the user closes the window in the app switcher **or when the system reclaims memory** — it is not app termination. Release scene-scoped resources and save user data here; don't treat it as "the app is quitting".
- **Opening scenes from UIKit** — the peer of SwiftUI's `openWindow` is an activation request (`requestSceneSessionActivation` is slated for deprecation):

  ```swift
  var request = UISceneSessionActivationRequest()
  request.userActivity = NSUserActivity(activityType: "com.example.detail")
  UIApplication.shared.activateSceneSession(for: request) { error in
      // request failed — log it
  }
  ```

  `UISceneSessionActivationRequest(role:)` and `(session:)` target a specific role or an existing session; attaching a `userActivity` is how content reaches the new scene. A scene's `activationConditions` tune which existing scene the system picks for a given target.
- **Drag creates windows** — with `UIApplicationSupportsMultipleScenes`, a drag item carrying an `NSUserActivity` lets the user open that content as a new window by dropping it at the iPad screen edge (UIKit ships the item-provider conformance — `NSUserActivity+NSItemProvider.h`):

  ```swift
  let activity = NSUserActivity(activityType: "com.example.detail")
  activity.userInfo = ["id": document.id]
  let item = UIDragItem(itemProvider: NSItemProvider(object: activity))
  ```

  The `activityType` must also be listed in Info.plist under `NSUserActivityTypes` — without it the drag silently creates no window. Route the activity in `scene(_:willConnectTo:options:)` exactly as for an activation request. SwiftUI's `.onDrag` can vend the same `NSItemProvider`. Pair the activity with your data representations on one item so a drop into another app still transfers content.
- **Per-window undo** — `UIResponder.undoManager` resolves up the responder chain, and SwiftUI's `@Environment(\.undoManager)` is per-window. The multi-window bug is holding one `UndoManager` in a shared model singleton: ⌘Z in one window then undoes edits made in another. Keep the manager scene-scoped — use the environment/responder-chain instance, or own one per scene root, and register undo actions against the manager of the window where the edit happened.
- **Per-scene restoration** — return the window's state from `stateRestorationActivity(for:)`; at the next connect, read it back from `session.stateRestorationActivity` inside `scene(_:willConnectTo:options:)`. This is the UIKit peer of SwiftUI's `@SceneStorage` — per window, not per app.

  ```swift
  func stateRestorationActivity(for scene: UIScene) -> NSUserActivity? {
      let activity = NSUserActivity(activityType: "com.example.browse")
      activity.userInfo = ["path": currentPath]
      return activity
  }
  ```
- **External displays** — a non-interactive external screen is its own scene session under `UIWindowSceneSessionRoleExternalDisplayNonInteractive` (iOS 16; replaces the deprecated unqualified `UIWindowSceneSessionRoleExternalDisplay`). Declare a configuration for that role and the system connects a scene when a screen appears — no `UIScreen` notifications.

#### Scene accessories — declare the content, let the system present it `OS27`

A **scene accessory** declares supplementary content up front; the system presents it on the app's behalf when the associated functionality becomes available (at 27, an external display connecting). `iOS27` only — unavailable on Mac Catalyst, tvOS, visionOS and watchOS.

```swift
@MainActor
final class PresenterViewController: UIViewController {
    private var accessory: UISceneAccessoryRegistration?

    func present(deckID: String) {
        let configuration = UISceneConfiguration(name: "Presentation")
        configuration.delegateClass = PresentationSceneDelegate.self
        accessory = registerSceneAccessory(
            .externalNonInteractive(sceneConfiguration: configuration, userInfo: deckID))
    }

    override func updateProperties() {
        super.updateProperties()
        accessory?.isEnabled = accessory?.isAvailable == true
    }
}
```

| Member | Role |
|---|---|
| `UISceneAccessory.externalNonInteractive(sceneConfiguration:)` / `(sceneConfiguration:userInfo:)` | the only accessory kind at 27 — non-interactive content on an external display |
| `UIViewController.registerSceneAccessory(_:)` | registers it; returns a `UISceneAccessoryRegistration` handle |
| `UISceneAccessoryRegistration.isAvailable` | read-only, the system's call — observable during the `updateProperties` and `layoutSubviews` lifecycle events |
| `UISceneAccessoryRegistration.isEnabled` | read-write, your opt-in; it does **not** reflect availability |
| `UIScene.ConnectionOptions.sceneAccessoryUserInfo` | reads the `userInfo` back in `scene(_:willConnectTo:options:)` |
| `UIViewController.unregisterSceneAccessory(_:)` | unregisters, dismissing the content if it is being presented |

- **The app must remain fully functional without the accessory** — it enhances the experience, it never gates it. Availability is the system's decision; enabling an unavailable accessory does not present it.
- `UISceneConfiguration(name:)` (`iOS27`/`macCatalyst27`/`tvOS27`/`visionOS27`, not watchOS) is a new role-free initializer — sessions created from it have their role set automatically by the system, so an accessory's configuration doesn't name a session role at all.

#### Adaptation traits beyond size classes

`UITraitCollection` carries more adaptation inputs than the size classes: `displayGamut` (iOS 10 — P3 vs sRGB asset decisions), `legibilityWeight` (iOS 13 — Bold Text accessibility setting), and `activeAppearance` (iOS 14 — whether the UI should draw its active or inactive appearance; varies with window foreground state on macOS and in iPad Stage Manager/windowed modes). Observe any of them with `registerForTraitChanges` (see `skills/adaptive-layout.md`). There is **no public pointer-capability trait** — pointer presence is discovered through the interaction APIs themselves (see Desktop-class input below).

## Every app is now resizable

iPhone apps resize freely (iPhone Mirroring on Mac; an iPhone-only app on iPad). Your UI must adapt to **any** scene size at runtime. iPhone Duo — two displays, a fold, bars on the side — builds on this model; see axiom-swiftui (skills/iphone-duo.md).

#### Stop reading the screen and the idiom

| Don't (wrong in resizable / external-display contexts) | Do |
|---|---|
| `UIScreen.main` | `window.windowScene?.screen` |
| `screen.scale` | `traitCollection.displayScale` |
| `screen.bounds` | the view's own `bounds`, or `windowScene.effectiveGeometry.coordinateSpace.bounds` |
| `UIDevice.userInterfaceIdiom` for layout | **size classes** (`traitCollection.horizontalSizeClass`) |
| `supportedInterfaceOrientations` for layout | size classes — orientation is only a *preference* at 27 and is ignored in resizable environments |

`effectiveGeometry` (iOS 16) and the `windowScene(_:didUpdateEffectiveGeometry:)` delegate (iOS 26) are the adaptive-geometry APIs to adopt — they predate 27, but 27 is where ignoring them breaks. `UIRequiresFullScreen` is now honored on iPhone but only enables *discrete* resizing that snaps to orientation-honoring configurations (for games); it no longer fully opts out of resizing.

```swift
override func layoutSubviews() {
    super.layoutSubviews()
    let displayScale = traitCollection.displayScale     // not UIScreen.main.scale
    // size from self.bounds, not the screen
}

func windowScene(_ windowScene: UIWindowScene,
                 didUpdateEffectiveGeometry previous: UIWindowScene.Geometry) {
    let bounds = windowScene.effectiveGeometry.coordinateSpace.bounds
}
```

#### Express preferences, not a fixed canvas

You no longer own a fixed canvas — you express preferences the user and system honor.

- **Minimum size** — the documented replacement for the old `UIRequiresFullScreen` opt-out (TN3192). Set it on the scene's `UISceneSizeRestrictions` so users can't shrink the window below a usable size:
  ```swift
  windowScene.sizeRestrictions?.minimumSize = CGSize(width: 400, height: 600)
  ```
- **Orientation lock** — a *preference*, not a guarantee, in resizable environments. Override `UIViewController.prefersInterfaceOrientationLocked` (returns `Bool`) and call `setNeedsUpdateOfPrefersInterfaceOrientationLocked()` when it changes; read the resolved state from `windowScene.effectiveGeometry.isInterfaceOrientationLocked` (iOS 26).
- **Requesting an orientation** — iPad refuses it under the windowing model. `windowScene.requestGeometryUpdate(.iOS(interfaceOrientations: .landscapeRight))` calls its `errorHandler` with `UISceneErrorDomain` code 101, "The current windowing mode does not allow for programmatic changes to interface orientation", and the scene keeps its size. The error handler is the only signal, so always pass one. The same request rotated an iPhone scene (measured on iPad Pro 11-inch and iPhone 17, iOS 27.0 simulators). On iPad, lay out for the size you're given instead of forcing an orientation.
- **Interactive vs settled resize** — `UIWindowSceneGeometry.isInteractivelyResizing` (iOS 26) is `true` while the user drags; throttle expensive work during the drag and settle when it clears. SwiftUI's equivalent is `.onInteractiveResizeChange(_:)` (see axiom-swiftui (skills/layout-ref.md)).

## iPhone Mirroring compatibility

Under iPhone Mirroring the app keeps running on the iPhone; the Mac supplies indirect mouse/trackpad/keyboard input and, from the 27 cycle, a freely resizable window. Standard UIKit and SwiftUI controls receive translated input correctly — the compatibility work is in custom gestures, biometric auth, and orientation assumptions.

#### The orientation trap

A mirrored app **always reports portrait interface orientation, regardless of the window's aspect ratio**. A landscape-shaped mirrored window is still "portrait". Never derive layout from `interfaceOrientation` — use size classes and the scene's `effectiveGeometry` (see the table above).

#### Indirect input reaches custom gestures differently

With `UIApplicationSupportsIndirectInputEvents` in effect (Info.plist key, iOS 13.4; treated as enabled when built against iOS 17+ SDKs):

- Pointer clicks arrive as `UITouch` of type `.indirectPointer`, not `.direct`.
- Trackpad pinch and rotate arrive as `UIEvent.EventType.transform` events that drive **only** `UIPinchGestureRecognizer` and `UIRotationGestureRecognizer`. For these events `numberOfTouches` is `0` and `location(ofTouch:in:)` raises — a custom recognizer that reads individual touches must detect non-touch events first (e.g. in `shouldReceive(_:)`).
- Scroll input is not touch: `allowedScrollTypesMask` (iOS 13.4) controls which scroll types a custom pan recognizer receives. `.discrete` is wheel-mouse scrolling, `.continuous` is trackpad — Mirroring users bring either device, so set `.all` explicitly:
  ```swift
  panRecognizer.allowedScrollTypesMask = .all   // wheel mice AND trackpads
  ```
  `UIScrollView` handles both automatically; this is only for custom pan handling.

#### Biometric auth needs a companion path

Biometric requests fail by default under Mirroring — the iPhone's Face ID/Touch ID sensors are not accessible from the Mac (TN3210). Use the companion-capable Local Authentication policy (iOS 18) so people can approve on the Mac (or a paired Apple Watch) instead:

```swift
let context = LAContext()
try await context.evaluatePolicy(
    .deviceOwnerAuthenticationWithBiometricsOrCompanion,
    localizedReason: "Unlock your vault")
```

With no companion nearby it behaves exactly like `.deviceOwnerAuthenticationWithBiometrics`, so it is safe as the default policy. On iOS the companion types are the Mac (iOS 18) and Vision Pro (iOS 26) — `LACompanionType` has no Watch case on iOS. A companion-only request with no companion available throws `LAError.companionNotAvailable`. For keychain items gated by `SecAccessControl`, add the `.companion` flag (iOS 18) alongside biometry — see axiom-security (skills/keychain.md).

#### Drag and drop crosses devices

Standard drag interactions (`UIDragInteraction`/`UIDropInteraction`, SwiftUI `Transferable`) participate in iPhone↔Mac drag and drop automatically (iOS 18.1/macOS 15.1). No Mirroring-specific API exists — apps that already implement standard drag and drop get the cross-device behavior for free. See axiom-swift (skills/transferable-ref.md).

#### Test it for real

Iterate with `devicectl device appResize` — scriptable, so breakpoints can be swept and asserted automatically (see axiom-tools (skills/device-control-ref.md)) — or by hand in Device Hub's resizable simulator. Then validate in **actual iPhone Mirroring on macOS 27**; Apple's guidance is resizable simulator first, real devices and Mirroring to confirm. TN3210's checklist includes verifying that pinch, rotate, and scroll gestures work with a trackpad or mouse.

## Desktop-class input — pointer, hardware keyboard, Pencil

The same environments that resize your windows also bring pointers, hardware keyboards, and (on iPad) the Pencil. UIKit's opt-in surface:

- **Pointer effects** — `UIPointerInteraction` (iOS 13.4) gives views the system hover treatment; return a `UIPointerStyle` from the delegate to shape the region. `UIHoverGestureRecognizer` (iOS 13) tracks pointer movement over a view (plus Pencil hover `zOffset` from iOS 16.1).
- **Key commands** — register `UIKeyCommand`s on responders (or via `UIMenuBuilder`, which doubles as the iPad menu bar). The iPad hold-⌘ shortcut HUD shows each command's `discoverabilityTitle`, falling back to its `title`; a command with neither is invisible to discovery.
- **Scribble** — Pencil handwriting into text fields is automatic for anything conforming to `UITextInput` (iOS 14, iPad): `UITextField`, `UITextView`, SwiftUI `TextField` all work with zero code. The work is only at the edges: `UIScribbleInteraction` (delegate) disables or tunes writing per view — e.g. suppress it on a field with a custom input view; `UIIndirectScribbleInteraction` makes UI that doesn't *look* like a text field writable (a tap-to-edit title, a canvas that should accept handwritten labels) by vending virtual writable "elements". A custom text editor must conform to `UITextInput` to participate at all.
- SwiftUI equivalents (`onHover`, `hoverEffect`, `keyboardShortcut`) live in axiom-swiftui (skills/gestures.md Pattern 8).

```swift
button.addInteraction(UIPointerInteraction(delegate: self))

override var keyCommands: [UIKeyCommand]? {
    let find = UIKeyCommand(input: "f", modifierFlags: .command,
                            action: #selector(focusSearch))
    find.discoverabilityTitle = "Find"
    return [find]
}
```

## Navigation bar titles and subtitles (iOS 26)

`UINavigationItem` gained a subtitle, attributed titles, and separate content under the large title. Apple's Mail example puts the unread count in `subtitle` and, while filtering, a filter button in `largeSubtitleView`:

```swift
navigationItem.title = "Inbox"
navigationItem.subtitle = "49 Unread"
navigationItem.largeSubtitleView = filterButton
```

| Slot | String | Attributed (beats string) | Custom view (beats both) | When all are nil |
|---|---|---|---|---|
| Inline title | `title` | `attributedTitle` | `titleView` | no title |
| Inline subtitle | `subtitle` | `attributedSubtitle` | `subtitleView` | no subtitle |
| Large title | `largeTitle` | — | — | uses `title` |
| Large subtitle | `largeSubtitle` | `largeAttributedSubtitle` | `largeSubtitleView` | falls back to the `subtitle` string |

In Swift the attributed properties are `AttributedString?`. When `titleView` is non-nil, `attributedSubtitle` is ignored too. Everything except `title`/`titleView` is iOS 26 and unavailable on tvOS, watchOS, and visionOS.

Verified on iPhone, iOS 26.5 and 27.0:
- **`largeSubtitleTextAttributes` is ignored.** A foreground color in it had no effect whether set on the item's appearances, the bar's, or `UINavigationBar.appearance()`; the large subtitle took `subtitleTextAttributes`, even with `largeSubtitle` set. Style it with `largeAttributedSubtitle`, and the inline bar with `attributedSubtitle`; both render their attributes. Prefer attributed strings to appearance objects anyway, since the new design asks apps to drop bar background customization.
- **`largeSubtitleView` disappears when the bar collapses**, and the inline bar shows `subtitle`. Set `subtitle` too when the status must survive scrolling.
- **A `UIButton` in `largeSubtitleView` renders centered.** Set `contentHorizontalAlignment = .leading` and zero `contentInsets` in its configuration to align it under the large title.
- **Custom views win their slot even when empty.** A leftover `UIView()` in `subtitleView` or `largeSubtitleView` silently hides that slot's string. To remove a subtitle, nil every variant.
- **Subtitles need the new design.** Nothing renders in the compatibility mode `UIDesignRequiresCompatibility` requests, which applies on iOS 26.x and, for apps still built with the 26 SDK, on iOS 27 (axiom-design (skills/liquid-glass.md)). Before 26 or in compatibility mode, compose a two-line `titleView`, and set it only on that path, because a non-nil `titleView` replaces the native title. There is no runtime check for compatibility mode, so decide by build: a 27-SDK app that keeps the key sets `subtitle` only under `#available(iOS 27, *)` and the `titleView` on 26.x; a 26-SDK app with the key uses the `titleView` on every OS.

Large titles now sit at the top of the scroll view and scroll with the content. Extend the scroll view fully under the navigation bar so the large title stays visible.

SwiftUI peers (`.navigationSubtitle` plus the `.title`, `.subtitle`, `.largeTitle`, and `.largeSubtitle` toolbar placements) are in axiom-swiftui (skills/toolbars.md) Pattern 14.

## New 27 additive APIs

| API | Scope | Use |
|-----|-------|-----|
| `UITabBarController.prominentTabIdentifier` | `iOS27`/`visionOS27` | mark one tab always-visible/prominent |
| `UITabBarControllerSidebar.preferredPlacement` (`.sidebar`) + `Placement` | `iOS27`/`visionOS27` | iPhone can now opt a tab bar into a sidebar (the `sidebar` object itself is iOS 18) |
| `UINavigationItem.navigationBarMinimization` (`UIBarMinimization`: `minimizationBehavior`/`safeAreaAdjustment`/`restorationBehavior`) | `iOS27` — types also tvOS/visionOS, but see below | control how the nav bar minimizes on scroll; SwiftUI peers are the `toolbarMinimization*` modifiers — see axiom-swiftui (skills/toolbars.md) Pattern 12 |
| `UIMenuElement.preferredImageVisibility` | `iOS27` | Liquid Glass may hide menu images by default; opt an item back in |
| `CMMotionManager.deviceMotionBody` | `iOS27`/`watchOS27`/`visionOS27` | assign a `UIView` as the motion reference frame (Body protocols) |
| `CLLocationManager.headingBody` | `iOS27`/`macOS27`/`watchOS27` | replaces the deprecated `headingOrientation` |
| `UITraitCollection.systemPrefersReducedResourceUsage` (+ `UITraitSystemPrefersReducedResourceUsage`, `.systemPrefersReducedResourceUsageDidChange`) | `iOS27`/`tvOS27`/`visionOS27` | system asks the app to cut discretionary work under resource pressure — react via `registerForTraitChanges`; see `axiom-performance (energy.md)` for the response playbook |

`UIView` conforms to the CoreMotion/CoreLocation Body protocols, so you set `motionManager.deviceMotionBody = view` / `locationManager.headingBody = view` directly.

#### Nav bar minimization in depth `OS27`

In Swift `UIBarMinimization` is a **struct** (the ObjC class is refined for Swift), read and written through `UINavigationItem.navigationBarMinimization`:

```swift
item.navigationBarMinimization.minimizationBehavior = .onScrollDown
item.navigationBarMinimization.restorationBehavior = .atScrollEdge
item.navigationBarMinimization.safeAreaAdjustment = .enabled
```

| Property | Values | Effect |
|---|---|---|
| `minimizationBehavior` | `.automatic`, `.never`, `.onScrollDown`, `.onScrollUp` | whether, and in which scroll direction, the bar minimizes |
| `safeAreaAdjustment` | `.automatic`, `.enabled`, `.disabled` | `.enabled` lets content reflow into the freed space; `.disabled` keeps the safe area fixed |
| `restorationBehavior` | `.automatic`, `.atScrollEdge` | `.automatic` restores when the user reverses scroll direction; `.atScrollEdge` only when content reaches the scroll edge |

- **`.atScrollEdge` is *currently* honored only alongside `.onScrollDown`.** Apple's wording is "Currently this is only honored alongside…", so treat it as present behavior rather than a guarantee. With any other minimization behavior the system silently falls back to `.automatic` — pairing it with `.onScrollUp` is a no-op, not an error.
- The system already selects `.atScrollEdge` on its own for navigation items whose `preferredSearchBarPlacement` is `.integratedCentered` (iOS 26).
- Minimizing the navigation bar also minimizes an **integrated top tab bar**. Only the navigation bar supports customizing `safeAreaAdjustment`.
- **The three types are iOS/tvOS/visionOS 27, but every case except `.automatic` is iOS-only** — explicitly unavailable on tvOS, visionOS and watchOS. A shared helper that assigns `.onScrollDown` fails to compile for tvOS (`'onScrollDown' is unavailable in tvOS`), so gate the assignment itself, not just the property access.

## Apple Intelligence touchpoints

Menus gain an automatic "Ask Siri" affordance, and UIKit adds a View Annotations API to annotate views with `AppEntity`s for Siri context (see WWDC 2026-278). If you support drag and drop, Siri may load resources via your drag handlers — avoid animations/modal UI in `sessionWillBegin` (a drag can start without a gesture); put stateful drag UI in `sessionDidMove`.

## Let Xcode do the mechanical migration

Xcode 27 ships an app-modernization agent skill that rewrites `UIScreen.main` calls → `traitCollection`/scene bounds, orientation checks → size classes, and can migrate to the scene life cycle. Export the skill for other tools with `xcrun agent skills export`. See `axiom-xcode-mcp` for the agentic-Xcode workflow. Xcode 27.1 extends this skill to SwiftUI and iPhone Duo under a new name — see axiom-swiftui (skills/iphone-duo.md, Tooling and Testing).

## Resources

**WWDC**: 2025-243, 2025-284, 2026-278

**Docs**: /uikit/app-and-environment, /uikit/uiscenedelegate, /uikit/uiwindowscene, /uikit/uiscenesizerestrictions, /uikit/transitioning-to-the-uikit-scene-based-life-cycle, /uikit/uitabbarcontroller, /uikit/uitabbarcontrollersidebar, /uikit/uimenuelement, /technotes/tn3192-migrating-your-app-from-the-deprecated-uirequiresfullscreen-key, /technotes/tn3210-optimizing-your-app-for-iphone-mirroring, /technotes/tn3208-preparing-your-apps-launch-screen-to-meet-app-store-requirements, /bundleresources/information-property-list/uiapplicationscenemanifest, /bundleresources/information-property-list/uilaunchscreen, /bundleresources/information-property-list/uiapplicationsupportsindirectinputevents, /uikit/uipangesturerecognizer/allowedscrolltypesmask, /localauthentication/lapolicy, /uikit/drag-and-drop, /uikit/uiscribbleinteraction, /uikit/uiindirectscribbleinteraction, /uikit/uiresponder/undomanager, /uikit/uibarminimization, /uikit/uinavigationitem/navigationbarminimization, /uikit/uinavigationitem/subtitle, /uikit/uinavigationitem/largesubtitleview, /uikit/customizing-your-app-s-navigation-bar, /uikit/uisceneaccessory, /uikit/uisceneaccessoryregistration

**Skills**: skills/uikit-bridging.md, axiom-xcode-mcp, axiom-swiftui (size-class-driven adaptive layout), axiom-swiftui (skills/toolbars.md), axiom-security (skills/keychain.md), axiom-swift (skills/transferable-ref.md)
