
# Photo Library API Reference

## Quick Reference

```swift
// SWIFTUI PHOTO PICKER (iOS 17+)
import PhotosUI

@State private var item: PhotosPickerItem?

PhotosPicker(selection: $item, matching: .images) {
    Text("Select Photo")
}
.onChange(of: item) { _, newItem in
    Task {
        if let data = try? await newItem?.loadTransferable(type: Data.self) {
            // Use image data
        }
    }
}

// UIKIT PHOTO PICKER (iOS 14+)
var config = PHPickerConfiguration()
config.selectionLimit = 1
config.filter = .images
let picker = PHPickerViewController(configuration: config)
picker.delegate = self

// SAVE TO CAMERA ROLL
try await PHPhotoLibrary.shared().performChanges {
    PHAssetCreationRequest.creationRequestForAsset(from: image)
}

// CHECK PERMISSION
let status = PHPhotoLibrary.authorizationStatus(for: .readWrite)
```

---

## PHPickerViewController (iOS 14+)

System photo picker for UIKit apps. No permission required.

### Configuration

```swift
import PhotosUI

var config = PHPickerConfiguration()

// Selection limit (0 = unlimited)
config.selectionLimit = 5

// Filter by asset type
config.filter = .images

// Use photo library (enables asset identifiers)
config = PHPickerConfiguration(photoLibrary: .shared())

// Preferred asset representation
config.preferredAssetRepresentationMode = .automatic  // default
// .current - original format
// .compatible - converted to compatible format

// Metadata stripping + search seeding (OS27; iOS/macOS/visionOS only)
config.metadataOptions = [.removeLocation, .removeCaptions]  // default []
config.searchText = PHPickerSearchText("beach sunset")
```

### Filter Options

```swift
// Basic filters
PHPickerFilter.images
PHPickerFilter.videos
PHPickerFilter.livePhotos

// Combined filters
PHPickerFilter.any(of: [.images, .videos])

// Exclusion filters (iOS 15+)
PHPickerFilter.all(of: [.images, .not(.screenshots)])
PHPickerFilter.not(.livePhotos)

// Playback style filters (iOS 16+)
PHPickerFilter.any(of: [.cinematicVideos, .slomoVideos])
```

### Presenting

```swift
let picker = PHPickerViewController(configuration: config)
picker.delegate = self
present(picker, animated: true)
```

### Delegate

```swift
extension ViewController: PHPickerViewControllerDelegate {

    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)

        for result in results {
            // Get asset identifier (if using PHPickerConfiguration(photoLibrary:))
            let identifier = result.assetIdentifier

            // Load as UIImage
            result.itemProvider.loadObject(ofClass: UIImage.self) { object, error in
                guard let image = object as? UIImage else { return }
                DispatchQueue.main.async {
                    self.displayImage(image)
                }
            }

            // Load as Data
            result.itemProvider.loadDataRepresentation(forTypeIdentifier: UTType.image.identifier) { data, error in
                guard let data else { return }
                // Use data
            }

            // Load Live Photo
            result.itemProvider.loadObject(ofClass: PHLivePhoto.self) { object, error in
                guard let livePhoto = object as? PHLivePhoto else { return }
                // Use live photo
            }
        }
    }
}
```

### PHPickerResult Properties

| Property | Type | Description |
|----------|------|-------------|
| `itemProvider` | NSItemProvider | Provides selected asset data |
| `assetIdentifier` | String? | PHAsset identifier (if using photoLibrary config) |

---

## PhotosPicker (SwiftUI, iOS 16+)

SwiftUI view for photo selection. No permission required.

### Basic Usage

```swift
import SwiftUI
import PhotosUI

// Single selection
@State private var selectedItem: PhotosPickerItem?

PhotosPicker(selection: $selectedItem, matching: .images) {
    Label("Select Photo", systemImage: "photo")
}

// Multiple selection
@State private var selectedItems: [PhotosPickerItem] = []

PhotosPicker(
    selection: $selectedItems,
    maxSelectionCount: 5,
    matching: .images
) {
    Text("Select Photos")
}
```

### Filters

```swift
// Images only
matching: .images

// Videos only
matching: .videos

// Images and videos
matching: .any(of: [.images, .videos])

// Live Photos
matching: .livePhotos

// Exclude screenshots (iOS 15+)
matching: .all(of: [.images, .not(.screenshots)])
```

### Selection Behavior

```swift
PhotosPicker(
    selection: $items,
    maxSelectionCount: 10,
    selectionBehavior: .ordered,  // .default, .ordered, .continuous
    matching: .images
) { ... }
```

| Behavior | Description |
|----------|-------------|
| `.default` | Standard multi-select |
| `.ordered` | Selection order preserved |
| `.continuous` | Live updates as user selects (iOS 17+) |

### Embedded Picker (iOS 17+)

```swift
PhotosPicker(
    selection: $items,
    maxSelectionCount: 10,
    selectionBehavior: .continuous,
    matching: .images
) {
    Text("Select")
}
.photosPickerStyle(.inline)  // Embed in view hierarchy
.photosPickerDisabledCapabilities([.selectionActions])
.photosPickerAccessoryVisibility(.hidden, edges: .all)
```

| Style | Description |
|-------|-------------|
| `.presentation` | Modal sheet (default) |
| `.inline` | Embedded in view |
| `.compact` | Single row |

| Disabled Capability | Effect |
|---------------------|--------|
| `.search` | Hide search bar |
| `.collectionNavigation` | Hide albums |
| `.stagingArea` | Hide selection review |
| `.selectionActions` | Hide Add/Cancel |

| Accessory Visibility | Description |
|----------------------|-------------|
| `.hidden`, `.automatic`, `.visible` | Per edge |

### HDR Preservation (iOS 16+)

```swift
PhotosPicker(
    selection: $items,
    matching: .images,
    preferredItemEncoding: .current  // Don't transcode, preserve HDR
) { ... }
```

| Encoding | Description |
|----------|-------------|
| `.automatic` | System decides format |
| `.current` | Original format, preserves HDR |
| `.compatible` | Force compatible format |

### Picker Modifiers `OS27`

iOS/macOS/visionOS 27 only — unavailable on tvOS/watchOS.

```swift
.photosPickerMetadataOptions([.removeLocation, .removeCaptions])
.photosPickerSearchText("beach sunset")          // String overload
.photosPickerSearchText(PHPickerSearchText(...)) // typed overload
```

| API | Type | Default |
|---|---|---|
| `PHPickerMetadataOptions` | OptionSet: `.removeLocation`, `.removeCaptions` (`.none` is unavailable in Swift — use `[]`) | `[]` |
| `PHPickerSearchText` | `init(_ string: String)` | `nil` |
| `PHPickerConfiguration.Update.searchText` | live update via `updatePicker(using:)` | `nil` |

### Shared Album Sheets `OS27`

```swift
.photosSharedAlbumCreationSheet(isPresented:defaultTitle:defaultSharingPolicy:photoLibrary:onCompletion:)
.photosSharedAlbumPostingSheet(isPresented:items:defaultAlbumIdentifier:photoLibrary:completion:)
.photosSharedAlbumCustomizationSheet(isPresented:albumIdentifier:photoLibrary:onCompletion:)
```

| Type | Members |
|---|---|
| `PHSharedAlbumCreationResult` | `albumIdentifier: String?`, `albumURL: URL?`, `error: (any Error)?` |
| `PHSharedAlbumCreationSharingPolicy` | `.private` (default, approval required), `.public` |
| `PHSharedAlbumCreationConfiguration` | `photoLibrary`, `defaultTitle`, `defaultPolicy` |

Completion types: creation → `PHSharedAlbumCreationResult?`; posting → `Result<String, any Error>`; customization → `(Error?) -> Void`. Cancel fires no completion on creation and customization (posting is undocumented). UIKit equivalents: `PHSharedAlbumCreationViewController`, `PHSharedAlbumPostingViewController`, `PHSharedAlbumCustomizationViewController` — none self-dismiss.

Deprecated in 27: `postToPhotosSharedAlbumSheet` (iOS 26.0) → `photosSharedAlbumPostingSheet`. Two breaks: `photoLibrary:` and `defaultAlbumIdentifier:` swap order, and the completion type changes `Result<Void, _>` → `Result<String, _>`.

### Apple Reference Image `OS27`

iOS/macOS 27 only — unavailable on tvOS/watchOS/visionOS. Detects and displays images carrying Apple Reference Image data (HEIC, JPEG, or DNG on disk, or a library asset).

```swift
let info = PHReferenceImageInfo(asset: asset)      // or PHReferenceImageInfo(fileURL:)
if await Task.detached(operation: { info.imageContainsReferenceImageData }).value { selection = asset }

// Non-nil binding presents the viewer; the closure delivers the processing result
.photosReferenceImageViewer(asset: $selection) { (result: Result<PHAsset, any Error>) in }
```

| Modifier | Binding | Completion |
|---|---|---|
| `photosReferenceImageViewer(asset:onProcessingCompletion:)` | `Binding<PHAsset?>` | `Result<PHAsset, any Error>` |
| `photosReferenceImageViewer(pickerItem:onProcessingCompletion:)` | `Binding<PhotosPickerItem?>` | `Result<PHAsset, any Error>` |
| `photosReferenceImageViewer(pickerResult:onProcessingCompletion:)` | `Binding<PHPickerResult?>` | `Result<PHAsset, any Error>` |
| `photosReferenceImageViewer(fileURL:onProcessingCompletion:)` | `Binding<URL?>` | `Result<URL, any Error>` |

`imageContainsReferenceImageData` reads image metadata on **first access** — Apple's own guidance is to wrap it in a `Task` rather than block the main thread. Hide any "show reference image" affordance when it returns `false`; it also always returns `false` for iPad apps on visionOS.

### Loading Images from PhotosPickerItem

```swift
// Load as Data (most reliable)
if let data = try? await item.loadTransferable(type: Data.self),
   let image = UIImage(data: data) {
    // Use image
}

// Custom Transferable for direct UIImage
struct ImageTransferable: Transferable {
    let image: UIImage

    static var transferRepresentation: some TransferRepresentation {
        DataRepresentation(importedContentType: .image) { data in
            guard let image = UIImage(data: data) else {
                throw TransferError.importFailed
            }
            return ImageTransferable(image: image)
        }
    }
}

// Usage
if let result = try? await item.loadTransferable(type: ImageTransferable.self) {
    let image = result.image
}
```

### PhotosPickerItem Properties

| Property | Type | Description |
|----------|------|-------------|
| `itemIdentifier` | String? | Unique identifier |
| `supportedContentTypes` | [UTType] | Available representations |

### PhotosPickerItem Methods

```swift
// Load transferable
func loadTransferable<T: Transferable>(type: T.Type) async throws -> T?

// Load with progress
func loadTransferable<T: Transferable>(
    type: T.Type,
    completionHandler: @escaping (Result<T?, Error>) -> Void
) -> Progress
```

---

## PHPhotoLibrary

Access and modify the photo library.

### Authorization Status

```swift
// Check current status
let status = PHPhotoLibrary.authorizationStatus(for: .readWrite)

// Request authorization
let newStatus = await PHPhotoLibrary.requestAuthorization(for: .readWrite)
```

### PHAuthorizationStatus

| Status | Description |
|--------|-------------|
| `.notDetermined` | User hasn't been asked |
| `.restricted` | Parental controls limit access |
| `.denied` | User denied access |
| `.authorized` | Full access granted |
| `.limited` | Access to user-selected photos only (iOS 14+) |

### Access Levels

```swift
// Read and write
PHPhotoLibrary.requestAuthorization(for: .readWrite)

// Add only (save photos, no reading)
PHPhotoLibrary.requestAuthorization(for: .addOnly)
```

### Limited Library Picker

```swift
// Present picker to expand limited selection
@MainActor
func presentLimitedLibraryPicker(from viewController: UIViewController) {
    PHPhotoLibrary.shared().presentLimitedLibraryPicker(from: viewController)
}

// With completion handler
PHPhotoLibrary.shared().presentLimitedLibraryPicker(from: viewController) { identifiers in
    // identifiers: asset IDs user added
}
```

### Performing Changes

Change blocks run on **PhotoKit's own serial queue**. `performChanges` takes a `dispatch_block_t`, which imports as non-`Sendable`, so a bare block written inside a `@MainActor` type inherits that isolation and traps at runtime. Mark the block `@Sendable` whenever the enclosing context is isolated — the snippets below and elsewhere in this file omit it only because they sit at file scope. See axiom-concurrency (skills/isolation-inheritance-diag.md).

```swift
// Async changes
try await PHPhotoLibrary.shared().performChanges { @Sendable in
    // Create, update, or delete assets
}

// With completion handler
PHPhotoLibrary.shared().performChanges({ @Sendable in
    // Changes
}) { success, error in
    // Handle result
}
```

### Change Observer

The callback arrives on an **arbitrary serial queue**. On a `@MainActor` type the method must be `nonisolated` — see axiom-concurrency (skills/isolation-inheritance-diag.md) for why `@preconcurrency` and isolated conformance build clean and crash.

```swift
@MainActor
final class PhotoObserver: NSObject, PHPhotoLibraryChangeObserver {

    private var fetchResult = PHAsset.fetchAssets(with: .image, options: nil)

    override init() {
        super.init()
        PHPhotoLibrary.shared().register(self)
    }

    deinit {
        PHPhotoLibrary.shared().unregisterChangeObserver(self)
    }

    nonisolated func photoLibraryDidChange(_ changeInstance: PHChange) {
        Task { @MainActor in
            guard let changes = changeInstance.changeDetails(for: self.fetchResult) else { return }
            self.fetchResult = changes.fetchResultAfterChanges
        }
    }
}
```

### Persistent Change History Observer `OS27`

`PHPhotoLibraryChangeObserver` (above) reports changes only while your process is running. The change-history API (`fetchPersistentChanges(since:)`, iOS 16) survives launches but had to be polled; the 27 observer pushes a notification when history advances. Requires read-write authorization.

**Registration imports as `register(_:)` — an overload of the `PHPhotoLibraryChangeObserver` one.** Only the unregister keeps a distinct name, `unregisterPersistentChangesObserver(_:)`. A type conforming to **both** protocols cannot just call `register(self)` twice — it converts to both existentials, so the call fails outright with `error: ambiguous use of 'register'`. Disambiguate at the call site: `register(self as any PHPhotoLibraryPersistentChangesObserver)`, and `as any PHPhotoLibraryChangeObserver` for the in-process channel.

```swift
@available(anyAppleOS 27, *)
@available(watchOS, unavailable)
@MainActor
final class LibraryHistoryObserver: NSObject, PHPhotoLibraryPersistentChangesObserver {
    private var token: PHPersistentChangeToken

    override init() {
        token = PHPhotoLibrary.shared().currentChangeToken
        super.init()
        PHPhotoLibrary.shared().register(self)
    }

    deinit { PHPhotoLibrary.shared().unregisterPersistentChangesObserver(self) }

    nonisolated func photoLibraryPersistentChangesDidUpdate(_ photoLibrary: PHPhotoLibrary) {
        Task { @MainActor in
            do {
                for change in try photoLibrary.fetchPersistentChanges(since: self.token) {
                    self.token = change.changeToken
                }
            } catch PHPhotosError.persistentChangeTokenExpired {
                self.token = photoLibrary.currentChangeToken
            } catch {
                assertionFailure("fetchPersistentChanges failed: \(error)")
            }
        }
    }
}
```

| Gotcha | Consequence |
|---|---|
| Observer is held **weakly** | register a long-lived object or callbacks stop silently |
| Callback runs on an arbitrary serial queue | same `nonisolated` + hop rule as `photoLibraryDidChange` above |
| `PHPersistentChangeFetchResult` is refined into a Swift `Sequence` | iterate with `for`-`in`; `enumerateChanges` does not exist in Swift |
| Token not advanced to each `change.changeToken` | the same history replays forever |
| Token the library has dropped | throws `PHPhotosError.persistentChangeTokenExpired` |

An expired token leaves no delta to apply. Apple documents the condition but prescribes no recovery — `PHError`'s comment says only that the token "refers to a library state that is older than the available history of persistent changes" — so treat the remedy as the sound consequence rather than stated behavior: re-baseline from `currentChangeToken` and refetch what you display. Persist the token across launches — that is the entire point of this API over the in-process observer.

---

## Sendability

These types carry `NS_SWIFT_SENDABLE` in the SDK (verified iOS 26 and 27) and cross isolation boundaries without a diagnostic:

| Type | Sendable |
|------|----------|
| `PHAsset`, `PHObject`, `PHObjectPlaceholder` | yes |
| `PHFetchResult`, `PHChange`, `PHPhotoLibrary` | yes |
| `PHImageManager`, `PHCollection`, `PHAssetCollection` | yes |

**Do not add `@unchecked Sendable` boxes or `@retroactive` conformances for these.** The conformance already exists. Note the compiler does NOT block either shape (verified by compile):

| Shape | Diagnostic |
|-------|------------|
| `extension PHObject: @retroactive @unchecked Sendable {}` | warning — "conformance … already stated in the type's module 'Photos'"; builds, module's conformance wins |
| `struct Box: @unchecked Sendable { let c: PHChange }` | **none** — compiles silently |

So it merges, becomes house style, and normalizes `@unchecked` for the next type that genuinely needs checking. This is a common wrong reflex — LLM baselines invent these boxes unprompted because the annotations postdate most training data.

Re-fetching by `localIdentifier` is still often right, but for **staleness** (a `PHAsset` is a snapshot; one held across library changes can target the wrong state) — never for isolation. See axiom-concurrency (skills/isolation-inheritance-diag.md).

## PHAsset

Represents an asset in the photo library.

### Fetching Assets

```swift
// All photos
let allPhotos = PHAsset.fetchAssets(with: .image, options: nil)

// With options
let options = PHFetchOptions()
options.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
options.fetchLimit = 100
options.predicate = NSPredicate(format: "mediaType == %d", PHAssetMediaType.image.rawValue)

let recentPhotos = PHAsset.fetchAssets(with: options)

// By identifier
let assets = PHAsset.fetchAssets(withLocalIdentifiers: [identifier], options: nil)
```

### Asset Properties

| Property | Type | Description |
|----------|------|-------------|
| `localIdentifier` | String | Unique ID |
| `mediaType` | PHAssetMediaType | `.image`, `.video`, `.audio` |
| `mediaSubtypes` | PHAssetMediaSubtype | `.photoLive`, `.photoPanorama`, etc. |
| `pixelWidth` | Int | Width in pixels |
| `pixelHeight` | Int | Height in pixels |
| `creationDate` | Date? | When taken |
| `modificationDate` | Date? | Last modified |
| `location` | CLLocation? | GPS location |
| `duration` | TimeInterval | Video duration |
| `isFavorite` | Bool | Marked as favorite |
| `isHidden` | Bool | In hidden album |

### PHAssetMediaType

| Type | Value |
|------|-------|
| `.unknown` | 0 |
| `.image` | 1 |
| `.video` | 2 |
| `.audio` | 3 |

### PHAssetMediaSubtype

| Subtype | Description |
|---------|-------------|
| `.photoPanorama` | Panoramic photo |
| `.photoHDR` | HDR photo |
| `.photoScreenshot` | Screenshot |
| `.photoLive` | Live Photo |
| `.photoDepthEffect` | Portrait mode |
| `.videoStreamed` | Streamed video |
| `.videoHighFrameRate` | Slo-mo video |
| `.videoTimelapse` | Timelapse |
| `.videoCinematic` | Cinematic mode |

---

## Asset Metadata Editing `OS27`

iOS/iPadOS/macOS/tvOS/visionOS 27. Photos ships no watchOS slice at all — there is no `Photos.framework` in the watchOS 27 SDK, so `import Photos` fails there outright and no availability guard changes that.

Keywords, rating, Live Photo playback, and the RAW/compressed original choice are **change-request** writes: they exist only on `PHAssetChangeRequest` and take effect only inside `performChanges`.

```swift
@available(anyAppleOS 27, *)
@available(watchOS, unavailable)
func editAsset(_ asset: PHAsset) async throws {
    try await PHPhotoLibrary.shared().performChanges { @Sendable in
        let request = PHAssetChangeRequest(for: asset)
        request.addKeyword("vacation")
        request.removeKeyword("draft")
        request.rating = .four
        request.setLivePhotoVideoPlaybackEnabled(false)
        request.revertAssetContent(to: .raw)
    }
}
```

| API | Where it lives | Notes |
|---|---|---|
| `addKeyword(_:)` / `removeKeyword(_:)` | `PHAssetChangeRequest` | adding a keyword already present, or removing one absent, is silently ignored |
| `rating` | `PHAssetChangeRequest` (settable), `PHAsset` (read) | `PHAsset.Rating`: `.unset`, `.one` … `.five` |
| `caption` | `PHAssetChangeRequest` (settable), `PHAssetExtendedMetadata` (read) | writable in 27 — `nil` or an empty string clears it |
| `setLivePhotoVideoPlaybackEnabled(_:)` | `PHAssetChangeRequest` | `false` makes a Live Photo present as a still; Live Photos only |
| `revertAssetContent(to:)` | `PHAssetChangeRequest` | RAW+JPEG only; unsupported on other asset types |
| `originalResourceChoice` | `PHAsset` (read), `PHAssetCreationRequest` and `PHContentEditingInputRequestOptions` (settable) | **not** on `PHAssetChangeRequest` — the compiler rejects it there |

`revertAssetContent(to:)` is not `revertAssetContentToOriginal()` plus a flag. Beyond reverting adjustments it selects which original — `.raw` or `.compressed` — becomes the unadjusted base for every later render. Apple states the local-originals requirement on the older `revertAssetContentToOriginal()`: download originals with `PHAssetResourceManager` before either call.

Reading keywords back needs `PHAssetExtendedMetadata` (`OS27`). `keywords` is **not** a `PHAsset` property:

```swift
@available(anyAppleOS 27, *)
@available(watchOS, unavailable)
func read(_ asset: PHAsset) -> ([String], String?, PHAsset.Rating, PHAsset.OriginalResourceChoice) {
    let meta = asset.extendedMetadata
    return (meta.keywords, meta.caption, asset.rating, asset.originalResourceChoice)
}
```

`extendedMetadata` (`caption`, `originalFilename`, `keywords`) fetches on demand for each asset. For a grid or any batch, prefetch it in the same fetch instead of paying that per row:

```swift
@available(anyAppleOS 27, *)
@available(watchOS, unavailable)
func prefetch() -> PHFetchResult<PHAsset> {
    let options = PHFetchOptions()
    options.prefetchAssetExtendedMetadata = true
    return PHAsset.fetchAssets(with: .image, options: options)
}
```

---

## Collections and Identifiers `OS27`

```swift
@available(anyAppleOS 27, *)
@available(watchOS, unavailable)
func rootFolder() -> PHCollectionList? {
    PHCollectionList.fetchCollectionLists(with: .folder, subtype: .rootFolder, options: nil).firstObject
}

@available(anyAppleOS 27, *)
@available(watchOS, unavailable)
func topLevel() -> PHFetchResult<PHCollection> {
    PHCollection.fetchTopLevelUserCollections(with: nil)
}
```

There is always exactly one root folder, and it refuses rename and delete. Fetching its *contents* is equivalent to the long-standing `PHCollection.fetchTopLevelUserCollections(with:)` — what the subtype adds is the list **object**, to hand to `fetchCollectionsInCollectionList(_:options:)` or to recognize the root while walking a hierarchy.

`localIdentifierMappings(forSynced:)` resolves cloud identifiers using **iCloud-synced records only**:

```swift
@available(anyAppleOS 27, *)
@available(watchOS, unavailable)
func resolveSynced(_ ids: [PHCloudIdentifier]) -> [String] {
    let mappings: [PHCloudIdentifier: Result<String, any Error>] =
        PHPhotoLibrary.shared().localIdentifierMappings(forSynced: ids)
    return mappings.values.compactMap { try? $0.get() }
}
```

The existing `localIdentifierMappings(for:)` falls back to **media-content matching** when a cloud identifier has not synced to this device, which can map one cloud identifier onto several local identifiers (`PHPhotosError.multipleIdentifiersFound`, 3202; the doc comment's `…MultipleLocalIdentifiersFound` does not exist). The 27 method skips that fallback — reach for it when a plausible-but-wrong match is worse than no match. Both are expensive; batch every lookup into one call rather than calling per identifier. The ObjC result wrapper `PHLocalIdentifierMapping` is `NS_REFINED_FOR_SWIFT` and never surfaces in Swift — you get `Result<String, any Error>`.

---

## PHAssetCreationRequest

Create new assets in the photo library.

### Creating from UIImage

```swift
try await PHPhotoLibrary.shared().performChanges {
    PHAssetCreationRequest.creationRequestForAsset(from: image)
}
```

### Creating from File URL

```swift
try await PHPhotoLibrary.shared().performChanges {
    PHAssetCreationRequest.creationRequestForAssetFromImage(atFileURL: imageURL)
}

// For video
try await PHPhotoLibrary.shared().performChanges {
    PHAssetCreationRequest.creationRequestForAssetFromVideo(atFileURL: videoURL)
}
```

### Creating with Resources

```swift
try await PHPhotoLibrary.shared().performChanges {
    let request = PHAssetCreationRequest.forAsset()

    // Add photo resource
    let options = PHAssetResourceCreationOptions()
    options.shouldMoveFile = true  // Move instead of copy

    request.addResource(with: .photo, fileURL: photoURL, options: options)

    // Set creation date
    request.creationDate = Date()

    // Set location
    request.location = CLLocation(latitude: 37.7749, longitude: -122.4194)
}
```

### Deferred Photo Proxy (iOS 17+)

Save camera proxy photos for background processing:

```swift
// From AVCaptureDeferredPhotoProxy callback
try await PHPhotoLibrary.shared().performChanges {
    let request = PHAssetCreationRequest.forAsset()

    // Use .photoProxy to trigger deferred processing
    request.addResource(with: .photoProxy, data: proxyData, options: nil)
}
```

| Resource Type | Description |
|---------------|-------------|
| `.photo` | Standard photo |
| `.video` | Video file |
| `.photoProxy` | Deferred processing proxy (iOS 17+) |
| `.adjustmentData` | Edit adjustments |

### Getting Created Asset

```swift
try await PHPhotoLibrary.shared().performChanges {
    let request = PHAssetCreationRequest.forAsset()
    request.addResource(with: .photo, fileURL: url, options: nil)

    // Get placeholder for later fetching
    let placeholder = request.placeholderForCreatedAsset
    // placeholder.localIdentifier available after changes complete
}
```

### Custom Albums

```swift
// Create a custom album
func getOrCreateAlbum(named title: String) async throws -> PHAssetCollection {
    // Check if album already exists
    let fetchOptions = PHFetchOptions()
    fetchOptions.predicate = NSPredicate(format: "title = %@", title)
    let existing = PHAssetCollection.fetchAssetCollections(with: .album, subtype: .any, options: fetchOptions)
    if let album = existing.firstObject { return album }

    // Create new album
    var placeholder: PHObjectPlaceholder?
    try await PHPhotoLibrary.shared().performChanges {
        let request = PHAssetCollectionChangeRequest.creationRequestForAssetCollection(withTitle: title)
        placeholder = request.placeholderForCreatedAssetCollection
    }
    guard let id = placeholder?.localIdentifier,
          let album = PHAssetCollection.fetchAssetCollections(withLocalIdentifiers: [id], options: nil).firstObject
    else { throw PhotoError.albumCreationFailed }
    return album
}

// Save photo to custom album
func saveToAlbum(_ image: UIImage, album: PHAssetCollection) async throws {
    try await PHPhotoLibrary.shared().performChanges {
        let assetRequest = PHAssetCreationRequest.creationRequestForAsset(from: image)
        guard let placeholder = assetRequest.placeholderForCreatedAsset,
              let albumRequest = PHAssetCollectionChangeRequest(for: album) else { return }
        albumRequest.addAssets([placeholder] as NSFastEnumeration)
    }
}
```

---

## CloudKit Server-Side Asset Export `OS27`

Export a photo-library asset directly into CloudKit — the CloudKit **server** copies it on save, with no local download/re-upload round-trip. This is the **producer** half; the CloudKit consumer (`CKAsset(importing:)`) and its data-safety edges live in axiom-data `cloudkit-ref` → "Server-side asset copy".

```swift
import CloudKit   // for CKAsset.ExportedAssetID

// All Apple platforms at 27 except watchOS (no producer there):
@available(anyAppleOS 27, *)
@available(watchOS, unavailable)
func exportedID(for resource: PHAssetResource) async throws -> CKAsset.ExportedAssetID {
    try await PHAssetResourceManager.default().exportedAssetID(for: resource)
}
```

- `PHAssetResource.dataSize: Int?` (`OS27`) reports the resource's byte size (nil when unknown) — gate or skip oversized exports before the round-trip.
- Requires network + a **cloud-enabled** photo library. A local-only library throws `PHPhotosError.requestNotSupportedForAsset` (3306). The call honors cancellation (`CancellationError`).
- **Apple doc bug (27.0b)**: the doc comment says to gate on `PHAssetResource.TypeGroup.coreComponents`, which does NOT exist anywhere in the 27 SDK. Gate on `PHAssetResourceType` and handle the throw — quoting the doc verbatim yields non-compiling code.
- The returned `ExportedAssetID` is device-bound and expires in days — hand it straight to `CKAsset(importing:)`; never persist or transmit it.

## Background Asset Resource Upload `OS27`

Host-app control of the `com.apple.photos.background-upload` extension. **iOS/iPadOS/macOS/Mac Catalyst** — explicitly unavailable on tvOS, visionOS, and watchOS, so a visionOS build fails with "is unavailable in visionOS", not a version warning. The APIs below are 27 with one exception: `uploadJobExtensionEnabled` itself dates to iOS 26.1. Requires full library access and the registered extension point.

```swift
@available(iOS 27, macOS 27, macCatalyst 27, *)
@available(tvOS, unavailable)
@available(visionOS, unavailable)
@available(watchOS, unavailable)
func configureUploads() throws {
    let library = PHPhotoLibrary.shared()

    let options = PHAssetResourceUploadJobOptions()
    options.preventsExpensiveNetworkAccess = true

    try library.enableUploadJobExtension(with: options)
    _ = library.uploadJobExtensionEnabled
    _ = library.uploadJobExtensionOptions

    try library.setUploadJobExtensionOptions(PHAssetResourceUploadJobOptions())
    try library.disableUploadJobExtension()
}
```

| API | Notes |
|---|---|
| `enableUploadJobExtension(with:)` | enables and applies options atomically, as one change; `nil` means defaults |
| `setUploadJobExtensionOptions(_:)` | a separate change afterward; pass a fresh `PHAssetResourceUploadJobOptions()` to reset to defaults |
| `disableUploadJobExtension()` | |
| `uploadJobExtensionOptions` | `nil` when the extension is disabled or the caller is unauthorized |
| `preventsExpensiveNetworkAccess` | `false` by default; `true` confines the service to Wi-Fi/Ethernet, never cellular |
| `PHAssetResource.assetResource(forUploadJob:)` | returns `nil` if the resource is gone; replaces `PHAssetResourceUploadJob.resource`, which is soft-deprecated on iOS and unavailable on macOS and Mac Catalyst |

The three configuration calls are ObjC `BOOL` + `NSError**`, so they import as `throws` — there is no `Bool` to test. `enableUploadJobExtension(with:)` supersedes `setUploadJobExtensionEnabled(_:)`, deprecated in 27 and iOS-only. On the extension side `PHBackgroundResourceUploadExtension` is likewise deprecated in favor of `PHBackgroundResourceUploadJobExtension` (`processJobs() async` returning `PHBackgroundResourceUploadProcessingResult`, `willTerminate() async`).

`PHAssetResourceUploadJob` itself is **not** new — it shipped in iOS 26.1. What 27 adds is the macOS/Mac Catalyst port plus the options and lifecycle APIs above.

---

## PHFetchResult

Ordered list of assets from a fetch.

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `count` | Int | Number of items |
| `firstObject` | T? | First item |
| `lastObject` | T? | Last item |

### Methods

```swift
// Access by index
let asset = fetchResult.object(at: 0)
let firstBySubscript = fetchResult[0]

// Get multiple
let assets = fetchResult.objects(at: IndexSet(0..<10))

// Iteration
fetchResult.enumerateObjects { asset, index, stop in
    // Process asset
    if shouldStop {
        stop.pointee = true
    }
}

// Check contains
let contains = fetchResult.contains(asset)
let index = fetchResult.index(of: asset)
```

---

## PHImageManager

Request images from assets.

### Request Image

```swift
let manager = PHImageManager.default()

let options = PHImageRequestOptions()
options.deliveryMode = .highQualityFormat
options.resizeMode = .exact
options.isNetworkAccessAllowed = true  // For iCloud photos

let targetSize = CGSize(width: 300, height: 300)

manager.requestImage(
    for: asset,
    targetSize: targetSize,
    contentMode: .aspectFill,
    options: options
) { image, info in
    guard let image else { return }

    // Check if this is the final image
    let isDegraded = (info?[PHImageResultIsDegradedKey] as? Bool) ?? false
    if !isDegraded {
        // Final high-quality image
    }
}
```

### PHImageRequestOptions

| Property | Type | Description |
|----------|------|-------------|
| `deliveryMode` | PHImageRequestOptionsDeliveryMode | Quality preference |
| `resizeMode` | PHImageRequestOptionsResizeMode | Resize behavior |
| `isNetworkAccessAllowed` | Bool | Allow iCloud download |
| `isSynchronous` | Bool | Synchronous request |
| `progressHandler` | Block | Download progress |
| `allowSecondaryDegradedImage` | Bool | Extra callback during deferred processing (iOS 17+) |

### Secondary Degraded Image (iOS 17+)

For photos undergoing deferred processing, get an intermediate quality image:

```swift
let options = PHImageRequestOptions()
options.allowSecondaryDegradedImage = true

// Callback order:
// 1. Low quality (immediate, isDegraded = true)
// 2. Medium quality (new, isDegraded = true) -- while processing
// 3. Final quality (isDegraded = false)
```

### Delivery Modes

| Mode | Description |
|------|-------------|
| `.opportunistic` | Fast thumbnail, then high quality |
| `.highQualityFormat` | Only high quality |
| `.fastFormat` | Only fast/degraded |

### Request Video

```swift
manager.requestAVAsset(forVideo: asset, options: nil) { avAsset, audioMix, info in
    guard let avAsset else { return }
    // Use AVAsset for playback
}

// Or export to file
manager.requestExportSession(
    forVideo: asset,
    options: nil,
    exportPreset: AVAssetExportPresetHighestQuality
) { session, info in
    session?.outputURL = outputURL
    session?.outputFileType = .mp4
    session?.exportAsynchronously { ... }
}
```

---

## PHChange

Represents changes to the photo library.

### Getting Change Details

```swift
// nonisolated — PhotoKit calls this on an arbitrary serial queue
nonisolated func photoLibraryDidChange(_ changeInstance: PHChange) {
    Task { @MainActor in
        guard let changes = changeInstance.changeDetails(for: self.fetchResult) else { return }

        // Assign the new fetch result BEFORE applying deltas, or the data
        // source and the batch update disagree
        self.fetchResult = changes.fetchResultAfterChanges

        guard changes.hasIncrementalChanges else {
            self.collectionView.reloadData()
            return
        }

        self.collectionView.performBatchUpdates {
            if let removed = changes.removedIndexes {
                self.collectionView.deleteItems(at: removed.map { IndexPath(item: $0, section: 0) })
            }
            if let inserted = changes.insertedIndexes {
                self.collectionView.insertItems(at: inserted.map { IndexPath(item: $0, section: 0) })
            }
            if let changed = changes.changedIndexes {
                self.collectionView.reloadItems(at: changed.map { IndexPath(item: $0, section: 0) })
            }
        }
    }
}
```

---

## Common Code Patterns

### Complete Photo Gallery View

```swift
import SwiftUI
import Photos
import PhotosUI

@MainActor
@Observable
final class PhotoGalleryViewModel {
    private(set) var assets: [PHAsset] = []
    private(set) var authorizationStatus: PHAuthorizationStatus = .notDetermined

    func requestAccess() async {
        authorizationStatus = await PHPhotoLibrary.requestAuthorization(for: .readWrite)

        if authorizationStatus == .authorized || authorizationStatus == .limited {
            fetchAssets()
        }
    }

    func fetchAssets() {
        let options = PHFetchOptions()
        options.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
        options.fetchLimit = 100

        let result = PHAsset.fetchAssets(with: .image, options: options)
        assets = result.objects(at: IndexSet(0..<result.count))
    }

    func expandLimitedAccess(from viewController: UIViewController) {
        PHPhotoLibrary.shared().presentLimitedLibraryPicker(from: viewController)
    }
}

struct PhotoGalleryView: View {
    @State private var viewModel = PhotoGalleryViewModel()

    var body: some View {
        Group {
            switch viewModel.authorizationStatus {
            case .authorized, .limited:
                PhotoGridView(assets: viewModel.assets)
            case .denied, .restricted:
                PermissionDeniedView()
            case .notDetermined:
                RequestAccessView {
                    Task { await viewModel.requestAccess() }
                }
            @unknown default:
                EmptyView()
            }
        }
        .task {
            await viewModel.requestAccess()
        }
    }
}
```

---

## Resources

**Docs**: /photosui/phpickerviewcontroller, /photosui/photospicker, /photos/phphotolibrary, /photos/phasset, /photos/phimagemanager

**Skills**: skills/photo-library.md, skills/camera-capture.md, axiom-concurrency/skills/isolation-inheritance-diag.md
