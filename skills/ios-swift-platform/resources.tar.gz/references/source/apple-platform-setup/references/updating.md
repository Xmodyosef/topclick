# Update the installed collection

Inspect the active installation's method, client scope, resolved paths, local
changes and observable provenance. A bundle receipt may name a commit; a selective
copy may expose only a source URL and folder hash. Record unknown revision data
explicitly. If adding missing dependencies to an unidentified copy, stage the
selected dependent set together from one reviewed source snapshot.

Preserve rollback and account for active consumers before activation. Zero leases
alone does not establish quiescence. Keep active/historical run grants unchanged;
fresh work needs fresh bindings. Do not require approval merely to wait.

## Inventory before reconciling

Before any update, removal or relink, run the read-only
[installed skill inventory](../../apple-development-health/references/health-matrix.md#installed-skill-inventory).
It needs a verifier that has `skill-inventory`; released verifiers from before
that command answer `Unknown command`. Build the verifier from the staged new
revision, in a folder outside every skill root (a fresh clone, or the
`git archive` export below), with `AGENT_HARNESS_ROOT` set to that copy's
`skills/agent-harness` and `APE` set as in
[Build and locate the verifier](../../agent-harness/references/swift-verification.md#build-and-locate-the-verifier).
A verifier built inside `~/.agents/skills` compares the copies beside it with
themselves, so it cannot verify them independently and reports them
`unverified`.

```sh
"$APE" skill-inventory --project '<repository>'
```

It covers both client roots, the deprecated `~/.codex/skills`, the project
roots, Xcode's agent roots, the global Skills CLI lock and each project's
`skills-lock.json`, and names each entry's ownership evidence. Build the
reconcile plan from it:

- Act only on entries the report attributes to the collection. `outdated`,
  `retired`, `split`, owned `broken` and `staleLock` entries each map to an
  exact command for the entry's installation method and scope (a
  project-scope install is updated or removed from that project, without
  `-g`), with a backup of anything removed. An `unlisted` entry needs the
  user's confirmation before removal. An `unverified` one needs an inspection
  of its `reason`: content that could not be compared, or a copy that no lock
  attributes to a repository (made without the Skills CLI, or installed from
  a local checkout, which the CLI records in a project's `skills-lock.json` as
  a path and in the global lock not at all). It changes only after the user
  confirms it is this installation.
- Never act on your own on an entry the report does not attribute to the
  collection. `reserved`, `foreign` and Apple entries, a `broken` link with no
  ownership evidence, Xcode's own folders (`__xcode`, the `xcode-integration`
  plug-in) and `CodingAssistant/AgentPlugins` are reported and left alone,
  except where the next bullet lets the person decide. A `reserved` Apple
  skill folder copied into a client root, or a link into an Apple export that
  no record lists, has one way out:
  [Retire an old export](apple-skill-exposure.md#retire-an-old-export).
  A `split` whose `occupiedBy` names a root is reported, not installed over.
- A `duplicate` that is not an owned stale copy and whose copies include no
  `reserved` one, and a `foreignSameName` outside `CodingAssistant/AgentPlugins`,
  are the person's decision, which setup can carry out; this covers another
  owner's skill installed twice, because the person decides for their own
  machine. A `duplicate` with a `reserved` copy is reported only, as
  [Apple skill exposure](apple-skill-exposure.md#apple-folders-are-foreign)
  requires. Keep these decisions out of the grouped approval and ask one entry at a
  time. Show
  the evidence first: each copy's root and resolved path, which copy each
  client loads, `equalContent` or a short diff against the collection copy,
  the `lock` detail and modification date. Offer: keep both; move the chosen
  copy to the backup folder; or, for a `foreignSameName`, keep it and leave
  the collection copy uninstalled there. Act only on that entry's explicit
  answer, and move rather than delete, recording the move for rollback. When
  the chosen copy is the collection's own lock-recorded install, back it up,
  then remove it with the Skills CLI from its scope with an explicit `-a`, so
  no `staleLock` is left.
- A `foreignSameName` in `CodingAssistant/AgentPlugins` is usually a stale
  import of a collection skill. Compare its `SKILL.md` with the current copy
  and, when it is stale, ask the person to remove it in Xcode › Settings ›
  Intelligence › Plug-ins. Do not edit that folder directly: Xcode keeps a
  `PluginsManifest.json` index beside the imports. Rerun the inventory after
  they confirm.
- Show the whole plan and get one explicit approval for the collection's own
  entries before running it. Remove
  with the Skills CLI only with an explicit `-a` for the affected clients.
- Rerun the inventory afterward; a remaining finding is reported, not retried
  in a loop.

## Skills CLI version

This collection's commands pin Skills CLI 1.5.23, the version they were tested
with: `npx skills@1.5.23`. It declares Node.js 22.20.0 or later
(`npm view skills@1.5.23 engines`), so check `node --version` first. On an
older Node, an unpinned `npx skills` silently resolves to 1.5.18, the newest
release whose engines still accept it. Do not use 1.5.18: when GitHub
rate-limits it, `update` prints `Failed to fetch tree` and then
`All global skills are up to date`, and exits 0. In 1.5.23 a check that fails
still ends with the same line after `Failed to check skills from …`, so read
the whole output and never take that line or the exit status as proof. A
later CLI is untested here; compare its `add --help` before using it.

## Skills CLI installations

Record the installation from the lock and the roots, not from `list`:

```sh
npx skills@1.5.23 --version
ls -la ~/.agents/skills "${CLAUDE_CONFIG_DIR:-$HOME/.claude}/skills"
LOCK="${XDG_STATE_HOME:+$XDG_STATE_HOME/skills}"; LOCK="${LOCK:-$HOME/.agents}/.skill-lock.json"
grep -A8 '"apple-platform-engineer"' "$LOCK"
```

The global lock is `$XDG_STATE_HOME/skills/.skill-lock.json` when
`XDG_STATE_HOME` is set, otherwise `~/.agents/.skill-lock.json`; a project
install records in the project's `skills-lock.json`. It holds each skill's
source, ref and folder hash, but not its clients. Take those from the roots:

- **Both clients** (`-a claude-code codex`): real folders in
  `~/.agents/skills`, which Codex reads, and a link to each in
  `~/.claude/skills` for Claude Code. `--copy`, or choosing copy at the
  prompt, gives each client its own real folders instead.
- **Claude Code alone:** real folders copied into `~/.claude/skills`, and no
  `~/.agents/skills` entry.
- **Codex alone:** real folders in `~/.agents/skills`.

Record the selected clients, installed names, global/project scope,
copy/link mode, and the lock's source and ref. `npx skills list -g` is not a
substitute: its `Agents` column names the clients the CLI detects on this
machine (Codex only while `$CODEX_HOME`, `~/.codex` or `/etc/codex` exists),
not the ones the install targeted; it never shows the ref; and it lists links
it did not make, such as a bundle's, as `Source: local`.

Do not use `update` (or `check`, which runs the same updater in 1.5.23) for
this collection. It re-invokes `add` for each skill with the lock's source
and ref and only `--skill <name> -g -y`, without the original `-a` or
`--copy`, so it installs for every client it detects, in link mode: a Codex-only install gained Claude Code links and a
Claude Code copy became links. It also keeps the lock's ref: a pinned install
(`owner/repo#<ref>`) checks and reinstalls that same ref, so a bare `update`
never moves past it.

Instead, stage and validate the intended source, retain the existing copy for
rollback, then rerun the original `add` with the same `-a` list, the same
names and the reviewed revision as `owner/repo#<ref>`. For the starter set in
a **global both-client** installation:

```sh
npx skills@1.5.23 add 'ShawnBaek/ai-workflow-apple-platform-engineer#<reviewed-tag>' -g -a claude-code codex \
  --skill apple-platform-engineer agent-harness apple-platform-setup \
  apple-development-health xcode-project-workflow xcodebuild core-simulator-health \
  apple-platform-ui xcode-preview-design apple-platform-testing screenshot \
  git-workflow code-review open-xcode-handoff
```

This rewrites each lock entry with the new ref and hash. Name the reviewed
revision by a tag or branch: the CLI clones with `git clone --branch`, which
refuses a bare commit SHA (`Remote branch <sha> not found`). Omit `#<ref>` to
take the default branch's current head and record no ref, after confirming
that head is the reviewed commit. Keep `-a` and names to what is installed,
always including `code-review`;
add `--copy` for a copy install, omit `-g` and run from the project for a
project install, and include shared dependencies that need the same
revision. Inspect the installation summary before confirming. The
[Skills CLI reference](https://github.com/vercel-labs/skills#available-options)
describes `add` options.

Do not reinstall from a local checkout path. The CLI records no global lock
entry for a local source, so the old GitHub entry, with its old ref and hash,
stays in place and no longer describes the copy; the inventory flags it. A
manually installed copy may be absent from CLI tracking, so an empty update
result is not proof that your active copy is current.

## Claude Code plugin

Claude Code installs the whole collection as one plugin from this repository's
marketplace. Codex and other agents keep the Skills CLI path above.

```sh
claude plugin marketplace add ShawnBaek/ai-workflow-apple-platform-engineer
claude plugin install apple-platform-engineer@apple-platform-engineer
```

The plugin also installs a PR gate hook that holds pull-request publication
until `code-review` approved the exact head, as
[PR delivery](../../git-workflow/references/pr-delivery.md) describes; Skills
CLI installs have no such hook. A session status hook shows you, and gives the
agent, the working directory's branch, upstream and worktree (warning when its
pull request already merged, and counting branches and worktrees that merged
pull requests left behind), each workspace or
project open in Xcode with its branch, the booted Simulators and Xcode Preview
devices (with a warning above the Simulator budget), the host's load,
memory and free storage (with a warning when overloaded or low) and the other
Claude and Codex sessions with transcript activity in the last 30 minutes (not
proof of live execution or writer ownership), at session start and with every
prompt; it reads Xcode through Automation, so allow that once when macOS asks.
On an overloaded or full host, a build, test run or Simulator boot (`xcodebuild`,
`swift build` or `swift test`, `simctl boot`, a `gate.sh`, or an Xcode MCP
build, test or run tool, or `DeviceInteractionInstallAndRun`) first asks you
whether to run it now or wait; in a
non-interactive run (`claude -p`) that question can stop the build. The same
hook asks you before an agent creates, clones, deletes or erases a Simulator,
shuts down every Simulator, or boots one more past the Simulator budget, as
[xcodebuild](../../xcodebuild/SKILL.md) describes. Heavy work an agent starts
in the background needs the plugin's deadline wrapper, and a turn that would end
while unbounded background work runs is sent back, as
[host resources](../../agent-harness/references/host-resources.md) describes. When Codex hands a task to
Claude, the status shows `Handoff waiting for Claude`, as
[session-handoff](../../session-handoff/SKILL.md) describes.
Skills load as `/apple-platform-engineer:<skill>`; a bare name works unless
another command owns it, so review is `/apple-platform-engineer:code-review`.
Pass `--scope project` to record the install in a project's
`.claude/settings.json` instead of for your user. Inside a session, use
`/plugin marketplace add` and `/plugin install`.

The plugin's version is the collection's `VERSION`, and each release has a
`apple-platform-engineer--v<version>` tag. Update to the latest release, then
start a new session or run `/reload-plugins`:

```sh
claude plugin marketplace update apple-platform-engineer
claude plugin update apple-platform-engineer@apple-platform-engineer
```

Auto-update is off for third-party marketplaces; turn it on for this one in
`/plugin` → Marketplaces only when you accept unreviewed releases. To pin or
roll back, remove the marketplace and add it again at a release tag
(`ShawnBaek/ai-workflow-apple-platform-engineer#apple-platform-engineer--v<version>`),
then install again.

Give Claude Code one copy of each skill. After switching an existing Skills CLI,
linked-checkout or bundle install to the plugin, remove only the collection's
entries from `~/.claude/skills` (back them up, as the link-farm reconciliation
below describes) and keep `~/.agents/skills` for Codex. The
[inventory](#inventory-before-reconciling) lists plugin installs under
`claudePlugins` and reports a personal copy beside the plugin as a `duplicate`.
The guarded runtime builds its verifier outside the plugin cache, as
[Build and locate the verifier](../../agent-harness/references/swift-verification.md#build-and-locate-the-verifier)
describes.

## Linked checkout or versioned bundle

- **Links into a Git checkout:** verify the resolved checkout and clean working
  state, fetch the intended upstream, review the target commit and fast-forward
  its release branch when appropriate. Preserve local edits and branch policy;
  do not reset an active development branch just to update a skill.
- **Copies or links into a custom versioned bundle** (not the Skills CLI's own
  links, which [rerun `add`](#skills-cli-installations)): export the intended
  revision into a new, empty bundle folder, then validate it with a verifier
  built from that revision (`APE` as in the inventory step above):

  ```sh
  mkdir '<new bundle>' && git -C '<reviewed checkout>' archive '<revision>' | tar -x -C '<new bundle>'
  "$APE" repository --root '<new bundle>'
  ```

  Include the supporting resources needed by the installed skills. Validate
  before switching the existing skill links/copies, and keep the prior bundle
  for rollback. Do not run a generic updater over custom links or rerun a
  one-off activation script without checking whether it supports an already
  installed revision.

### Switching the active pointer without corrupting it

A bundle layout usually has one pointer symlink (`…-active`) and a farm of
per-skill links resolving through it. Repointing that symlink is the step most
likely to fail silently, because the usual commands do something different when
the existing link resolves to a *directory*:

- `mv -f new.tmp active` **moves the new link inside the old bundle** instead of
  replacing the pointer. Exit status is 0 and the pointer never changes.
- `ln -sfn target active` has the same trap without `-n` on some shells, and
  `cp` on a link can copy the tree rather than the link.

Replace the pointer explicitly, then read it back:

```sh
rm -f "$HOME/.agents/<name>-active"
ln -s "$HOME/.agents/skill-bundles/<name>/<revision>" "$HOME/.agents/<name>-active"
readlink "$HOME/.agents/<name>-active"   # must print the new revision
```

Between `rm` and `ln` the pointer is missing for a few milliseconds. That is
acceptable: a client that loads skills in that moment sees broken links until
its next reload, and nothing is left half-written.

If a previous attempt used `mv`, look for the stray link left inside the old
bundle and delete it, so the rollback copy stays byte-identical to its revision.

### Reconciling the per-skill link farm

Switching the pointer does not change which skills the farm exposes. After
activation, reconcile in both directions, and never clear the directory
wholesale:

1. **Protect local-only entries.** Some entries may be real directories or links
   to other sources rather than into this bundle. Resolve each entry's target
   first and leave anything that does not point into the bundle untouched — a
   `rm -rf` and relink destroys them. Links into an export of Apple's Xcode
   skills are foreign too; report them as
   [Apple skill exposure](apple-skill-exposure.md#apple-folders-are-foreign)
   describes.
2. **Prune stale links.** Remove bundle-managed links whose skill no longer
   exists in the new revision; otherwise a renamed or removed skill stays as a
   broken link that a client may still try to load.
3. **Add new links.** A revision that introduces a skill contributes nothing
   until it is linked; the farm will silently stay at the old skill set.
4. Confirm no broken links remain in any client root: rerun the inventory, or
   for one root:

   ```sh
   find "$HOME/.agents/skills" -maxdepth 1 -type l ! -exec test -e {} \; -print
   ```

### Local overrides are a decision, not just a copy

When the active copy differs from the revision it claims, extract the delta
before staging and decide per file rather than reapplying it by habit: upstream
it (the drift then disappears for good), keep it deliberately, or drop it.
Record kept and dropped overrides in the installation receipt, and keep the
patch for anything dropped. Silently reapplying overrides is what makes an
installation permanently diverge from every upstream revision.

The strongest post-switch check is a direct comparison with the source
revision — export it and diff against the activated bundle. Build outputs and
other ignored artifacts are expected; anything else is unreconciled drift.

The collection does not ship a general updater for custom versioned bundles.
Ask your agent:

> Update my installed Apple Platform Engineer skills from
> ShawnBaek/ai-workflow-apple-platform-engineer. Identify my installation method,
> preserve its scope and local changes, validate the new revision, and report the
> active paths and revision afterward.

## Verify the active result

1. Check actual loaded paths and observable source revision/hash, not only the README
   version label. Confirm one discoverable copy of each selected skill with the
   inventory, run by the verifier built from the reviewed revision outside
   every skill root, as in [the inventory step](#inventory-before-reconciling),
   or run with `--repository-root '<reviewed checkout>'` before the
   subcommand. A verifier from the previous revision compares each entry with
   its own older copy, and one built inside `~/.agents/skills` with the copies
   beside it. It reports each one `current`, and no `outdated`,
   `unverified`, `retired`, `unlisted`, `split`, `duplicate`, owned `broken` or
   `staleLock` finding remains for the collection. A copy that no lock
   attributes to a repository, such as one made without the Skills CLI, stays
   `unverified` with a `reason` saying so; check that copy against the source
   revision instead. A copy reinstalled from a local checkout path over an
   earlier GitHub install keeps that install's lock entry, which the inventory
   flags; reinstall it from `owner/repo#<ref>` as
   [Skills CLI installations](#skills-cli-installations) describes. A
   `CLAUDE_CONFIG_DIR` set only in Claude Code's settings `env` is not in the
   shell's environment, so pass that directory as `--claude-config-dir`.
2. When the selected setup uses the harness Swift runtime, rebuild its
   executable in the installed `agent-harness` with the selected full Xcode, as
   in [Build and locate the verifier](../../agent-harness/references/swift-verification.md#build-and-locate-the-verifier).
   That is its changed executable; the out-of-root inventory verifier is not.
   Keep executable, sources and contracts together.
3. If a private coordinator/runtime binding is configured, follow the explicit
   [runtime migration procedure](../../agent-harness/references/swift-verification.md)
   before resuming coordinated work. New hashes do not renew old approvals.
4. Start a fresh task or use your client's supported skill reload, confirm the
   resolved path, then try one representative task with its normal evidence.

If validation fails, retain or restore the previous complete installation and
record the failure. Installed files, a valid runtime binding and a successfully
executed user task are separate checks.
