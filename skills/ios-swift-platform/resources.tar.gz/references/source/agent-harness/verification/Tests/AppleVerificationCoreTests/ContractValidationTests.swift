import XCTest

@testable import AppleVerificationCore

final class ContractValidationTests: XCTestCase {
  var root: URL {
    if let override = ProcessInfo.processInfo.environment["APPLE_VERIFICATION_REPOSITORY_ROOT"] {
      return URL(fileURLWithPath: override)
    }
    return URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent()
      .deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent()
      .deletingLastPathComponent()
  }
  var context: RuntimeContext {
    RuntimeContext(
      repositoryRoot: root, harnessRoot: root.appendingPathComponent("skills/agent-harness"))
  }

  func testLocalAndPRHarnessTemplatesPreserveTrackingModes() throws {
    let schema = try object("skills/agent-harness/contracts/schemas/harness.schema.json")
    for (name, local) in [("harness-local.json", true), ("harness.json", false)] {
      var template = try object("skills/agent-harness/templates/\(name)")
      XCTAssertEqual(JSONSchemaValidator.errors(instance: template, schema: schema), [], name)
      var tracking = try XCTUnwrap(template["github_tracking"] as? [String: Any])
      XCTAssertEqual(tracking["issues"] as? Bool, !local)
      if local { XCTAssertTrue(tracking["project"] is NSNull) }

      tracking["issues"] = local
      template["github_tracking"] = tracking
      XCTAssertFalse(JSONSchemaValidator.errors(instance: template, schema: schema).isEmpty, name)
      if local {
        tracking["issues"] = false
        tracking["project"] = ["number": 1]
        template["github_tracking"] = tracking
        // Satisfy the existing project-component rule to isolate the local scope restriction.
        template["health_components"] =
          (template["health_components"] as! [String]) + ["github_project"]
        XCTAssertFalse(JSONSchemaValidator.errors(instance: template, schema: schema).isEmpty)
      }
    }
  }

  func testShippedWorkflowsAndLeaseIntervalsAreExact() throws {
    let resources = Set(ContractValidation.resources)
    let main = try object("skills/agent-harness/contracts/workflow.json")
    let local = try object("skills/agent-harness/contracts/local-workflow.json")
    let testflight = try object("skills/agent-harness/contracts/testflight-workflow.json")
    XCTAssertEqual(ContractValidation.validateWorkflowSemantics(main, resources: resources), [])
    XCTAssertEqual(ContractValidation.validateLocalWorkflow(local, resources: resources), [])
    XCTAssertEqual(
      ContractValidation.validateTestFlightWorkflow(testflight, resources: resources), [])
    var nodes = testflight["nodes"] as! [[String: Any]]
    let release = nodes.firstIndex { $0["id"] as? String == "release_testflight_upload" }!
    nodes[release]["protects"] = ["upload"]
    var drifted = testflight
    drifted["nodes"] = nodes
    XCTAssertTrue(
      ContractValidation.validateTestFlightWorkflow(drifted, resources: resources).contains {
        $0.contains("protected nodes")
      })
    var bounded = main
    var attempt = main["attempt_policy"] as! [String: Any]
    attempt["max_implementation_attempts"] = 4
    bounded["attempt_policy"] = attempt
    XCTAssertTrue(
      ContractValidation.validateWorkflowSemantics(bounded, resources: resources).contains {
        $0.contains("attempt")
      })
    var cleanup = local
    var cleanupValue = local["cleanup"] as! [String: Any]
    cleanupValue["triggers"] = ["success_terminal"]
    cleanup["cleanup"] = cleanupValue
    XCTAssertTrue(
      ContractValidation.validateLocalWorkflow(cleanup, resources: resources).contains {
        $0.contains("cleanup")
      })
  }

  func testTaskBranchSelectionPreservesAuthorizationBoundaries() throws {
    let workflow = try object("skills/agent-harness/contracts/workflow.json")
    let resources = Set(ContractValidation.resources)
    XCTAssertEqual(ContractValidation.validateWorkflowSemantics(workflow, resources: resources), [])

    // Automatic naming must not let checkout mutation skip the bound run authorization.
    var bypass = workflow
    var nodes = try XCTUnwrap(workflow["nodes"] as? [[String: Any]])
    let writer = try XCTUnwrap(
      nodes.firstIndex {
        $0["id"] as? String == "claim_implementation_writer"
      })
    nodes[writer]["requires"] = ["select_task_branch"]
    bypass["nodes"] = nodes
    XCTAssertTrue(
      ContractValidation.validateWorkflowSemantics(bypass, resources: resources)
        .contains("control-spine dependency drift at claim_implementation_writer"))

    // A persisted old spine needs its pinned bundle, not silent rebinding to this one.
    var legacy = workflow
    legacy["nodes"] = try XCTUnwrap(workflow["nodes"] as? [[String: Any]]).map { node in
      var result = node
      if result["id"] as? String == "select_task_branch" {
        result["id"] = "branch_approval"
      }
      result["requires"] = (result["requires"] as? [String])?.map {
        $0 == "select_task_branch" ? "branch_approval" : $0
      }
      return result
    }
    XCTAssertTrue(
      ContractValidation.validateWorkflowSemantics(legacy, resources: resources)
        .contains("workflow control-spine node order drifted"))
  }

  func testDAGRejectsCyclesMissingEdgesAndDuplicateDependencies() {
    XCTAssertFalse(
      ContractValidation.validateDAG([
        ["id": "a", "requires": ["b"]], ["id": "b", "requires": ["a"]],
      ]).isEmpty)
    XCTAssertFalse(ContractValidation.validateDAG([["id": "a", "requires": ["missing"]]]).isEmpty)
    XCTAssertFalse(
      ContractValidation.validateDAG([
        ["id": "a", "requires": []], ["id": "b", "requires": ["a", "a"]],
      ]).isEmpty)
  }

  func testDeliveryAliasesAndNullCredentials() {
    let disabled: [String: Any] = ["enabled": false, "channels": []]
    XCTAssertEqual(ContractValidation.validateDeliveryChannelConfig(disabled), [])
    let telegram: [String: Any] = [
      "enabled": true,
      "channels": [
        [
          "id": "t", "enabled": true, "kind": "telegram", "credential_ref": NSNull(),
          "destination_ref": "public.chat", "transport_ref": "http",
          "whatsapp_template_ref": NSNull(),
        ]
      ],
    ]
    let errors = ContractValidation.validateDeliveryChannelConfig(telegram)
    XCTAssertTrue(errors.contains { $0.contains("credential") })
    XCTAssertTrue(errors.contains { $0.contains("private alias") })
    XCTAssertTrue(errors.contains { $0.contains("transport") })
  }

  func testCompletionUsageTreatsJSONNullAsAbsentAndRejectsFractions() {
    let valid: [String: Any] = [
      "usage": [
        "status": "not_exposed", "missing_sources": ["codex"], "source_records": [:],
        "attribution": [], "cross_provider_total": NSNull(),
        "cost": ["status": "not_exposed", "amount": NSNull(), "currency": NSNull()],
      ]
    ]
    XCTAssertEqual(ContractValidation.validateCompletionReport(valid), [])
    let fractional: [String: Any] = [
      "usage": [
        "status": "full", "missing_sources": [],
        "source_records": ["x": ["input_tokens": 1.5, "output_tokens": 2]],
        "attribution": [["source_ids": ["x"]]],
        "cross_provider_total": ["input_tokens": 1, "output_tokens": 2],
        "cost": ["status": "not_exposed", "amount": NSNull(), "currency": NSNull()],
      ]
    ]
    XCTAssertTrue(
      ContractValidation.validateCompletionReport(fractional).contains {
        $0.contains("bounded integer")
      })
  }

  func testCompanionProvenanceAndRuntimeBindingMutations() throws {
    let companion = try object("skills/icon-composer/contracts/companion-upstream.json")
    XCTAssertEqual(ContractValidation.validateCompanionUpstream(companion), [])
    var drifted = companion
    var integration = drifted["integration"] as! [String: Any]
    integration["execute_upstream"] = true
    drifted["integration"] = integration
    XCTAssertTrue(
      ContractValidation.validateCompanionUpstream(drifted).contains {
        $0.contains("safety boundary")
      })
    let binding: [String: Any] = [
      "runtime_kind": "swift", "runtime_contract": Authorization.runtimeContract,
      "executable_path": "/bin/tool",
      "executable_sha256": "sha256:" + String(repeating: "a", count: 64),
      "source_bundle_sha256": "sha256:" + String(repeating: "b", count: 64),
    ]
    XCTAssertEqual(
      ContractValidation.validateSwiftRuntimeBinding(
        binding, contract: Authorization.runtimeContract, requireExecutablePath: true), [])
    var legacy = binding
    legacy["script_sha256"] = "sha256:" + String(repeating: "c", count: 64)
    XCTAssertFalse(
      ContractValidation.validateSwiftRuntimeBinding(
        legacy, contract: Authorization.runtimeContract, requireExecutablePath: true
      ).isEmpty)
    XCTAssertEqual(
      ContractValidation.validateIconGenWorkflow(
        at: root.appendingPathComponent(".github/workflows/icongen-upstream-watch.yml")), [])
    let temporary = FileManager.default.temporaryDirectory.appendingPathComponent(
      UUID().uuidString + ".yml")
    try
      (try String(
        contentsOf: root.appendingPathComponent(".github/workflows/icongen-upstream-watch.yml"),
        encoding: .utf8) + "\npermissions: write-all\n").write(
        to: temporary, atomically: true, encoding: .utf8)
    defer { try? FileManager.default.removeItem(at: temporary) }
    XCTAssertTrue(
      ContractValidation.validateIconGenWorkflow(at: temporary).contains {
        $0.contains("forbidden privilege")
      })
    let watcher = try String(
      contentsOf: root.appendingPathComponent(".github/workflows/icongen-upstream-watch.yml"),
      encoding: .utf8)
    try watcher.replacingOccurrences(
      of: "    if: github.repository == 'ShawnBaek/ai-workflow-apple-platform-engineer'\n",
      with: ""
    ).write(to: temporary, atomically: true, encoding: .utf8)
    XCTAssertTrue(
      ContractValidation.validateIconGenWorkflow(at: temporary).contains {
        $0.contains("execution contract drifted")
      })
  }

  func testCapabilityPoliciesRemainFullyBound() throws {
    let capabilities = try object("skills/agent-harness/contracts/capabilities.json")
    XCTAssertEqual(ContractValidation.validateCapabilities(capabilities), [])
    var drifted = capabilities
    var varPolicy = capabilities["runtime_registry_policy"] as! [String: Any]
    varPolicy["minimum_repeat_observations"] = 1
    drifted["runtime_registry_policy"] = varPolicy
    XCTAssertTrue(
      ContractValidation.validateCapabilities(drifted).contains {
        $0.contains("not the reviewed policy")
      })
  }

  func testTestFlightTransitionRequiresOrderedCompletedReadbackAndStableArtifact() {
    func record(_ type: String, _ payload: [String: Any]) -> [String: Any] {
      ["record_type": type, "payload": payload]
    }
    let base: [String: Any] = [
      "system": "apple", "authorization_hash": "auth", "outcome": "succeeded",
      "artifact_sha256": "sha256:" + String(repeating: "a", count: 64),
      "artifact_source_commit": String(repeating: "b", count: 40), "version": "1.0", "build": "1",
    ]
    var readback = base
    readback["action"] = "apple.testflight.readback"
    readback["target"] = "app:1:upload"
    readback["external_state"] = "completed"
    let errors = ContractValidation.validateTestFlightLedgerTransitions([
      record("external_write", readback),
      record("node", ["node_id": "testflight_uploaded", "status": "passed"]),
    ])
    XCTAssertTrue(errors.contains { $0.contains("bounded processing") })
    XCTAssertTrue(errors.contains { $0.contains("completed upload read-back") })
    var upload = base
    upload["action"] = "apple.testflight.upload"
    upload["target"] = "app:1"
    var wait = base
    wait["action"] = "apple.testflight.processing.wait"
    wait["target"] = "app:1:processing"
    XCTAssertEqual(
      ContractValidation.validateTestFlightLedgerTransitions([
        record("external_write", upload), record("external_write", wait),
        record("external_write", readback),
        record("node", ["node_id": "testflight_uploaded", "status": "passed"]),
      ]), [])
    var changed = readback
    changed["build"] = "2"
    XCTAssertTrue(
      ContractValidation.validateTestFlightLedgerTransitions([
        record("external_write", upload), record("external_write", wait),
        record("external_write", changed),
      ]).contains { $0.contains("artifact identity drifted") })
  }

  func testAuthorizationTemplatesAndSchemaContentBinding() throws {
    let pending = try object("skills/agent-harness/templates/run-authorization.json")
    XCTAssertEqual(ContractValidation.validatePendingAuthorization(pending), [])
    var executable = pending
    executable["allowed_paths"] = ["Sources"]
    XCTAssertTrue(
      ContractValidation.validatePendingAuthorization(executable).contains {
        $0.contains("allowed_paths")
      })
    let schema = root.appendingPathComponent(
      "skills/agent-harness/contracts/schemas/run-authorization.schema.json")
    var approved = try object("tests/fixtures/run-authorization-approved.json")
    approved["contract_schema_sha256"] = "sha256:" + (try HarnessRuntime.sha256File(schema))
    XCTAssertEqual(
      ContractValidation.validateApprovedAuthorization(
        approved, schemaURL: schema, context: context), [])
    approved["contract_schema_sha256"] = "sha256:" + String(repeating: "0", count: 64)
    XCTAssertTrue(
      ContractValidation.validateApprovedAuthorization(
        approved, schemaURL: schema, context: context
      ).contains { $0.contains("schema content") })
  }

  func testImmutableAuthorityInjectionFixture() throws {
    let fixture = try object("tests/fixtures/rag-prompt-injection.json")
    XCTAssertEqual(ContractValidation.validatePromptInjectionFixture(fixture), [])
    var drifted = fixture
    var expected = fixture["expected"] as! [String: Any]
    expected["tool_calls"] = 1
    drifted["expected"] = expected
    XCTAssertTrue(
      ContractValidation.validatePromptInjectionFixture(drifted).contains {
        $0.contains("zero tool calls")
      })
  }

  private func object(_ path: String) throws -> [String: Any] {
    try HarnessRuntime.object(root.appendingPathComponent(path))
  }
}
