# XCTest and UI automation practice

## Test type

Use Swift Testing for new, focused unit-level tests when supported by the project and toolchain. Use XCTest for existing XCTest suites, UI automation, performance metrics, and cases needing its integration. Keep an existing suite's conventions unless the task explicitly includes migration.

## Accessibility tree and selector contract

XCUITest discovers app UI through the accessibility tree. That does not make an
accessibility label the default automation key. For app-owned controls and
navigation, prefer a stable, unique, nonlocalized `accessibilityIdentifier` and
scope the query by semantic element type or container. Keep identifiers in
production-like builds, treat them as a test-facing API, and never derive them
from localized text, array position, personal data, or volatile content.

An identifier is not a substitute for `accessibilityLabel`, value, traits,
actions, grouping, focus order, or hit behavior. Keep those user-facing
semantics correct for VoiceOver and other assistive technologies. Do not change
a label only to make a test pass. When wording, localization, selected value, or
another accessibility semantic is the acceptance criterion, query the element
by identifier and assert its label/value/traits in the selected locale. A
localized label selector is acceptable only when that visible/accessibility text
is the contract or an unowned system surface exposes no stable identifier;
scope it narrowly and record the locale-dependent risk.

```swift
// App code
Button("Save") { save() }
    .accessibilityIdentifier("settings.save")

// UI test: stable navigation, then a user-facing accessibility assertion.
let saveButton = app.buttons["settings.save"]
XCTAssertTrue(saveButton.waitForExistence(timeout: 5))
XCTAssertEqual(saveButton.label, expectedLocalizedSaveLabel)
```

For repeated content, use a stable fixture/domain ID without PII and keep the
semantic element unique inside its screen/container. Duplicate or missing IDs
block the selector contract; do not fall through silently to coordinates. Seed
deterministic state through an approved launch argument, environment variable,
fixture, or dependency seam, as the [launch contract](ui-test-architecture.md#govern-the-launch-contract)
describes. Pass environment to the test process through the scheme, the test
plan, or a shell variable prefixed `TEST_RUNNER_`, which `xcodebuild test`
passes to the test runner with the prefix removed. Do not rely on other
exported shell variables: a gate that reads one from
`ProcessInfo.processInfo.environment` can silently skip. The app under test
receives `XCUIApplication.launchEnvironment`, not the runner's environment;
copy any runner value it needs into it. Wait explicitly for the expected
element or state; do not use time-based sleeps as synchronization. Use
hierarchy inspection before any documented coordinate fallback.

Keep the test focused on the changed user contract. Prefer an assertion on the visible outcome over implementation details, and avoid recording-based selectors without reviewing and stabilizing them.

For a state-changing action, verify its meaningful postcondition before the next
dependent step. An element's existence or a successful tap does not prove that
saving, navigation or deletion occurred. When practical, establish that the
postcondition was not already satisfied. Keep waits tied to observable state and
capture the first failing step with its relevant screenshot or short recording.
[Shopify's mobile testing experience](https://shopify.engineering/mobile-e2e-testing)
supports this principle; reuse native XCTest and the app's existing helpers
instead of importing its custom OCR/Appium framework.

## Gesture contracts

For a detented sheet, slider, scrubber, reorder handle, or other continuous
control, exercise one uninterrupted touch-down, held move, and touch-up gesture.
Start from the current hierarchy-derived hit region, cross the actual threshold,
wait for animation completion, then recapture and assert the changed frame or
state. A tap followed by a swipe, a command exit, or an outer-container-only
assertion does not prove the recognizer handled the intended gesture. Reverse
gestures must use the element's new coordinates rather than stale ones.

Two Simulator defaults silently turn a correct gesture or input into a no-op.
Check both before concluding the app is at fault:

- **A drag that starts at a screen edge becomes a system gesture.** Within a few
  points of an edge the Simulator routes the touch to the OS — back, app
  switcher, Notification Center, Control Center — so a bottom sheet dragged from
  its lowest visible rows never reaches the app's recognizer, and the failure
  looks like an unresponsive sheet. Start the gesture inside the content, away
  from the edge, and confirm the app received it.
- **A connected hardware keyboard suppresses the software keyboard.** With
  `ConnectHardwareKeyboard` enabled, typing still succeeds while the on-screen
  keyboard never appears — so keyboard-driven layout, safe-area insets,
  scroll-to-field and accessory views cannot reproduce. Disable it for any
  criterion that depends on the keyboard being on screen, and verify the
  keyboard is actually visible in the hierarchy rather than assuming.

A detented sheet also snaps by *velocity*, not only by distance: the same path
delivered slowly settles at the nearest detent while a fast flick crosses to the
next one. When the detent reached is the criterion, control the timing of the
move samples and exercise both, rather than reporting the one that happened to
land.

If an official host interaction grammar does not expose pinch, do not invent an
undocumented command or occupy the device session while searching for one. Use
an enabled XCUITest target and call
`XCUIElement.pinch(withScale:velocity:)` on the visible zoom surface. Confirm the
UI test target is included in the active scheme/test plan and that the named test
actually executed. Build success or a compiled test method is
not pinch runtime evidence; report it as unrun when the target is excluded.

## Build reuse and results

Reuse `build-for-testing` products when the source/dependency identity, project/container, scheme, configuration, toolchain, destination compatibility, and required built test targets match. A narrower or different `-only-testing` filter may reuse those products when the selected tests were already built. Rebuild for changed inputs or a missing test target; preserve the compatible `.xctestrun` and build manifest. For a gate that runs several test plans of one scheme, build once and run each plan with `test-without-building -testPlan <plan>` using the same `-derivedDataPath`, after confirming the products contain each plan's `.xctestrun` and test bundles.

When a gate is slow, split its time into build and test from the logs and result bundle, and find the suites that dominate test time before changing what runs. In those suites, first replace fixed sleeps and over-long waits with condition-based waits, and remove avoidable animation settling time. Skipping a test plan whose inputs did not change, or running only the UI suites a change touches, changes the repository's required gate: do it only when the repository's own rules or the person's explicit instruction allow it, report what was skipped, and otherwise run every required plan.

When a run fails, retain the raw `.xcresult`, extract a concise summary with the supported Xcode result tooling, and lead with the first actionable failure. Treat sandbox/CoreSimulator permission failures as host-environment problems, not failing application tests.
