#!/usr/bin/env swift
import CoreGraphics
import Foundation
import ImageIO
import UniformTypeIdentifiers

struct Arguments {
  let figma: URL
  let actual: URL
  let output: URL
  let threshold: Int
  let minimumMatch: Double?
}

struct RGBAImage {
  let width: Int
  let height: Int
  var pixels: [UInt8]
}

enum ScriptError: LocalizedError {
  case usage(String)
  case invalidImage(URL)
  case dimensionsDiffer(CGSize, CGSize)
  case couldNotWrite(URL)

  var errorDescription: String? {
    switch self {
    case .usage(let message): return message
    case .invalidImage(let url): return "Could not read PNG: \(url.path)"
    case .dimensionsDiffer(let figma, let actual):
      return
        "input dimensions differ: figma=\(Int(figma.width))x\(Int(figma.height)), actual=\(Int(actual.width))x\(Int(actual.height))"
    case .couldNotWrite(let url): return "Could not write PNG: \(url.path)"
    }
  }
}

func value(after flag: String, in arguments: [String]) throws -> String {
  guard let index = arguments.firstIndex(of: flag), arguments.indices.contains(index + 1) else {
    throw ScriptError.usage("Missing value for \(flag)")
  }
  return arguments[index + 1]
}

func parseArguments() throws -> Arguments {
  let arguments = Array(CommandLine.arguments.dropFirst())
  guard !arguments.contains("--help") else {
    throw ScriptError.usage(
      "Usage: overlay_diff.swift --figma <PNG> --actual <PNG> --out <directory> [--threshold <0...255>] [--minimum-match <0...100>]"
    )
  }
  let figma = URL(fileURLWithPath: try value(after: "--figma", in: arguments))
  let actual = URL(fileURLWithPath: try value(after: "--actual", in: arguments))
  let output = URL(fileURLWithPath: try value(after: "--out", in: arguments))
  let thresholdText =
    arguments.contains("--threshold")
    ? try value(after: "--threshold", in: arguments) : "16"
  guard let threshold = Int(thresholdText), (0...255).contains(threshold) else {
    throw ScriptError.usage("--threshold must be between 0 and 255")
  }
  var minimumMatch: Double?
  if arguments.contains("--minimum-match") {
    guard let minimum = Double(try value(after: "--minimum-match", in: arguments)),
      minimum.isFinite, (0...100).contains(minimum)
    else {
      throw ScriptError.usage("--minimum-match must be a finite number between 0 and 100")
    }
    minimumMatch = minimum
  }
  return Arguments(
    figma: figma, actual: actual, output: output, threshold: threshold, minimumMatch: minimumMatch)
}

func loadImage(_ url: URL) throws -> RGBAImage {
  guard let source = CGImageSourceCreateWithURL(url as CFURL, nil),
    let image = CGImageSourceCreateImageAtIndex(source, 0, nil)
  else { throw ScriptError.invalidImage(url) }

  let width = image.width
  let height = image.height
  var pixels = [UInt8](repeating: 0, count: width * height * 4)
  let colorSpace = CGColorSpaceCreateDeviceRGB()
  let bitmapInfo = CGImageAlphaInfo.premultipliedLast.rawValue
  let rendered = pixels.withUnsafeMutableBytes { bytes in
    guard let baseAddress = bytes.baseAddress,
      let context = CGContext(
        data: baseAddress,
        width: width,
        height: height,
        bitsPerComponent: 8,
        bytesPerRow: width * 4,
        space: colorSpace,
        bitmapInfo: bitmapInfo
      )
    else { return false }
    context.interpolationQuality = .none
    context.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
    return true
  }
  guard rendered else { throw ScriptError.invalidImage(url) }
  return RGBAImage(width: width, height: height, pixels: pixels)
}

func makeCGImage(_ image: RGBAImage) -> CGImage? {
  let data = Data(image.pixels) as CFData
  guard let provider = CGDataProvider(data: data) else { return nil }
  return CGImage(
    width: image.width,
    height: image.height,
    bitsPerComponent: 8,
    bitsPerPixel: 32,
    bytesPerRow: image.width * 4,
    space: CGColorSpaceCreateDeviceRGB(),
    bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
    provider: provider,
    decode: nil,
    shouldInterpolate: false,
    intent: .defaultIntent
  )
}

func writePNG(_ image: RGBAImage, to url: URL) throws {
  guard let cgImage = makeCGImage(image),
    let destination = CGImageDestinationCreateWithURL(
      url as CFURL, UTType.png.identifier as CFString, 1, nil)
  else { throw ScriptError.couldNotWrite(url) }
  CGImageDestinationAddImage(destination, cgImage, nil)
  guard CGImageDestinationFinalize(destination) else { throw ScriptError.couldNotWrite(url) }
}

func blend(_ lhs: RGBAImage, _ rhs: RGBAImage) -> RGBAImage {
  var pixels = lhs.pixels
  for index in stride(from: 0, to: pixels.count, by: 4) {
    for channel in 0..<4 {
      pixels[index + channel] = UInt8(
        (Int(lhs.pixels[index + channel]) + Int(rhs.pixels[index + channel])) / 2)
    }
  }
  return RGBAImage(width: lhs.width, height: lhs.height, pixels: pixels)
}

/// The per-pixel difference used by both `diff.png` and `metrics.json`: the largest RGB channel delta.
func maxRGBDelta(_ lhs: RGBAImage, _ rhs: RGBAImage, at index: Int) -> Int {
  max(
    abs(Int(lhs.pixels[index]) - Int(rhs.pixels[index])),
    abs(Int(lhs.pixels[index + 1]) - Int(rhs.pixels[index + 1])),
    abs(Int(lhs.pixels[index + 2]) - Int(rhs.pixels[index + 2])))
}

/// Draws the Figma reference dimmed to grayscale, then marks every pixel that differs:
/// solid red (255, 0, 0) above the threshold, and a faint yellow tint that strengthens with
/// the delta from 1 up to the threshold. An identical pixel keeps only the dimmed reference.
func heatmap(_ lhs: RGBAImage, _ rhs: RGBAImage, threshold: Int) -> RGBAImage {
  func mix(_ base: Int, _ tint: Int, _ alpha: Int) -> UInt8 {
    UInt8((base * (255 - alpha) + tint * alpha) / 255)
  }
  var pixels = lhs.pixels
  for index in stride(from: 0, to: pixels.count, by: 4) {
    let delta = maxRGBDelta(lhs, rhs, at: index)
    let luma =
      (299 * Int(lhs.pixels[index]) + 587 * Int(lhs.pixels[index + 1])
        + 114 * Int(lhs.pixels[index + 2])) / 1000
    let dimmed = luma / 3
    let color: (UInt8, UInt8, UInt8)
    if delta > threshold {
      color = (255, 0, 0)
    } else if delta > 0 {
      // Reachable only when threshold >= 1 (delta > 0 exceeds a zero threshold).
      let alpha = 64 + 96 * delta / threshold
      color = (mix(dimmed, 255, alpha), mix(dimmed, 214, alpha), mix(dimmed, 0, alpha))
    } else {
      color = (UInt8(dimmed), UInt8(dimmed), UInt8(dimmed))
    }
    pixels[index] = color.0
    pixels[index + 1] = color.1
    pixels[index + 2] = color.2
    pixels[index + 3] = 255
  }
  return RGBAImage(width: lhs.width, height: lhs.height, pixels: pixels)
}

func sideBySide(_ lhs: RGBAImage, _ rhs: RGBAImage) -> RGBAImage {
  var pixels = [UInt8](repeating: 255, count: lhs.width * 2 * lhs.height * 4)
  for y in 0..<lhs.height {
    for x in 0..<lhs.width {
      let source = (y * lhs.width + x) * 4
      let left = (y * lhs.width * 2 + x) * 4
      let right = (y * lhs.width * 2 + lhs.width + x) * 4
      pixels.replaceSubrange(left..<(left + 4), with: lhs.pixels[source..<(source + 4)])
      pixels.replaceSubrange(right..<(right + 4), with: rhs.pixels[source..<(source + 4)])
    }
  }
  return RGBAImage(width: lhs.width * 2, height: lhs.height, pixels: pixels)
}

func writeMetrics(
  figma: RGBAImage, actual: RGBAImage, threshold: Int, minimumMatch: Double?, to url: URL
) throws -> Bool {
  var exact = 0
  var matching = 0
  var sumDelta = 0
  var maxDelta = 0
  for index in stride(from: 0, to: figma.pixels.count, by: 4) {
    let delta = maxRGBDelta(figma, actual, at: index)
    exact += delta == 0 ? 1 : 0
    matching += delta <= threshold ? 1 : 0
    sumDelta += delta
    maxDelta = max(maxDelta, delta)
  }
  let count = figma.width * figma.height
  let percentage = Double(matching) * 100 / Double(count)
  let passed = minimumMatch.map { percentage >= $0 }
  let metrics: [String: Any] = [
    "requiredMatchPercentage": minimumMatch.map { $0 as Any } ?? NSNull(),
    "status": passed.map { $0 ? "passed" : "failed" } ?? "not_evaluated",
    "comparison": "raw pixel agreement; not perceptual correctness",
    "dimensions": ["width": figma.width, "height": figma.height],
    "threshold": threshold,
    "exactPixels": exact,
    "matchingPixels": matching,
    "pixelCount": count,
    "exactPercentage": Double(exact) * 100 / Double(count),
    "matchPercentage": Double(matching) * 100 / Double(count),
    "meanMaxRGBDelta": Double(sumDelta) / Double(count),
    "maxRGBDelta": maxDelta,
    "transformations": "CoreGraphics device-RGB decode; no scaling, cropping, or masking",
  ]
  let data = try JSONSerialization.data(
    withJSONObject: metrics, options: [.prettyPrinted, .sortedKeys])
  try data.write(to: url)
  return passed != false
}

do {
  let arguments = try parseArguments()
  let figma = try loadImage(arguments.figma)
  let actual = try loadImage(arguments.actual)
  guard figma.width == actual.width, figma.height == actual.height else {
    throw ScriptError.dimensionsDiffer(
      CGSize(width: figma.width, height: figma.height),
      CGSize(width: actual.width, height: actual.height)
    )
  }
  try FileManager.default.createDirectory(at: arguments.output, withIntermediateDirectories: true)
  try writePNG(blend(figma, actual), to: arguments.output.appendingPathComponent("overlay.png"))
  try writePNG(
    heatmap(figma, actual, threshold: arguments.threshold),
    to: arguments.output.appendingPathComponent("diff.png"))
  try writePNG(
    sideBySide(figma, actual), to: arguments.output.appendingPathComponent("side-by-side.png"))
  let accepted = try writeMetrics(
    figma: figma, actual: actual, threshold: arguments.threshold,
    minimumMatch: arguments.minimumMatch,
    to: arguments.output.appendingPathComponent("metrics.json"))
  print(arguments.output.path)
  if !accepted {
    FileHandle.standardError.write(
      Data("Pixel comparison failed; see metrics.json and diff.png\n".utf8))
    exit(2)
  }
} catch {
  FileHandle.standardError.write(Data("\(error.localizedDescription)\n".utf8))
  exit(1)
}
