# Self-hosted macOS runner

A dedicated self-hosted Mac can provide a controlled Xcode version, local
hardware, and predictable queueing. A developer's daily-use Mac is higher risk:
workflow code runs with that user's filesystem and network access. Compare it
with GitHub-hosted macOS before choosing.

## Before registration

1. Verify the exact GitHub account, repository/organization, and private project
   policy. Do not register against a convenient cached login.
2. Decide which code can ever reach the runner. Untrusted pull-request code,
   including every fork or outside-collaborator PR, never runs on a persistent
   self-hosted runner, even without secrets or write access. It can persist on
   the host, read the runner user's files and keychain, and poison DerivedData
   or SwiftPM caches that later trusted jobs reuse. GitHub advises against
   self-hosted runners for public repositories. Build that code on GitHub-hosted
   runners, or on ephemeral just-in-time runners whose VM or machine is reset
   after its one job. When such a change needs an Xcode build only this runner
   has, a maintainer first reviews it and then runs the protected
   `workflow_dispatch` job at its pinned head SHA described in
   [workflow templates](workflow-templates.md#build-and-minimum-sufficient-test).
   A private repository needs the same rule when people outside the trusted
   group can fork it and open pull requests.
3. Dedicate an OS user and runner directory when practical. Do not reuse a user
   that holds broad Apple/GitHub credentials.
4. Record architecture, macOS, Xcode build, available disk, labels, signing
   access, and concurrency policy.
5. Retrieve the current download/configuration commands from the repository's
   GitHub Settings > Actions > Runners page. Do not paste a hardcoded runner
   release URL from an old guide.

Registration/removal tokens are short-lived credentials. Request them only when
the user approved registration/removal, do not print/store them, and run the
current GitHub-provided command in the intended runner directory.

## Labels and routing

Use labels that state actual capabilities, for example architecture, Xcode build,
and whether signing is present. A job must not select a generic runner and then
silently change Xcode or install tools. Limit each runner service to the
concurrency it can safely support; separate build tuple, Simulator/device, and
signing leases still apply across local agents and CI. Devices and
parallel-testing clones persist between jobs on this runner, so choose test
destinations under [destination reuse](../xcodebuild/SKILL.md#choose-and-reuse-a-simulator-destination).

## Service and verification

After following GitHub's current macOS service instructions:

- verify the runner appears online for the exact repository/account;
- run a read-only diagnostic job that prints runner architecture and Xcode build;
- confirm the job lacks unneeded write permissions and secrets;
- verify logs/artifacts do not expose home paths or account material;
- test shutdown/restart and document who owns maintenance.

Do not run an application build until the Xcode project/account/host preflight is
complete.

## Security and maintenance

- Never execute untrusted fork code on this runner or in a privileged workflow.
- Keep runner software and macOS/Xcode updates intentional and recorded.
- Use least-privilege repository/environment secrets and protected environments.
- A signing job never imports certificates into the runner user's login
  keychain. It uses a temporary keychain and, in an always-run step, removes
  it, its key files and any profile it installed, and restores the search
  list, as in the
  [signed TestFlight upload](workflow-templates.md#signed-testflight-upload).
- Monitor disk with `xcode-storage`; never schedule blanket cache/Simulator/
  archive/workspace deletion.
- Remove a runner through GitHub's current removal flow. Do not delete its
  directory first and leave a registered orphan.
- Treat a shared runner's unexpected dirty workspace or active process as a
  blocked lease, not permission to wipe it.

References:

- [Adding self-hosted runners](https://docs.github.com/en/actions/hosting-your-own-runners/managing-self-hosted-runners/adding-self-hosted-runners)
- [Configuring the runner as a macOS service](https://docs.github.com/en/actions/hosting-your-own-runners/managing-self-hosted-runners/configuring-the-self-hosted-runner-application-as-a-service)
- [Self-hosted runner security](https://docs.github.com/en/actions/reference/security/secure-use#hardening-for-self-hosted-runners)
