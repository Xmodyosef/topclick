# Naqra / PersonalKeyboard — APP ONLY (isolation test)

This package has NO keyboard extension.
Purpose: test whether install failure is caused by the Extension.

- Bundle: app.personal.PersonalKeyboard
- Version: 0.1 (3)
- DisplayName: Naqra

Build with GitHub Actions same as before.
