import SwiftUI
import Translation
import UIKit

enum KeyboardLanguage { case arabic, english }

enum KeyboardPage { case letters, symbols, emoji }

enum KeyShape: String {
    case square, rounded, pill
    var cornerRadius: CGFloat {
        switch self {
        case .square: return 4
        case .rounded: return 8
        case .pill: return 22
        }
    }
}

final class ClipboardHistory {
    static let shared = ClipboardHistory()
    private let key = "topclick|clipboard"
    private let maxItems = 20
    var items: [String] {
        get { (ThemeIO.string(key) ?? "").split(separator: "\n").map(String.init).filter { !$0.isEmpty } }
        set { ThemeIO.write(key, value: newValue.prefix(maxItems).joined(separator: "\n")) }
    }
    func add(_ text: String) {
        guard !text.isEmpty, text.count < 500 else { return }
        var current = items
        current.removeAll { $0 == text }
        current.insert(text, at: 0)
        items = current
    }
}

enum ThemeIO {
    static let group = "group.app.personal.Topclick"
    static var suite: UserDefaults { UserDefaults(suiteName: group) ?? .standard }
    static var fileURL: URL? {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group)?
            .appendingPathComponent("naqra-prefs.json")
    }
    static func fileDict() -> [String: Any] {
        guard let url = fileURL, let data = try? Data(contentsOf: url),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return [:] }
        return obj
    }
    static let boardName = UIPasteboard.Name("group.app.personal.Topclick")
    static func write(_ key: String, value: Any) {
        suite.set(value, forKey: key)
        UserDefaults.standard.set(value, forKey: key)
        suite.synchronize()
        UserDefaults.standard.synchronize()
        var d = fileDict()
        d[key] = value
        if let url = fileURL, let data = try? JSONSerialization.data(withJSONObject: d, options: []) {
            try? data.write(to: url, options: .atomic)
        }
        if let text = value as? String, key == "themeId" {
            let pb = UIPasteboard(name: boardName, create: true)
            pb?.string = "topclick|themeId|" + text
        }
        CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(), CFNotificationName("app.personal.Topclick.prefs" as CFString), nil, nil, true)
    }
    static func string(_ key: String) -> String? {
        if let v = fileDict()[key] as? String { return v }
        if let v = suite.string(forKey: key) { return v }
        if let v = UserDefaults.standard.string(forKey: key) { return v }
        if key == "themeId",
           let raw = UIPasteboard(name: boardName, create: false)?.string,
           raw.hasPrefix("topclick|themeId|") {
            return String(raw.dropFirst("topclick|themeId|".count))
        }
        return nil
    }
    static func bool(_ key: String) -> Bool? {
        if let v = fileDict()[key] as? Bool { return v }
        if suite.object(forKey: key) != nil { return suite.bool(forKey: key) }
        if UserDefaults.standard.object(forKey: key) != nil { return UserDefaults.standard.bool(forKey: key) }
        return nil
    }
}

final class TranslationBridgeModel: ObservableObject {
    @Published var sourceText = ""
    @Published var token = 0
    var sourceLang = "ar"
    var targetLang = "en"
    var onResult: ((String) -> Void)?
}

struct TranslationBridgeView: View {
    @ObservedObject var model: TranslationBridgeModel
    var body: some View {
        Group {
            if #available(iOS 18.0, *) {
                Color.clear.frame(width: 1, height: 1)
                    .translationTask(
                        TranslationSession.Configuration(
                            source: Locale.Language(identifier: model.sourceLang),
                            target: Locale.Language(identifier: model.targetLang)
                        )
                    ) { session in
                        let text = model.sourceText
                        guard !text.isEmpty else { return }
                        do {
                            let response = try await session.translate(text)
                            await MainActor.run {
                                model.onResult?(response.targetText)
                            }
                        } catch {}
                    }
                    .id(model.token)
            }
        }
    }
}

struct NaqraPalette {
    var background: UIColor
    var key: UIColor
    var text: UIColor
    var accent: UIColor
    var blurDark: Bool

    static let order = [
        "auto", "light", "dark", "glass", "ocean", "cobalt", "violet",
        "orchid", "hailey", "ember", "forest", "matrix", "nord",
        "sunset", "aurora", "sakura", "cyberpunk", "minimal", "sepia",
        "morning", "evening",
        "m1","m2","m3","m4","m5","m6","m7","m8","m9","m10",
        "m11","m12","m13","m14","m15","m16","m17","m18","m19","m20",
        "e1","e2","e3","e4","e5","e6","e7","e8","e9","e10",
        "e11","e12","e13","e14","e15","e16","e17","e18","e19","e20",
        "custom"
    ]
    static let titles = [
        "auto": "تلقائي",
        "light": "فاتح",
        "dark": "داكن",
        "glass": "منشور",
        "ocean": "بحر",
        "cobalt": "كوبالت",
        "violet": "بنفسج",
        "orchid": "أوركيد",
        "hailey": "دم",
        "ember": "جمر",
        "forest": "غابة",
        "matrix": "ماتريكس",
        "nord": "نورد",
        "sunset": "غروب",
        "aurora": "شفق",
        "sakura": "ساكورا",
        "cyberpunk": "سايبر",
        "minimal": "بسيط",
        "sepia": "سيبيا",
        "morning": "صباح",
        "evening": "مساء",
        "m1": "رملي", "m2": "قش", "m3": "خوخ", "m4": "مشمش", "m5": "عاج",
        "m6": "حليب", "m7": "نعناع", "m8": "مريمية", "m9": "سماء", "m10": "بحيرة",
        "m11": "لافندر", "m12": "ورد", "m13": "ذهب", "m14": "عسل", "m15": "زيتون",
        "m16": "طين", "m17": "ورق", "m18": "ضباب", "m19": "مرجان", "m20": "فستق",
        "e1": "فحم", "e2": "كحلي", "e3": "ليل", "e4": "حبر", "e5": "برقوق",
        "e6": "نبيذ", "e7": "غابة", "e8": "زمرد", "e9": "محيط", "e10": "كوبالت ليلي",
        "e11": "جمر", "e12": "نحاس", "e13": "بنفسج ليلي", "e14": "أوركيد ليلي", "e15": "رماد",
        "e16": "دخان", "e17": "قهوة", "e18": "صحراء", "e19": "ملكي", "e20": "فجر",
        "custom": "مخصص"
    ]

    static func current() -> NaqraPalette {
        let raw = ThemeIO.string("themeId") ?? "dark"
        let id = normalizeThemeId(raw)
        if id == "custom" { return solid(customPalette()) }
        if id == "auto" {
            let dark = UITraitCollection.current.userInterfaceStyle == .dark
            return solid(preset(dark ? "dark" : "light"))
        }
        return solid(preset(id))
    }

    static func solid(_ p: NaqraPalette) -> NaqraPalette {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        guard p.key.getRed(&r, green: &g, blue: &b, alpha: &a) else { return p }
        let amount: CGFloat = p.blurDark ? 0.05 : 0.08
        let background = UIColor(red: max(0, r - amount), green: max(0, g - amount), blue: max(0, b - amount), alpha: 1)
        return .init(background: background, key: p.key.withAlphaComponent(1), text: p.text, accent: p.accent, blurDark: p.blurDark)
    }

    static func preset(_ id: String) -> NaqraPalette {
        switch id {
        case "light":
            return .init(background: .clear, key: UIColor(red: 0.90, green: 0.95, blue: 0.99, alpha: 0.82), text: UIColor(red: 0.14, green: 0.27, blue: 0.40, alpha: 1), accent: UIColor(red: 0.28, green: 0.52, blue: 0.86, alpha: 1), blurDark: false)
        case "glass":
            return .init(background: .clear, key: UIColor(red: 0.86, green: 0.82, blue: 0.96, alpha: 0.38), text: UIColor(red: 0.18, green: 0.16, blue: 0.28, alpha: 1), accent: UIColor(red: 0.62, green: 0.42, blue: 0.88, alpha: 1), blurDark: false)
        case "ocean":
            return .init(background: .clear, key: UIColor(red: 0.06, green: 0.22, blue: 0.32, alpha: 0.55), text: UIColor(red: 0.62, green: 0.96, blue: 0.98, alpha: 1), accent: UIColor(red: 0.16, green: 0.78, blue: 0.84, alpha: 1), blurDark: true)
        case "cobalt":
            return .init(background: .clear, key: UIColor(red: 0.10, green: 0.18, blue: 0.42, alpha: 0.62), text: UIColor(red: 0.82, green: 0.90, blue: 1.0, alpha: 1), accent: UIColor(red: 0.32, green: 0.56, blue: 1.0, alpha: 1), blurDark: true)
        case "violet":
            return .init(background: .clear, key: UIColor(red: 0.18, green: 0.10, blue: 0.32, alpha: 0.50), text: UIColor(red: 0.90, green: 0.78, blue: 1.0, alpha: 1), accent: UIColor(red: 0.70, green: 0.42, blue: 1.0, alpha: 1), blurDark: true)
        case "orchid":
            return .init(background: .clear, key: UIColor(red: 0.32, green: 0.08, blue: 0.18, alpha: 0.58), text: UIColor(red: 1.0, green: 0.78, blue: 0.86, alpha: 1), accent: UIColor(red: 0.92, green: 0.32, blue: 0.52, alpha: 1), blurDark: true)
        case "hailey":
            return .init(background: .clear, key: UIColor(red: 0.22, green: 0.05, blue: 0.08, alpha: 0.58), text: UIColor(red: 1.0, green: 0.78, blue: 0.80, alpha: 1), accent: UIColor(red: 0.86, green: 0.16, blue: 0.22, alpha: 1), blurDark: true)
        case "ember":
            return .init(background: .clear, key: UIColor(red: 0.24, green: 0.12, blue: 0.05, alpha: 0.58), text: UIColor(red: 1.0, green: 0.84, blue: 0.58, alpha: 1), accent: UIColor(red: 0.96, green: 0.50, blue: 0.18, alpha: 1), blurDark: true)
        case "forest":
            return .init(background: .clear, key: UIColor(red: 0.06, green: 0.18, blue: 0.12, alpha: 0.58), text: UIColor(red: 0.70, green: 0.96, blue: 0.76, alpha: 1), accent: UIColor(red: 0.22, green: 0.78, blue: 0.42, alpha: 1), blurDark: true)
        case "matrix":
            return .init(background: .clear, key: UIColor(red: 0.02, green: 0.07, blue: 0.03, alpha: 0.62), text: UIColor(red: 0.28, green: 0.98, blue: 0.36, alpha: 1), accent: UIColor(red: 0.12, green: 0.78, blue: 0.22, alpha: 1), blurDark: true)
        case "nord":
            return .init(background: .clear, key: UIColor(red: 0.78, green: 0.82, blue: 0.86, alpha: 0.72), text: UIColor(red: 0.16, green: 0.20, blue: 0.26, alpha: 1), accent: UIColor(red: 0.36, green: 0.56, blue: 0.70, alpha: 1), blurDark: false)
        case "sunset":
            return .init(background: .clear, key: UIColor(red: 0.65, green: 0.25, blue: 0.45, alpha: 0.55), text: UIColor(red: 1.0, green: 0.92, blue: 0.75, alpha: 1), accent: UIColor(red: 1.0, green: 0.55, blue: 0.30, alpha: 1), blurDark: true)
        case "aurora":
            return .init(background: .clear, key: UIColor(red: 0.06, green: 0.20, blue: 0.28, alpha: 0.58), text: UIColor(red: 0.62, green: 0.98, blue: 0.86, alpha: 1), accent: UIColor(red: 0.20, green: 0.86, blue: 0.72, alpha: 1), blurDark: true)
        case "sakura":
            return .init(background: .clear, key: UIColor(red: 0.96, green: 0.78, blue: 0.84, alpha: 0.72), text: UIColor(red: 0.28, green: 0.14, blue: 0.20, alpha: 1), accent: UIColor(red: 0.92, green: 0.42, blue: 0.62, alpha: 1), blurDark: false)
        case "cyberpunk":
            return .init(background: .clear, key: UIColor(red: 0.06, green: 0.04, blue: 0.14, alpha: 0.72), text: UIColor(red: 0.98, green: 0.98, blue: 0.20, alpha: 1), accent: UIColor(red: 0.20, green: 0.96, blue: 0.98, alpha: 1), blurDark: true)
        case "minimal":
            return .init(background: .clear, key: UIColor(white: 0.96, alpha: 0.88), text: UIColor(white: 0.12, alpha: 1), accent: UIColor(white: 0.36, alpha: 1), blurDark: false)
        case "sepia":
            return .init(background: .clear, key: UIColor(red: 0.88, green: 0.78, blue: 0.60, alpha: 0.82), text: UIColor(red: 0.28, green: 0.18, blue: 0.10, alpha: 1), accent: UIColor(red: 0.62, green: 0.42, blue: 0.22, alpha: 1), blurDark: false)
        case "morning", "m1":
            return Self.tone(0.96, 0.90, 0.78, dark: false)
        case "m2": return Self.tone(0.94, 0.89, 0.72, dark: false)
        case "m3": return Self.tone(0.98, 0.86, 0.76, dark: false)
        case "m4": return Self.tone(0.97, 0.82, 0.64, dark: false)
        case "m5": return Self.tone(0.96, 0.94, 0.88, dark: false)
        case "m6": return Self.tone(0.93, 0.94, 0.96, dark: false)
        case "m7": return Self.tone(0.84, 0.93, 0.88, dark: false)
        case "m8": return Self.tone(0.78, 0.86, 0.76, dark: false)
        case "m9": return Self.tone(0.78, 0.88, 0.96, dark: false)
        case "m10": return Self.tone(0.72, 0.86, 0.90, dark: false)
        case "m11": return Self.tone(0.90, 0.86, 0.96, dark: false)
        case "m12": return Self.tone(0.96, 0.86, 0.90, dark: false)
        case "m13": return Self.tone(0.93, 0.86, 0.68, dark: false)
        case "m14": return Self.tone(0.92, 0.78, 0.52, dark: false)
        case "m15": return Self.tone(0.82, 0.84, 0.68, dark: false)
        case "m16": return Self.tone(0.86, 0.74, 0.62, dark: false)
        case "m17": return Self.tone(0.95, 0.93, 0.89, dark: false)
        case "m18": return Self.tone(0.86, 0.88, 0.90, dark: false)
        case "m19": return Self.tone(0.96, 0.78, 0.74, dark: false)
        case "m20": return Self.tone(0.80, 0.90, 0.78, dark: false)
        case "evening", "e2":
            return Self.tone(0.08, 0.12, 0.24, dark: true, amber: true)
        case "e1": return Self.tone(0.22, 0.23, 0.26, dark: true)
        case "e3": return Self.tone(0.07, 0.09, 0.16, dark: true, amber: true)
        case "e4": return Self.tone(0.10, 0.12, 0.18, dark: true)
        case "e5": return Self.tone(0.18, 0.10, 0.22, dark: true)
        case "e6": return Self.tone(0.24, 0.08, 0.14, dark: true)
        case "e7": return Self.tone(0.08, 0.16, 0.12, dark: true)
        case "e8": return Self.tone(0.06, 0.18, 0.16, dark: true)
        case "e9": return Self.tone(0.06, 0.14, 0.22, dark: true)
        case "e10": return Self.tone(0.10, 0.16, 0.32, dark: true)
        case "e11": return Self.tone(0.22, 0.10, 0.08, dark: true, amber: true)
        case "e12": return Self.tone(0.28, 0.16, 0.10, dark: true, amber: true)
        case "e13": return Self.tone(0.16, 0.10, 0.28, dark: true)
        case "e14": return Self.tone(0.26, 0.08, 0.18, dark: true)
        case "e15": return Self.tone(0.16, 0.18, 0.22, dark: true)
        case "e16": return Self.tone(0.14, 0.14, 0.16, dark: true)
        case "e17": return Self.tone(0.18, 0.12, 0.08, dark: true, amber: true)
        case "e18": return Self.tone(0.20, 0.14, 0.10, dark: true, amber: true)
        case "e19": return Self.tone(0.12, 0.08, 0.20, dark: true)
        case "e20": return Self.tone(0.18, 0.10, 0.12, dark: true, amber: true)
        default:
            return .init(background: .clear, key: UIColor(red: 0.10, green: 0.16, blue: 0.28, alpha: 0.62), text: UIColor(red: 0.93, green: 0.96, blue: 1.0, alpha: 1), accent: UIColor(red: 0.36, green: 0.60, blue: 1.0, alpha: 1), blurDark: true)
        }
    }

    static func tone(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat, dark: Bool, amber: Bool = false) -> NaqraPalette {
        let text: UIColor = dark
            ? (amber ? UIColor(red: 0.96, green: 0.78, blue: 0.42, alpha: 1) : UIColor(white: 0.94, alpha: 1))
            : UIColor(red: 0.22, green: 0.16, blue: 0.10, alpha: 1)
        let accent: UIColor = dark
            ? UIColor(red: 0.82, green: 0.58, blue: 0.22, alpha: 1)
            : UIColor(red: 0.72, green: 0.48, blue: 0.22, alpha: 1)
        let amount: CGFloat = dark ? 0.05 : 0.08
        let key = UIColor(red: r, green: g, blue: b, alpha: dark ? 0.88 : 0.90)
        let background = UIColor(red: max(0, r - amount), green: max(0, g - amount), blue: max(0, b - amount), alpha: 1)
        return .init(background: background, key: key, text: text, accent: accent, blurDark: dark)
    }

    static func customPalette() -> NaqraPalette {
        let key = storedColor("customKey") ?? UIColor(white: 1.0, alpha: 0.16)
        let text = storedColor("customText") ?? UIColor(white: 0.96, alpha: 1)
        let accent = storedColor("customAccent") ?? UIColor(red: 0.55, green: 0.62, blue: 0.70, alpha: 1)
        let dark = storedBool("customBlurDark") ?? true
        return .init(background: .clear, key: key, text: text, accent: accent, blurDark: dark)
    }

    static func storedColor(_ key: String) -> UIColor? {
        let raw = ThemeIO.string(key)
        guard let raw else { return nil }
        let p = raw.split(separator: ",").compactMap { Double($0) }
        guard p.count == 4 else { return nil }
        return UIColor(red: CGFloat(p[0]), green: CGFloat(p[1]), blue: CGFloat(p[2]), alpha: CGFloat(p[3]))
    }

    static func storedBool(_ key: String) -> Bool? {
        return ThemeIO.bool(key)
    }

    static func saveColor(_ color: UIColor, key: String) {
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        color.getRed(&r, green: &g, blue: &b, alpha: &a)
        let raw = "\(r),\(g),\(b),\(a)"
        ThemeIO.write(key, value: raw)
    }

    static func saveTheme(_ id: String) {
        ThemeIO.write("themeId", value: id)
    }

    static func normalizeThemeId(_ raw: String) -> String {
        switch raw {
        case "charcoal", "smoke": return "dark"
        case "teal": return "ocean"
        case "midnight": return "cobalt"
        case "snow": return "light"
        case "clear": return "glass"
        default: return raw
        }
    }

    static func saveBool(_ value: Bool, key: String) {
        ThemeIO.write(key, value: value)
    }

    static func applyHarmony(from base: UIColor) {
        let lum = luminance(base)
        let darkGlass = lum < 0.55
        let text = darkGlass
            ? UIColor(white: 0.97, alpha: 1)
            : UIColor(red: 0.16, green: 0.20, blue: 0.26, alpha: 1)
        let accent = relatedAccent(base, dark: darkGlass)
        saveColor(base, key: "customKey")
        saveColor(text, key: "customText")
        saveColor(accent, key: "customAccent")
        saveBool(darkGlass, key: "customBlurDark")
        saveTheme("custom")
    }

    static func luminance(_ color: UIColor) -> CGFloat {
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        color.getRed(&r, green: &g, blue: &b, alpha: &a)
        return 0.2126 * r + 0.7152 * g + 0.0722 * b
    }

    static func relatedAccent(_ color: UIColor, dark: Bool) -> UIColor {
        var h: CGFloat = 0
        var s: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        if color.getHue(&h, saturation: &s, brightness: &b, alpha: &a) {
            let ns = min(0.55, max(0.18, s * 0.75))
            let nb = dark ? min(0.86, max(0.55, b + 0.28)) : min(0.62, max(0.38, b * 0.72))
            return UIColor(hue: h, saturation: ns, brightness: nb, alpha: 1)
        }
        return dark
            ? UIColor(red: 0.55, green: 0.62, blue: 0.70, alpha: 1)
            : UIColor(red: 0.42, green: 0.58, blue: 0.74, alpha: 1)
    }
}

final class KeyboardViewController: UIInputViewController, UIScrollViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UISearchBarDelegate {
    private var language: KeyboardLanguage = .arabic
    private var page: KeyboardPage = .letters
    private var isShifted = false
    private var symbolPageIndex = 0
    private var emojiCategoryIndex = 0
    private var palette = NaqraPalette.current()
    private var colorSlot = 0
    private var showThemes = false
    private var awaitingPaste = false
    private var showClipboard = false
    private var emojiSearchResults: [String] = []
    private var isSearchingEmoji = false
    private var emojiSearchIndex: [String: [String]] = [:]

    private enum OneHandedSide { case left, right }
    private var oneHandedSide: OneHandedSide?

    private var keyShape: KeyShape {
        KeyShape(rawValue: ThemeIO.string("keyShape") ?? "rounded") ?? .rounded
    }

    private let blurView = UIVisualEffectView(effect: UIBlurEffect(style: .systemUltraThinMaterialDark))
    private let rootStack = UIStackView()
    private var heightConstraint: NSLayoutConstraint?
    private var deleteTimer: Timer?
    private var deleteStartX: CGFloat = 0
    private var lastSpaceTap: Date?
    private let spaceSwitchInterval: TimeInterval = 0.36
    private var spaceStart: CGPoint = .zero
    private var spaceIsTrackpad = false
    private var lastTrackpadX: CGFloat = 0
    private var holdTimer: Timer?
    private var holdSource: UIButton?
    private var holdPopup: UIView?
    private var holdChoice = ""

    private let translationModel = TranslationBridgeModel()
    private var translationHost: UIHostingController<TranslationBridgeView>?
    private var emojiPager: UIScrollView?
    private var emojiTabs: UIStackView?
    private var emojiSearchBar: UISearchBar?
    private var suggestionButtons: [UIButton] = []
    private var appliedThemeId = ""

    private var undoButton: UIButton?
    private var undoTimer: Timer?
    private var lastAutocorrect: (original: String, corrected: String)?

    private let letterFont = UIFont.systemFont(ofSize: 24, weight: .medium)
    private let iconConfig = UIImage.SymbolConfiguration(pointSize: 13, weight: .semibold)
    private let boardHeight: CGFloat = 332

    private let arabicRows = [
        ["ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج"],
        ["ش","س","ي","ب","ل","ا","ت","ن","م","ك","ة"],
        ["ء","ظ","ط","ذ","د","ز","ر","و","ى"]
    ]
    private let arabicShiftRows = [
        ["َ","ً","ُ","ٌ","ِ","ٍ","ْ","ّ","ـ","ٰ","ٓ"],
        ["أ","إ","آ","ى","ء","ؤ","لا","لآ","لأ","لإ","ة"],
        ["،","؛","؟","٪","…","ـ","ى","ئ"]
    ]
    private let englishLower = [
        ["q","w","e","r","t","y","u","i","o","p"],
        ["a","s","d","f","g","h","j","k","l"],
        ["z","x","c","v","b","n","m"]
    ]
    private let englishUpper = [
        ["Q","W","E","R","T","Y","U","I","O","P"],
        ["A","S","D","F","G","H","J","K","L"],
        ["Z","X","C","V","B","N","M"]
    ]
    private let numberRow = ["1","2","3","4","5","6","7","8","9","0"]
    private var symbolPages: [[[String]]] { language == .arabic ? arabicSymbolPages : englishSymbolPages }
    private let arabicSymbolPages = [
        [["1","2","3","4","5","6","7","8","9","0"],
         ["-","/",":","؛","(",")","ر.س","؟","&","@"],
         [".","،","؟","!","'","«","»","٪","…","•"]],
        [["[","]","{","}","#","%","^","*","+","="],
         ["_","\\","|","~","<",">","$","€","£","¥"],
         ["√","π","∞","≤","≥","‰","№","℃","℉","¶"]]
    ]
    private let englishSymbolPages = [
        [["1","2","3","4","5","6","7","8","9","0"],
         ["-","/",":",";","(",")","$","&","@","\""],
         [".",",","?","!","'","\"","+","=","/","•"]],
        [["[","]","{","}","#","%","^","*","+","="],
         ["_","\\","|","~","<",">","€","£","¥","•"],
         ["√","π","∞","≤","≥","‰","№","℃","℉","Ω"]]
    ]
    private let emojiPack: [(icon: String, items: [String])] = KeyboardViewController.catalog()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        configureRoot()
        attachBridge()
        loadPrefs()
        listenPrefs()
        translationModel.onResult = { [weak self] t in self?.applyTranslation(t) }
        armHaptics()
        buildEmojiSearchIndex()
        rebuild()
    }

    deinit {
        CFNotificationCenterRemoveObserver(CFNotificationCenterGetDarwinNotifyCenter(), Unmanaged.passUnretained(self).toOpaque(), CFNotificationName("app.personal.Topclick.prefs" as CFString), nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        armHaptics()
        showAccessHintIfNeeded()
        view.clipsToBounds = true
        let incoming = ThemeIO.string("themeId") ?? "dark"
        if incoming != appliedThemeId {
            appliedThemeId = incoming
            applyIncomingTheme()
        }
    }

    override func textDidChange(_ textInput: UITextInput?) {
        super.textDidChange(textInput)
        refreshSuggestions()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        deleteTimer?.invalidate()
        deleteTimer = nil
    }

    override func updateViewConstraints() {
        if heightConstraint == nil {
            let c = view.heightAnchor.constraint(equalToConstant: boardHeight)
            c.priority = .required
            c.isActive = true
            heightConstraint = c
        }
        super.updateViewConstraints()
    }

    private func persistAccess() {
        ThemeIO.write("hasFullAccess", value: hasFullAccess)
    }
    private func loadPrefs() {
        persistAccess()
        if page != .emoji {
            page = .letters
        }
        let raw = ThemeIO.string("lastLanguage") ?? "ar"
        language = raw == "en" ? .english : .arabic
    }
    private func saveLanguage() {
        ThemeIO.write("lastLanguage", value: language == .english ? "en" : "ar")
    }

    private func listenPrefs() {
        let me = Unmanaged.passUnretained(self).toOpaque()
        CFNotificationCenterAddObserver(
            CFNotificationCenterGetDarwinNotifyCenter(),
            me,
            { _, observer, _, _, _ in
                guard let observer else { return }
                let vc = Unmanaged<KeyboardViewController>.fromOpaque(observer).takeUnretainedValue()
                DispatchQueue.main.async { vc.applyIncomingTheme() }
            },
            "app.personal.Topclick.prefs" as CFString,
            nil,
            .deliverImmediately
        )
    }

    private func applyIncomingTheme() {
        appliedThemeId = ThemeIO.string("themeId") ?? "dark"
        applyPaletteOnly()
    }

    private func applyPaletteOnly() {
        palette = NaqraPalette.current()
        view.backgroundColor = palette.background
        blurView.effect = nil
        blurView.backgroundColor = palette.background
        updateColorsRecursively(in: rootStack)
    }

    private func updateColorsRecursively(in view: UIView) {
        if let button = view as? UIButton {
            let isShiftBtn = button.currentImage?.description.contains("shift") == true
            paint(button, emphasized: isShiftBtn && isShifted)
        }
        for subview in view.subviews {
            updateColorsRecursively(in: subview)
        }
    }

    private var hapticsOn: Bool { ThemeIO.bool("haptics") ?? true }
    private var trackpadOn: Bool { ThemeIO.bool("trackpad") ?? true }
    private enum Pulse { case key, action, del, move }
    private let buzzLight = UIImpactFeedbackGenerator(style: .light)
    private let buzzTick = UISelectionFeedbackGenerator()

    private func armHaptics() {
        guard hapticsOn, hasFullAccess else { return }
        buzzLight.prepare()
        buzzTick.prepare()
    }

    private func tapHaptic(_ pulse: Pulse = .key) {
        guard hapticsOn, hasFullAccess else { return }
        switch pulse {
        case .key:
            buzzTick.selectionChanged()
        case .action:
            buzzLight.impactOccurred(intensity: 0.35)
        case .del:
            buzzLight.impactOccurred(intensity: 0.55)
        case .move:
            buzzTick.selectionChanged()
        }
    }

    private func lockHeight(_ v: UIView, _ h: CGFloat) {
        v.heightAnchor.constraint(equalToConstant: h).isActive = true
        v.setContentHuggingPriority(.required, for: .vertical)
        v.setContentCompressionResistancePriority(.required, for: .vertical)
    }

    private func configureRoot() {
        blurView.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(blurView, at: 0)
        NSLayoutConstraint.activate([
            blurView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            blurView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            blurView.topAnchor.constraint(equalTo: view.topAnchor),
            blurView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        rootStack.axis = .vertical
        rootStack.spacing = 5
        rootStack.distribution = .fill
        rootStack.alignment = .fill
        rootStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(rootStack)
        NSLayoutConstraint.activate([
            rootStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 5),
            rootStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -5),
            rootStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 0)
        ])
        rootStack.setContentHuggingPriority(.required, for: .vertical)
        rootStack.setContentCompressionResistancePriority(.required, for: .vertical)
    }

    private func attachBridge() {
        let host = UIHostingController(rootView: TranslationBridgeView(model: translationModel))
        translationHost = host
        addChild(host)
        host.view.backgroundColor = .clear
        host.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(host.view)
        NSLayoutConstraint.activate([
            host.view.widthAnchor.constraint(equalToConstant: 1),
            host.view.heightAnchor.constraint(equalToConstant: 1),
            host.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            host.view.topAnchor.constraint(equalTo: view.topAnchor)
        ])
        host.didMove(toParent: self)
    }

    private func rebuild() {
        palette = NaqraPalette.current()
        view.backgroundColor = palette.background
        blurView.effect = nil
        blurView.backgroundColor = palette.background
        rootStack.arrangedSubviews.forEach { rootStack.removeArrangedSubview($0); $0.removeFromSuperview() }
        heightConstraint?.constant = boardHeight
        rootStack.addArrangedSubview(makeToolbar())
        if showClipboard {
            rootStack.addArrangedSubview(makeClipboardStrip())
        }
        switch page {
        case .letters:
            rootStack.addArrangedSubview(makeNumberStrip())
            rootStack.addArrangedSubview(makeRow(numberRow, rtl: false))
            let rows = language == .arabic ? (isShifted ? arabicShiftRows : arabicRows) : (isShifted ? englishUpper : englishLower)
            for (i, row) in rows.enumerated() {
                if i == rows.count - 1 { rootStack.addArrangedSubview(makeLastLetterRow(row)) }
                else { rootStack.addArrangedSubview(makeRow(row, rtl: false)) }
            }
            rootStack.addArrangedSubview(makeBottom(title: "#+="))
        case .symbols:
            let rows = symbolPages[min(symbolPageIndex, symbolPages.count - 1)]
            for (i, row) in rows.enumerated() {
                if i == rows.count - 1 {
                    rootStack.addArrangedSubview(makeSymbolLastRow(row))
                } else {
                    rootStack.addArrangedSubview(makeRow(row, rtl: false))
                }
            }
            rootStack.addArrangedSubview(makeBottom(title: "\(symbolPageIndex + 1)/\(symbolPages.count)", letters: true))
        case .emoji:
            rootStack.addArrangedSubview(makeEmojiSearchBar())
            rootStack.addArrangedSubview(makeEmojiTabs())
            rootStack.addArrangedSubview(makeEmojiPager())
            rootStack.addArrangedSubview(makeBottom(title: "#+=", letters: true, emojiOn: true))
        }
        applyWOT()
    }


    private func buildEmojiSearchIndex() {
        emojiSearchIndex.removeAll()
        for pack in emojiPack {
            for emoji in pack.items {
                emojiSearchIndex[emoji, default: []].append(emoji)
                for scalar in emoji.unicodeScalars {
                    if let name = scalar.properties.name {
                        let words = name.lowercased().split(separator: " ").map(String.init)
                        for word in words {
                            emojiSearchIndex[word, default: []].append(emoji)
                        }
                    }
                }
            }
        }
        let manual: [String: [String]] = [
            "قلب": ["❤️","🧡","💛","💚","💙","💜","🖤","🤍"],
            "heart": ["❤️","🧡","💛","💙"],
            "ضحك": ["😂","🤣","😆","😅","😊"],
            "laugh": ["😂","🤣","😆"],
            "حزن": ["😢","😭","😔","☹️"],
            "sad": ["😢","😭","😔"],
            "مطر": ["🌧️","⛈️","☔"],
            "rain": ["🌧️","⛈️","☔"],
            "شمس": ["☀️","🌞","🌅"],
            "sun": ["☀️","🌞","🌅"],
            "قهوة": ["☕"], "coffee": ["☕"],
            "طعام": ["🍔","🍕","🍟","🍣"],
            "food": ["🍔","🍕","🍟"],
            "حيوان": ["🐶","🐱","🐭","🐰"],
            "animal": ["🐶","🐱","🐭"],
            "سيارة": ["🚗","🚕","🚙"],
            "car": ["🚗","🚕","🚙"],
            "مرحبا": ["👋","🤚","✋"],
            "hello": ["👋","🤚","✋"],
            "موسيقى": ["🎵","🎶","🎤","🎧"],
            "music": ["🎵","🎶","🎤"],
            "نجمة": ["⭐","🌟","✨"],
            "star": ["⭐","🌟","✨"],
            "نار": ["🔥","💥"], "fire": ["🔥","💥"]
        ]
        for (k, v) in manual { emojiSearchIndex[k, default: []].append(contentsOf: v) }
    }

    private func reloadAllEmojiCollections() {
        guard let pager = emojiPager else { return }
        for sub in pager.subviews {
            for s in sub.subviews {
                if let cv = s as? UICollectionView { cv.reloadData() }
            }
        }
    }

    private func makeNumberStrip() -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 6
        s.distribution = .fillEqually
        s.semanticContentAttribute = .forceLeftToRight
        let numbers = language == .arabic
            ? ["١","٢","٣","٤","٥","٦","٧","٨","٩","٠"]
            : ["1","2","3","4","5","6","7","8","9","0"]
        for n in numbers {
            let b = charKey(n)
            b.titleLabel?.font = .systemFont(ofSize: 18, weight: .regular)
            b.alpha = 0.85
            s.addArrangedSubview(b)
        }
        lockHeight(s, 34)
        return s
    }

    private func makeToolbar() -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 4
        s.distribution = .fill
        s.semanticContentAttribute = .forceLeftToRight
        let clip = iconKey("doc.on.clipboard", #selector(copyPasteTapped))
        clip.addTarget(self, action: #selector(copyPasteHold), for: .touchDown)
        clip.widthAnchor.constraint(equalToConstant: 32).isActive = true
        s.addArrangedSubview(clip)
        let clipHistory = iconKey("list.bullet", #selector(clipboardTapped))
        clipHistory.widthAnchor.constraint(equalToConstant: 32).isActive = true
        s.addArrangedSubview(clipHistory)
        suggestionButtons = []
        let slot = UIStackView()
        slot.axis = .horizontal
        slot.spacing = 4
        slot.distribution = .fillEqually
        for (i, word) in suggestions().enumerated() {
            let b = UIButton(type: .system)
            b.tag = i
            b.setTitle(word, for: .normal)
            b.isEnabled = !word.isEmpty
            b.titleLabel?.font = .systemFont(ofSize: 14, weight: .semibold)
            b.titleLabel?.adjustsFontSizeToFitWidth = true
            b.titleLabel?.minimumScaleFactor = 0.7
            b.setTitleColor(palette.text, for: .normal)
            b.backgroundColor = palette.key.withAlphaComponent(word.isEmpty ? 0.35 : 1)
            b.layer.cornerRadius = 8
            b.layer.cornerCurve = .circular
            b.addTarget(self, action: #selector(suggestionTapped(_:)), for: .touchUpInside)
            suggestionButtons.append(b)
            slot.addArrangedSubview(b)
        }
        s.addArrangedSubview(slot)
        let tr = iconKey("translate", #selector(translateTapped))
        tr.widthAnchor.constraint(equalToConstant: 32).isActive = true
        s.addArrangedSubview(tr)
        let wot = iconKey("hand.point.up.left", #selector(wotTapped))
        wot.widthAnchor.constraint(equalToConstant: 32).isActive = true
        s.addArrangedSubview(wot)
        let hide = iconKey("keyboard.chevron.compact.down", #selector(dismissKeyboardAction))
        hide.widthAnchor.constraint(equalToConstant: 32).isActive = true
        s.addArrangedSubview(hide)
        lockHeight(s, 36)
        return s
    }

    private func makeClipboardStrip() -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 4
        let scroller = UIScrollView()
        scroller.showsHorizontalScrollIndicator = false
        let inner = UIStackView()
        inner.axis = .horizontal
        inner.spacing = 4
        inner.translatesAutoresizingMaskIntoConstraints = false
        scroller.addSubview(inner)
        for (i, text) in ClipboardHistory.shared.items.enumerated() {
            let b = UIButton(type: .system)
            let preview = text.count > 20 ? String(text.prefix(20)) + "…" : text
            b.setTitle(preview, for: .normal)
            b.titleLabel?.font = .systemFont(ofSize: 12, weight: .medium)
            b.setTitleColor(palette.text, for: .normal)
            b.backgroundColor = palette.key
            b.layer.cornerRadius = 8
            b.contentEdgeInsets = UIEdgeInsets(top: 4, left: 8, bottom: 4, right: 8)
            b.tag = i
            b.addTarget(self, action: #selector(clipboardItemTapped(_:)), for: .touchUpInside)
            inner.addArrangedSubview(b)
        }
        NSLayoutConstraint.activate([
            inner.leadingAnchor.constraint(equalTo: scroller.contentLayoutGuide.leadingAnchor, constant: 2),
            inner.trailingAnchor.constraint(equalTo: scroller.contentLayoutGuide.trailingAnchor, constant: -2),
            inner.topAnchor.constraint(equalTo: scroller.contentLayoutGuide.topAnchor),
            inner.bottomAnchor.constraint(equalTo: scroller.contentLayoutGuide.bottomAnchor),
            inner.heightAnchor.constraint(equalTo: scroller.frameLayoutGuide.heightAnchor)
        ])
        s.addArrangedSubview(scroller)
        lockHeight(s, 40)
        return s
    }

    private func suggestions() -> [String] {
        let before = textDocumentProxy.documentContextBeforeInput ?? ""
        let token = String(before.split { !$0.isLetter && !$0.isNumber }.last ?? "")
        if token.count < 1 { return ["", "", ""] }
        let code = language == .english ? "en_US" : "ar"
        var out = systemGuesses(token, language: code)
        if language == .arabic { out.append(contentsOf: arabicGuesses(token).filter { !$0.isEmpty && !out.contains($0) }) }
        var unique: [String] = []
        for word in out where !unique.contains(word) && word.caseInsensitiveCompare(token) != .orderedSame {
            unique.append(word)
            if unique.count == 3 { break }
        }
        while unique.count < 3 { unique.append("") }
        return unique
    }

    private func systemGuesses(_ token: String, language code: String) -> [String] {
        let checker = UITextChecker()
        let range = NSRange(location: 0, length: token.utf16.count)
        let completions = checker.completions(forPartialWordRange: range, in: token, language: code) ?? []
        let guesses = checker.guesses(forWordRange: range, in: token, language: code) ?? []
        return completions + guesses
    }

    private func arabicGuesses(_ token: String) -> [String] {
        let folded = Self.fold(token)
        var ranked: [(Int, String)] = []
        for word in Self.arabicLexicon {
            let fw = Self.fold(word)
            if fw == folded { ranked.append((0, word)); continue }
            if fw.hasPrefix(folded) { ranked.append((1, word)); continue }
            if Self.near(folded, fw) { ranked.append((2, word)); continue }
        }
        var out: [String] = []
        for pair in ranked.sorted(by: { $0.0 == $1.0 ? $0.1.count < $1.1.count : $0.0 < $1.0 }) where !out.contains(pair.1) {
            out.append(pair.1)
            if out.count == 3 { break }
        }
        while out.count < 3 { out.append("") }
        return out
    }

    private func refreshSuggestions() {
        let words = suggestions()
        guard suggestionButtons.count == words.count else { return }
        for (button, word) in zip(suggestionButtons, words) {
            button.setTitle(word, for: .normal)
            button.isEnabled = !word.isEmpty
            button.backgroundColor = word.isEmpty ? .clear : palette.key
        }
    }

    private static func fold(_ s: String) -> String {
        let map: [Character: Character] = [
            "أ": "ا", "إ": "ا", "آ": "ا", "ى": "ي", "ة": "ه",
            "ؤ": "و", "ئ": "ي", "ٱ": "ا"
        ]
        return String(s.lowercased().map { map[$0] ?? $0 })
    }

    private static func near(_ a: String, _ b: String) -> Bool {
        if abs(a.count - b.count) > 1 { return false }
        if a.count == b.count {
            return zip(a, b).filter { $0 != $1 }.count == 1
        }
        let (short, long) = a.count < b.count ? (a, b) : (b, a)
        var i = 0, skips = 0
        for ch in long {
            if i < short.count, short[short.index(short.startIndex, offsetBy: i)] == ch {
                i += 1
            } else {
                skips += 1
                if skips > 1 { return false }
            }
        }
        return i == short.count
    }

    private static let arabicLexicon = [
        "السلام","عليكم","ورحمة","الله","صباح","الخير","مساء","كيف","حالك",
        "الحمد","شكرا","عفوا","نعم","لا","ممكن","أريد","اليوم",
        "غدا","الآن","هنا","هناك","هذا","هذه","ذلك","التي","الذي","كان",
        "تكون","يكون","بعد","قبل","حتى","عند","بين","كل","بعض","جدا",
        "مرحبا","أهلا","وسهلا","تمام","زين","طيب","يعني","لكن","أيضا",
        "اليمن","صنعاء","كتاب","كتابة","كتب","مدرسة","جامعة","عمل",
        "كيفك","إن شاء","يا","أخي","أختي",
        "وين","متى","ليش","عشان","بكرة","أمس",
        "البيت","الشغل","المدرسة","الجامعة","الشارع","السيارة","الجوال","النت",
        "ماء","أكل","شرب","نوم","صحة","فلوس","وقت","طريق","باب","غرفة",
        "أحب","أبغى","أقدر","ما","في","هذي","تلك",
        "سلام","آسف","موافق","غير","بعدين","الحين"
    ]

    private func makeRow(_ keys: [String], rtl: Bool) -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 6
        s.distribution = .fillEqually
        s.semanticContentAttribute = rtl ? .forceRightToLeft : .forceLeftToRight
        keys.forEach { s.addArrangedSubview(charKey($0)) }
        lockHeight(s, 48)
        return s
    }

    private func makeLastLetterRow(_ keys: [String]) -> UIView {
        return makeActionRow(keys, leadingShift: language == .english)
    }

    private func makeSymbolLastRow(_ keys: [String]) -> UIView {
        return makeActionRow(keys, leadingShift: false)
    }

    private func makeActionRow(_ keys: [String], leadingShift: Bool) -> UIView {
        let wrap = UIStackView()
        wrap.axis = .horizontal
        wrap.spacing = 6
        wrap.semanticContentAttribute = .forceLeftToRight
        if leadingShift {
            let shift = iconKey(isShifted ? "shift.fill" : "shift", #selector(shiftTapped))
            shift.widthAnchor.constraint(equalToConstant: 40).isActive = true
            paint(shift, emphasized: isShifted)
            wrap.addArrangedSubview(shift)
        }
        let mid = UIStackView()
        mid.axis = .horizontal
        mid.spacing = 6
        mid.distribution = .fillEqually
        mid.semanticContentAttribute = .forceLeftToRight
        keys.forEach { mid.addArrangedSubview(charKey($0)) }
        wrap.addArrangedSubview(mid)
        wrap.addArrangedSubview(makeDeleteKey())
        lockHeight(wrap, 48)
        return wrap
    }

    private func makeDeleteKey() -> UIButton {
        let del = iconKey("delete.left", #selector(deleteTouchUp))
        del.addTarget(self, action: #selector(deleteTouchDown), for: .touchDown)
        del.addTarget(self, action: #selector(deleteTouchCancel), for: [.touchUpOutside, .touchCancel])
        del.addTarget(self, action: #selector(deleteDrag(_:event:)), for: .touchDragInside)
        del.addTarget(self, action: #selector(deleteDrag(_:event:)), for: .touchDragOutside)
        del.widthAnchor.constraint(equalToConstant: 54).isActive = true
        return del
    }

    private func makeBottom(title: String, letters: Bool = false, emojiOn: Bool = false) -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 6
        s.semanticContentAttribute = .forceLeftToRight
        let symbolsTitle: String
        if page == .symbols {
            symbolsTitle = "\(symbolPageIndex + 1)/\(symbolPages.count)"
        } else if page == .emoji {
            symbolsTitle = "رجوع"
        } else {
            symbolsTitle = "123"
        }
        let symbols = control(symbolsTitle, #selector(symbolsOrLettersTapped), font: 13)
        symbols.widthAnchor.constraint(equalToConstant: 46).isActive = true
        let emoji = UIButton(type: .system)
        emoji.setTitle("😊", for: .normal)
        emoji.titleLabel?.font = .systemFont(ofSize: 20)
        paint(emoji)
        emoji.addTarget(self, action: #selector(emojiTapped), for: .touchUpInside)
        emoji.widthAnchor.constraint(equalToConstant: 44).isActive = true
        let space = control(" ", #selector(spaceTouchUp), font: 14)
        space.setTitle("", for: .normal)
        space.addTarget(self, action: #selector(spaceTouchDown(_:event:)), for: .touchDown)
        space.addTarget(self, action: #selector(spaceDrag(_:event:)), for: .touchDragInside)
        space.addTarget(self, action: #selector(spaceDrag(_:event:)), for: .touchDragOutside)
        space.setContentHuggingPriority(.defaultLow, for: .horizontal)
        space.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        let enter = iconKey("arrow.down.to.line", #selector(enterTapped))
        enter.widthAnchor.constraint(equalToConstant: 46).isActive = true
        s.addArrangedSubview(symbols)
        s.addArrangedSubview(emoji)
        s.addArrangedSubview(space)
        if emojiOn {
            s.addArrangedSubview(makeDeleteKey())
        } else {
            let period = control(language == .arabic ? "؟" : ".", #selector(periodTapped), font: 20)
            period.widthAnchor.constraint(equalToConstant: 36).isActive = true
            s.addArrangedSubview(period)
        }
        s.addArrangedSubview(enter)
        lockHeight(s, 48)
        return s
    }

    private func makeEmojiSearchBar() -> UIView {
        let bar = UISearchBar()
        bar.placeholder = "ابحث عن إيموجي..."
        bar.barStyle = .black
        bar.delegate = self
        emojiSearchBar = bar
        lockHeight(bar, 40)
        return bar
    }

    private func makeEmojiTabs() -> UIView {
        let wrap = UIStackView()
        wrap.axis = .horizontal
        wrap.spacing = 6
        wrap.semanticContentAttribute = .forceLeftToRight
        let scroller = UIScrollView()
        scroller.showsHorizontalScrollIndicator = false
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 4
        s.translatesAutoresizingMaskIntoConstraints = false
        scroller.addSubview(s)
        emojiTabs = s
        for (i, pack) in emojiPack.enumerated() {
            let b = control(pack.icon, #selector(emojiTab(_:)), font: 18)
            b.tag = i
            b.backgroundColor = i == emojiCategoryIndex ? UIColor.white.withAlphaComponent(0.22) : .clear
            b.widthAnchor.constraint(equalToConstant: 38).isActive = true
            s.addArrangedSubview(b)
        }
        NSLayoutConstraint.activate([
            s.leadingAnchor.constraint(equalTo: scroller.contentLayoutGuide.leadingAnchor, constant: 2),
            s.trailingAnchor.constraint(equalTo: scroller.contentLayoutGuide.trailingAnchor, constant: -2),
            s.topAnchor.constraint(equalTo: scroller.contentLayoutGuide.topAnchor),
            s.bottomAnchor.constraint(equalTo: scroller.contentLayoutGuide.bottomAnchor),
            s.heightAnchor.constraint(equalTo: scroller.frameLayoutGuide.heightAnchor)
        ])
        wrap.addArrangedSubview(scroller)
        lockHeight(wrap, 32)
        return wrap
    }

    private func makeEmojiPager() -> UIView {
        let pager = UIScrollView()
        pager.isPagingEnabled = true
        pager.showsHorizontalScrollIndicator = false
        pager.delegate = self
        pager.translatesAutoresizingMaskIntoConstraints = false
        emojiPager = pager
        lockHeight(pager, 196)
        let host = UIView()
        host.translatesAutoresizingMaskIntoConstraints = false
        pager.addSubview(host)
        NSLayoutConstraint.activate([
            host.topAnchor.constraint(equalTo: pager.contentLayoutGuide.topAnchor),
            host.bottomAnchor.constraint(equalTo: pager.contentLayoutGuide.bottomAnchor),
            host.leadingAnchor.constraint(equalTo: pager.contentLayoutGuide.leadingAnchor),
            host.trailingAnchor.constraint(equalTo: pager.contentLayoutGuide.trailingAnchor),
            host.heightAnchor.constraint(equalTo: pager.frameLayoutGuide.heightAnchor)
        ])
        var previous: UIView?
        for i in 0..<emojiPack.count {
            let layout = UICollectionViewFlowLayout()
            layout.minimumInteritemSpacing = 1
            layout.minimumLineSpacing = 1
            layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
            let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
            cv.backgroundColor = .clear
            cv.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 16, right: 0)
            cv.alwaysBounceVertical = true
            cv.dataSource = self
            cv.delegate = self
            cv.tag = i
            cv.register(EmojiCell.self, forCellWithReuseIdentifier: "e")
            cv.translatesAutoresizingMaskIntoConstraints = false
            host.addSubview(cv)
            NSLayoutConstraint.activate([
                cv.topAnchor.constraint(equalTo: host.topAnchor),
                cv.bottomAnchor.constraint(equalTo: host.bottomAnchor),
                cv.widthAnchor.constraint(equalTo: pager.frameLayoutGuide.widthAnchor),
                cv.heightAnchor.constraint(equalTo: host.heightAnchor)
            ])
            if let previous {
                cv.leadingAnchor.constraint(equalTo: previous.trailingAnchor).isActive = true
            } else {
                cv.leadingAnchor.constraint(equalTo: host.leadingAnchor).isActive = true
            }
            if i == emojiPack.count - 1 {
                cv.trailingAnchor.constraint(equalTo: host.trailingAnchor).isActive = true
            }
            previous = cv
        }
        DispatchQueue.main.async { [weak self] in
            guard let self, let pager = self.emojiPager else { return }
            pager.setContentOffset(CGPoint(x: CGFloat(self.emojiCategoryIndex) * pager.bounds.width, y: 0), animated: false)
        }
        return pager
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if query.isEmpty {
            isSearchingEmoji = false
            emojiSearchResults = []
            emojiPager?.isScrollEnabled = true
            reloadAllEmojiCollections()
            return
        }
        isSearchingEmoji = true
        var results: [String] = []
        var seen = Set<String>()
        for (key, emojis) in emojiSearchIndex where key.contains(query) {
            for e in emojis where seen.insert(e).inserted { results.append(e) }
        }
        emojiSearchResults = results
        emojiPager?.isScrollEnabled = false
        emojiPager?.setContentOffset(.zero, animated: false)
        reloadAllEmojiCollections()
    }

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        guard scrollView === emojiPager, scrollView.bounds.width > 0 else { return }
        let idx = Int(round(scrollView.contentOffset.x / scrollView.bounds.width))
        emojiCategoryIndex = min(max(idx, 0), emojiPack.count - 1)
        refreshTabs()
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if isSearchingEmoji {
            return collectionView.tag == 0 ? emojiSearchResults.count : 0
        }
        return emojiPack[collectionView.tag].items.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "e", for: indexPath) as! EmojiCell
        if isSearchingEmoji {
            cell.label.text = emojiSearchResults[indexPath.item]
        } else {
            cell.label.text = emojiPack[collectionView.tag].items[indexPath.item]
        }
        cell.paint(palette)
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let item = isSearchingEmoji ? emojiSearchResults[indexPath.item] : emojiPack[collectionView.tag].items[indexPath.item]
        textDocumentProxy.insertText(item)
        rememberEmoji(item)
        tapHaptic()
        TapSoundEngine.shared.play(.emoji)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let itemWidth = floor((collectionView.bounds.width - 2 - 8) / 9)
        return CGSize(width: max(itemWidth, 30), height: 30)
    }

    private func refreshTabs() {
        guard let tabs = emojiTabs else { return }
        for (i, view) in tabs.arrangedSubviews.enumerated() {
            view.backgroundColor = i == emojiCategoryIndex ? UIColor.white.withAlphaComponent(0.22) : .clear
        }
    }

    @objc private func emojiTab(_ sender: UIButton) {
        if isSearchingEmoji {
            isSearchingEmoji = false
            emojiSearchResults = []
            emojiSearchBar?.text = ""
            emojiSearchBar?.resignFirstResponder()
            emojiPager?.isScrollEnabled = true
            reloadAllEmojiCollections()
        }
        emojiCategoryIndex = sender.tag
        refreshTabs()
        guard let pager = emojiPager else { return }
        pager.setContentOffset(CGPoint(x: CGFloat(sender.tag) * pager.bounds.width, y: 0), animated: true)
    }

    private func paint(_ b: UIButton, emphasized: Bool = false) {
        if emphasized {
            b.backgroundColor = palette.accent.withAlphaComponent(0.72)
        } else {
            b.backgroundColor = palette.key
        }
        b.setTitleColor(emphasized ? .white : palette.text, for: .normal)
        b.tintColor = emphasized ? .white : palette.text
        b.layer.cornerRadius = keyShape.cornerRadius
        b.layer.cornerCurve = .circular
        b.layer.borderWidth = 0.6
        let line = palette.blurDark ? UIColor.white.withAlphaComponent(0.20) : UIColor.black.withAlphaComponent(0.10)
        b.layer.borderColor = line.cgColor
        b.clipsToBounds = true
    }

    private func attachPress(_ b: UIButton) {
        b.addTarget(self, action: #selector(keyPressDown(_:)), for: .touchDown)
        b.addTarget(self, action: #selector(keyPressUp(_:)), for: [.touchUpInside, .touchUpOutside, .touchCancel])
    }

    @objc private func keyPressDown(_ sender: UIButton) {
        sender.alpha = 0.85
        let ripple = UIView()
        ripple.backgroundColor = UIColor.white.withAlphaComponent(0.35)
        ripple.frame = sender.bounds
        ripple.layer.cornerRadius = sender.layer.cornerRadius
        ripple.alpha = 1
        sender.addSubview(ripple)
        UIView.animate(withDuration: 0.25, animations: {
            ripple.alpha = 0
            ripple.transform = CGAffineTransform(scaleX: 1.4, y: 1.4)
        }, completion: { _ in
            ripple.removeFromSuperview()
        })
    }

    @objc private func keyPressUp(_ sender: UIButton) {
        sender.alpha = 1.0
    }

    private let holdMap: [String: [String]] = [
        "ا": ["أ", "إ", "آ", "ء", "ى"],
        "و": ["ؤ"],
        "ي": ["ئ", "ى"],
        "ى": ["ئ", "ي"],
        "ه": ["ة"],
        "ل": ["لا", "لأ", "لإ", "لآ"],
        "ة": ["ه"],
        "ئ": ["ء", "ي"],
        "أ": ["إ", "آ", "ء", "ا"],
        "ؤ": ["و", "ء"],
        ".": ["…", "•"],
        "-": ["–", "—"],
        ",": ["،"],
        ";": ["؛"],
        "?": ["؟"],
        "!": ["؟"],
        "%": ["٪"],
        "'": ["’", "‘"]
    ]

    private func alts(for key: String) -> [String] {
        if key == "\"" { return ["«", "»"] }
        return holdMap[key] ?? []
    }

    private func charKey(_ t: String) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(t, for: .normal)
        b.titleLabel?.font = letterFont
        paint(b)
        attachPress(b)
        b.addTarget(self, action: #selector(charDown(_:)), for: .touchDown)
        b.addTarget(self, action: #selector(charDrag(_:event:)), for: .touchDragInside)
        b.addTarget(self, action: #selector(charDrag(_:event:)), for: .touchDragOutside)
        b.addTarget(self, action: #selector(charUp(_:)), for: [.touchUpInside, .touchUpOutside, .touchCancel])
        return b
    }

    private func control(_ t: String, _ a: Selector, font: CGFloat) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(t, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: font, weight: .semibold)
        paint(b)
        attachPress(b)
        b.addTarget(self, action: a, for: .touchUpInside)
        return b
    }

    private func iconKey(_ name: String, _ a: Selector) -> UIButton {
        let b = UIButton(type: .system)
        let symbol = UIImage(systemName: name, withConfiguration: iconConfig)
            ?? UIImage(systemName: fallbackSymbol(name), withConfiguration: iconConfig)
        b.setImage(symbol, for: .normal)
        paint(b, emphasized: name.contains("shift.fill") && isShifted)
        attachPress(b)
        b.addTarget(self, action: a, for: .touchUpInside)
        return b
    }

    private func fallbackSymbol(_ name: String) -> String {
        switch name {
        case "translate": return "globe"
        case "paintpalette": return "paintbrush"
        case "doc.on.clipboard": return "doc.on.doc"
        case "arrow.down.to.line": return "arrow.down"
        default: return "circle"
        }
    }

    @objc private func charDown(_ sender: UIButton) {
        holdSource = sender
        holdChoice = sender.title(for: .normal) ?? ""
        holdTimer?.invalidate()
        hideHoldPopup()
        guard let key = sender.title(for: .normal), !alts(for: key).isEmpty else { return }
        holdTimer = Timer.scheduledTimer(withTimeInterval: 0.38, repeats: false) { [weak self] _ in
            self?.showHoldPopup(from: sender)
        }
    }

    @objc private func charDrag(_ sender: UIButton, event: UIEvent) {
        guard let popup = holdPopup, let touch = event.allTouches?.first else { return }
        let p = touch.location(in: popup)
        for v in popup.subviews {
            guard let b = v as? UIButton else { continue }
            let inside = b.frame.insetBy(dx: -4, dy: -10).contains(p)
            b.backgroundColor = inside ? UIColor.white.withAlphaComponent(0.28) : .clear
            if inside { holdChoice = b.title(for: .normal) ?? holdChoice }
        }
    }

    @objc private func charUp(_ sender: UIButton) {
        holdTimer?.invalidate()
        holdTimer = nil
        let text = holdPopup != nil ? holdChoice : (sender.title(for: .normal) ?? "")
        hideHoldPopup()
        holdSource = nil
        guard !text.isEmpty else { return }
        textDocumentProxy.insertText(text)
        tapHaptic()
        TapSoundEngine.shared.play(.rowHigh)
        if page == .letters, language == .english, isShifted {
            isShifted = false
            applyPaletteOnly()
        }
    }

    private func showHoldPopup(from button: UIButton) {
        guard let key = button.title(for: .normal) else { return }
        let items = alts(for: key)
        guard !items.isEmpty else { return }
        hideHoldPopup()
        let bar = UIStackView()
        bar.axis = .horizontal
        bar.spacing = 4
        bar.alignment = .center
        bar.translatesAutoresizingMaskIntoConstraints = false
        bar.backgroundColor = UIColor.black.withAlphaComponent(0.82)
        bar.layer.cornerRadius = 12
        bar.layer.cornerCurve = .continuous
        bar.isLayoutMarginsRelativeArrangement = true
        bar.layoutMargins = UIEdgeInsets(top: 6, left: 6, bottom: 6, right: 6)
        holdChoice = items[0]
        for (i, item) in items.enumerated() {
            let b = UIButton(type: .system)
            b.setTitle(item, for: .normal)
            b.titleLabel?.font = .systemFont(ofSize: 24, weight: .medium)
            b.setTitleColor(.white, for: .normal)
            b.backgroundColor = i == 0 ? UIColor.white.withAlphaComponent(0.28) : .clear
            b.layer.cornerRadius = 8
            bar.addArrangedSubview(b)
        }
        view.addSubview(bar)
        let frame = button.convert(button.bounds, to: view)
        NSLayoutConstraint.activate([
            bar.bottomAnchor.constraint(equalTo: view.topAnchor, constant: frame.minY - 6),
            bar.heightAnchor.constraint(equalToConstant: 44)
        ])
        let center = bar.centerXAnchor.constraint(equalTo: view.leadingAnchor, constant: frame.midX)
        center.priority = .defaultHigh
        center.isActive = true
        bar.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 6).isActive = true
        bar.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -6).isActive = true
        holdPopup = bar
        tapHaptic()
    }

    private func hideHoldPopup() {
        holdPopup?.removeFromSuperview()
        holdPopup = nil
    }

    @objc private func shiftTapped() {
        isShifted.toggle()
        rebuild()
    }

    @objc private func deleteTouchDown() {
        textDocumentProxy.deleteBackward()
        tapHaptic(.del)
        TapSoundEngine.shared.play(.delete)
        deleteTimer?.invalidate()
        deleteTimer = Timer.scheduledTimer(withTimeInterval: 0.35, repeats: false) { [weak self] _ in
            self?.deleteTimer = Timer.scheduledTimer(withTimeInterval: 0.07, repeats: true) { [weak self] _ in
                self?.textDocumentProxy.deleteBackward()
            }
        }
    }

    @objc private func deleteTouchUp() {
        deleteTimer?.invalidate()
        deleteTimer = nil
        deleteStartX = 0
    }

    @objc private func deleteDrag(_ sender: UIButton, event: UIEvent) {
        guard let touch = event.allTouches?.first else { return }
        let x = touch.location(in: sender).x
        if deleteStartX == 0 { deleteStartX = x }
        if deleteStartX - x > 28 {
            deleteStartX = x
            let before = textDocumentProxy.documentContextBeforeInput ?? ""
            let token = String(before.split { $0 == " " || $0 == "\n" }.last ?? "")
            let n = max(token.count + 1, 1)
            for _ in 0..<n { textDocumentProxy.deleteBackward() }
        }
    }

    @objc private func deleteTouchCancel() {
        deleteTimer?.invalidate()
        deleteTimer = nil
        deleteStartX = 0
    }

    @objc private func spaceTouchDown(_ sender: UIButton, event: UIEvent) {
        spaceIsTrackpad = false
        if let t = event.allTouches?.first {
            spaceStart = t.location(in: sender)
            lastTrackpadX = spaceStart.x
        }
    }

    @objc private func spaceDrag(_ sender: UIButton, event: UIEvent) {
        guard trackpadOn, let t = event.allTouches?.first else { return }
        let p = t.location(in: sender)
        if abs(p.x - spaceStart.x) > 10 { spaceIsTrackpad = true }
        guard spaceIsTrackpad else { return }
        let delta = p.x - lastTrackpadX
        if abs(delta) >= 12 {
            textDocumentProxy.adjustTextPosition(byCharacterOffset: delta > 0 ? 1 : -1)
            lastTrackpadX = p.x
            tapHaptic(.move)
        }
    }

    private func knownWord(_ token: String) -> Bool {
        if language == .english {
            let checker = UITextChecker()
            let range = NSRange(location: 0, length: token.utf16.count)
            let miss = checker.rangeOfMisspelledWord(in: token, range: range, startingAt: 0, wrap: false, language: "en_US")
            return miss.location == NSNotFound
        }
        let folded = Self.fold(token)
        return Self.arabicLexicon.contains { Self.fold($0) == folded }
    }

    private func isUserWord(_ word: String) -> Bool {
        let raw = ThemeIO.string("userWords") ?? ""
        for line in raw.split(separator: "\n") {
            let parts = line.split(separator: "|")
            if parts.count == 2, String(parts[0]) == word, let n = Int(parts[1]), n >= 2 { return true }
        }
        return false
    }

    private func rememberUserWord(_ word: String) {
        var counts: [String: Int] = [:]
        let raw = ThemeIO.string("userWords") ?? ""
        for line in raw.split(separator: "\n") {
            let parts = line.split(separator: "|")
            if parts.count == 2, let n = Int(parts[1]) {
                counts[String(parts[0])] = n
            }
        }
        counts[word, default: 0] += 1
        let sorted = counts.sorted { $0.value > $1.value }.prefix(300)
        let encoded = sorted.map { "\($0.key)|\($0.value)" }.joined(separator: "\n")
        ThemeIO.write("userWords", value: encoded)
    }

    private func applyAutocorrectIfNeeded() {
        guard ThemeIO.bool("autocorrect") ?? false else { return }
        let before = textDocumentProxy.documentContextBeforeInput ?? ""
        let token = String(before.split { !$0.isLetter && !$0.isNumber }.last ?? "")
        guard token.count >= 3 else { return }
        guard !knownWord(token) else { return }
        guard !isUserWord(token) else { return }
        guard let fix = bestGuess(for: token), fix != token else { return }
        for _ in 0..<token.count { textDocumentProxy.deleteBackward() }
        textDocumentProxy.insertText(fix)
        lastAutocorrect = (token, fix)
        showUndoButton(original: token)
    }

    private func bestGuess(for token: String) -> String? {
        let checker = UITextChecker()
        let range = NSRange(location: 0, length: token.utf16.count)
        let lang = language == .arabic ? "ar" : "en_US"
        let guesses = checker.guesses(forWordRange: range, in: token, language: lang) ?? []
        if let first = guesses.first, first.caseInsensitiveCompare(token) != .orderedSame { return first }
        if language == .arabic {
            return arabicGuesses(token).first { !$0.isEmpty && $0 != token }
        }
        return nil
    }

    private func showUndoButton(original: String) {
        undoButton?.removeFromSuperview()
        undoTimer?.invalidate()
        let btn = UIButton(type: .system)
        let preview = original.count > 12 ? String(original.prefix(12)) + "…" : original
        btn.setTitle("↩︎ \(preview)", for: .normal)
        btn.titleLabel?.font = .systemFont(ofSize: 12, weight: .medium)
        btn.setTitleColor(.white, for: .normal)
        btn.backgroundColor = palette.accent.withAlphaComponent(0.85)
        btn.layer.cornerRadius = 8
        btn.contentEdgeInsets = UIEdgeInsets(top: 4, left: 8, bottom: 4, right: 8)
        btn.addTarget(self, action: #selector(undoAutocorrect), for: .touchUpInside)
        btn.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(btn)
        NSLayoutConstraint.activate([
            btn.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -8),
            btn.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -60),
            btn.heightAnchor.constraint(equalToConstant: 28)
        ])
        undoButton = btn
        undoTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { [weak self] _ in
            self?.undoButton?.removeFromSuperview()
            self?.undoButton = nil
        }
    }

    @objc private func undoAutocorrect() {
        guard let last = lastAutocorrect else { return }
        for _ in 0..<last.corrected.count { textDocumentProxy.deleteBackward() }
        textDocumentProxy.insertText(last.original)
        rememberUserWord(last.original)
        lastAutocorrect = nil
        undoButton?.removeFromSuperview()
        undoButton = nil
        undoTimer?.invalidate()
        tapHaptic()
    }

    @objc private func spaceTouchUp() {
        if spaceIsTrackpad {
            spaceIsTrackpad = false
            return
        }
        let now = Date()
        if let last = lastSpaceTap, now.timeIntervalSince(last) <= spaceSwitchInterval {
            lastSpaceTap = nil
            language = language == .arabic ? .english : .arabic
            isShifted = false
            symbolPageIndex = 0
            saveLanguage()
            if page != .emoji { page = .letters }
            rebuild()
            tapHaptic()
            return
        }
        lastSpaceTap = now
        applyAutocorrectIfNeeded()
        textDocumentProxy.insertText(" ")
        tapHaptic()
        TapSoundEngine.shared.play(.space)
    }

    @objc private func periodTapped() {
        textDocumentProxy.insertText(language == .arabic ? "؟" : ".")
        tapHaptic(.action)
        TapSoundEngine.shared.play(.rowMid)
    }

    @objc private func enterTapped() {
        textDocumentProxy.insertText("\n")
        tapHaptic(.action)
        TapSoundEngine.shared.play(.enter)
    }

    @objc private func emojiTapped() {
        page = (page == .emoji) ? .letters : .emoji
        rebuild()
        tapHaptic()
    }

    @objc private func symbolsOrLettersTapped() {
        switch page {
        case .letters:
            page = .symbols
            symbolPageIndex = 0
        case .symbols:
            if symbolPageIndex < symbolPages.count - 1 {
                symbolPageIndex += 1
            } else {
                page = .letters
                symbolPageIndex = 0
            }
        case .emoji:
            page = .letters
        }
        rebuild()
    }

    @objc private func copyPasteTapped() {
        if awaitingPaste { return }
        copyNow()
    }

    @objc private func copyPasteHold() {
        awaitingPaste = false
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(armPaste), object: nil)
        perform(#selector(armPaste), with: nil, afterDelay: 0.38)
    }

    @objc private func armPaste() {
        awaitingPaste = true
        pasteNow()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { [weak self] in
            self?.awaitingPaste = false
        }
    }

    private func copyNow() {
        guard hasFullAccess else { return }
        persistAccess()
        let selected = textDocumentProxy.selectedText
        let text = (selected?.isEmpty == false ? selected : nil) ?? combined()
        guard let text, !text.isEmpty else { return }
        UIPasteboard.general.string = text
        ClipboardHistory.shared.add(text)
        tapHaptic()
    }

    private func pasteNow() {
        guard hasFullAccess else { return }
        persistAccess()
        if let t = UIPasteboard.general.string, !t.isEmpty {
            textDocumentProxy.insertText(t)
            tapHaptic()
        }
    }

    @objc private func clipboardTapped() {
        showClipboard.toggle()
        rebuild()
        tapHaptic()
    }

    @objc private func clipboardItemTapped(_ sender: UIButton) {
        let items = ClipboardHistory.shared.items
        guard sender.tag < items.count else { return }
        textDocumentProxy.insertText(items[sender.tag])
        tapHaptic()
    }

    @objc private func wotTapped() {
        switch oneHandedSide {
        case .none: oneHandedSide = .right
        case .right: oneHandedSide = .left
        case .left: oneHandedSide = nil
        }
        applyWOT()
        tapHaptic()
    }

    private func applyWOT() {
        let shift: CGFloat = 60
        switch oneHandedSide {
        case .right: rootStack.transform = CGAffineTransform(translationX: shift, y: 0)
        case .left: rootStack.transform = CGAffineTransform(translationX: -shift, y: 0)
        case .none: rootStack.transform = .identity
        }
    }

    @objc private func translateTapped() {
        guard hasFullAccess else { return }
        persistAccess()
        let selected = textDocumentProxy.selectedText
        let text = (selected?.isEmpty == false ? selected : nil)
            ?? textDocumentProxy.documentContextBeforeInput
            ?? combined()
        guard let text, !text.isEmpty else { return }
        let ar = text.unicodeScalars.filter { $0.value >= 0x0600 && $0.value <= 0x06FF }.count
        let toEn = ar >= max(1, text.count / 4)
        translationModel.sourceLang = toEn ? "ar" : "en"
        translationModel.targetLang = toEn ? "en" : "ar"
        translationModel.sourceText = text
        translationModel.token += 1
    }

    private func applyTranslation(_ text: String) {
        guard !text.isEmpty else { return }
        if let selected = textDocumentProxy.selectedText, !selected.isEmpty {
            textDocumentProxy.deleteBackward()
            textDocumentProxy.insertText(text)
            return
        }
        if let before = textDocumentProxy.documentContextBeforeInput {
            for _ in 0..<before.count { textDocumentProxy.deleteBackward() }
        }
        textDocumentProxy.insertText(text)
    }

    private func combined() -> String? {
        let v = (textDocumentProxy.documentContextBeforeInput ?? "") + (textDocumentProxy.documentContextAfterInput ?? "")
        return v.isEmpty ? nil : v
    }

    @objc private func dismissKeyboardAction() {
        dismissKeyboard()
    }

    @objc private func suggestionTapped(_ sender: UIButton) {
        guard let word = sender.title(for: .normal), !word.isEmpty else { return }
        let before = textDocumentProxy.documentContextBeforeInput ?? ""
        let token = String(before.split { !$0.isLetter && !$0.isNumber }.last ?? "")
        if !token.isEmpty {
            for _ in 0..<token.count { textDocumentProxy.deleteBackward() }
        }
        textDocumentProxy.insertText(word)
        tapHaptic()
    }

    private func showAccessHintIfNeeded() {
        guard !hasFullAccess else { return }
        guard !(ThemeIO.bool("shownAccessHint") ?? false) else { return }
        ThemeIO.write("shownAccessHint", value: true)
        let label = UILabel()
        label.text = "فعّل الوصول الكامل من الإعدادات ← عام ← لوحة المفاتيح ← نقرة"
        label.numberOfLines = 2
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 11, weight: .medium)
        label.textColor = .white
        label.backgroundColor = UIColor.black.withAlphaComponent(0.78)
        label.layer.cornerRadius = 10
        label.layer.masksToBounds = true
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 8),
            label.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -8),
            label.topAnchor.constraint(equalTo: view.topAnchor, constant: 4),
            label.heightAnchor.constraint(equalToConstant: 42)
        ])
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            UIView.animate(withDuration: 0.4, animations: { label.alpha = 0 }, completion: { _ in label.removeFromSuperview() })
        }
    }

    private static func loadFrequent() -> [String] {
        let raw = ThemeIO.string("frequentEmoji") ?? "😀 😂 ❤️ 😍 🔥 👍 🙏 😊 ✨ 😭 👏 💕 🌹 🇾🇪 🎉 😎 🤔 😅 😁 😘 💪 ✌️ 💯 🤍"
        let items = raw.split(separator: " ").map(String.init)
        return Array(items.prefix(24))
    }

    private func rememberEmoji(_ item: String) {
        var items = (ThemeIO.string("frequentEmoji") ?? "").split(separator: " ").map(String.init)
        items.removeAll { $0 == item }
        items.insert(item, at: 0)
        ThemeIO.write("frequentEmoji", value: items.prefix(32).joined(separator: " "))
    }

    private static func catalog() -> [(icon: String, items: [String])] {
        func s(_ t: String) -> [String] { t.split(separator: " ").map(String.init) }
        let frequent = loadFrequent()
        return [
            ("🕒", frequent),
            ("😊", s("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 🫠 🫡 🫢 🫣 🫤 🥹 🥲 😵‍💫 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 🤡 👻 💀 👽 🤖 🎃 😺 😸 😹 😻 😼 😽")),
            ("👋", s("👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 👏 🙌 👐 🤲 🤝 🙏 🫰 🫶 🫵 🤜 🤛 🫳 🫴 ✍️ 💅 💪 👂 👃 👀 👶 👧 👦 👩 🧑 👨 👵 👴 👮 👷 👸 🤴 🦸 🎅 🧙 🧚 👼 🚶 🏃 💃 🕺 🧘 👪")),
            ("❤️", s("❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❤️‍🩹 🫀 🩶 🩷 🩵 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ⭐ 🌟 ✨ ⚡ 🔥 💯 ✅ ❌ ❓ ❗")),
            ("🐾", s("🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🐤 🦆 🦉 🐝 🦋 🐞 🐢 🐍 🐙 🐠 🐬 🐳 🦈 🐘 🦒 🦌 🐄 🐇 🌸 🌹 🌻 🌷 🍀 🌿 🍁 🍂")),
            ("🍔", s("🍏 🍎 🍊 🍋 🍌 🍉 🍇 🍓 🍑 🍍 🥝 🍅 🥑 🥕 🌽 🍞 🧀 🥚 🍳 🥞 🥓 🍔 🍟 🍕 🌮 🌯 🥗 🍝 🍜 🍣 🍱 🍦 🍩 🍪 🎂 🍫 🍿 ☕ 🍵 🧃 🥤")),
            ("✈️", s("🚗 🚕 🚌 🚓 🚑 🚚 🚲 🏍️ ✈️ 🚀 🚁 ⛵ 🚢 🏠 🏢 🏥 🏫 🕌 🕋 🗽 🗼 🏰 🎡 ⛺ 🌅 🌃 🌈 ☀️ ⛅ ☁️ 🌧️ ❄️")),
            ("⚽", s("⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 ⛳ 🎯 🎮 🎲 🏆 🥇 🥈 🥉 🎨 🎬 🎤 🎧 🎹 🎸 🥁")),
            ("💡", s("⌚ 📱 💻 📷 🎥 💡 🔒 🔑 🎁 🎈 🎉 📦 📚 ✏️ 💼 🛒")),
            ("⭐", s("⭐ 🌟 ✨ ⚡ 🔥 💧 🌈 ✅ ❌ ❓ ❗ 💯 🔔 💬 ⚪ ⚫ 🔴 🔵 🟢 🟡")),
            ("🌙", s("🌙 🌛 🌜 🌝 🌞 ⭐ 🌟 🌠 🌌 🪐 🌍 🌎 🌏 🌐 🌑 🌒 🌓 🌔 🌕 🌖 🌗 🌘")),
            ("😀", s("🥲 🥹 😵 😵‍💫 🥴 🤢 🤮 🤧 🥵 🥶 😱 🤯 🥳 🤩 🤪 🤫 🤭 🤗 🤔 🫡 🫢 🫣 🫤 🫥 🫨")),
            ("🇾🇪", s("🇾🇪 🇸🇦 🇯🇴 🇵🇸 🇱🇧 🇸🇾 🇮🇶 🇦🇪 🇶🇦 🇰🇼 🇧🇭 🇴🇲 🇹🇷 🇺🇸 🇬🇧 🇫🇷 🇩🇪 🇯🇵 🇰🇷 🇮🇳 🇵🇰 🇮🇩 🇲🇾 🇺🇳 🏳️ 🏴 🏁"))
        ]
    }
}

final class EmojiCell: UICollectionViewCell {
    let label = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 28)
        label.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])
        contentView.backgroundColor = .clear
        contentView.layer.cornerRadius = 6
    }
    required init?(coder: NSCoder) { fatalError() }
    func paint(_ p: NaqraPalette) {
        contentView.backgroundColor = .clear
        label.textColor = p.text
    }
}
