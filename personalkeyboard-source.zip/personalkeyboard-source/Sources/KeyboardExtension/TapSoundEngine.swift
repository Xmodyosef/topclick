import AVFoundation

class TapSoundEngine {
    static let shared = TapSoundEngine()
    private let engine = AVAudioEngine()
    private let playerNode = AVAudioPlayerNode()
    private var isSetup = false
    private var isEnabled = true
    private let format = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 1)!

    enum TapSound: Int {
        case rowHigh = 0
        case rowMid
        case rowLow
        case space
        case delete
        case enter
        case emoji
    }

    private let frequencies: [Double] = [
        523.25, 392.00, 261.63, 349.23, 329.63, 440.00, 587.33
    ]

    private init() { setupAudio() }

    private func setupAudio() {
        guard !isSetup else { return }
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.ambient, options: [.mixWithOthers])
        try? session.setActive(true, options: [])
        engine.attach(playerNode)
        engine.connect(playerNode, to: engine.mainMixerNode, format: format)
        try? engine.start()
        isSetup = true
    }

    func setEnabled(_ enabled: Bool) { isEnabled = enabled }

    func play(_ sound: TapSound) {
        guard isEnabled else { return }
        setupAudio()
        let sampleRate = format.sampleRate
        let duration: Double = 0.12
        let length = Int(sampleRate * duration)
        let frequency = frequencies[sound.rawValue]
        guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(length)) else { return }
        buffer.frameLength = AVAudioFrameCount(length)
        let channelData = buffer.floatChannelData![0]
        for i in 0..<length {
            let t = Double(i) / sampleRate
            let envelope = exp(-t * 25)
            let sample = sin(2.0 * .pi * frequency * t) * envelope * 0.15
            channelData[i] = Float(sample)
        }
        DispatchQueue.global(qos: .userInteractive).async {
            self.playerNode.scheduleBuffer(buffer, at: nil, options: [], completionHandler: nil)
            if !self.playerNode.isPlaying { self.playerNode.play() }
        }
    }
}
