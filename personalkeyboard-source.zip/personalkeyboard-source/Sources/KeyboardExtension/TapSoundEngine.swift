import AVFoundation

final class TapSoundEngine {
    static let shared = TapSoundEngine()
    private let engine = AVAudioEngine()
    private let playerNode = AVAudioPlayerNode()
    private var format: AVAudioFormat!
    private var isEnabled = true
    private var started = false

    enum Sound: Int {
        case rowHigh = 0
        case rowMid = 1
        case rowLow = 2
        case delete = 3
        case space = 4
        case emoji = 5
        case enter = 6
        case key = 1
    }

    private let frequencies: [Double] = [
        880,  // rowHigh
        740,  // rowMid / key
        620,  // rowLow
        220,  // delete
        520,  // space
        980,  // emoji
        660   // enter
    ]

    private init() {
        format = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 1)!
        engine.attach(playerNode)
        engine.connect(playerNode, to: engine.mainMixerNode, format: format)
    }

    func setEnabled(_ enabled: Bool) {
        isEnabled = enabled
    }

    private func setupAudio() {
        guard !started else { return }
        do {
            try engine.start()
            started = true
        } catch {}
    }

    func play(_ sound: Sound = .key) {
        guard isEnabled else { return }
        setupAudio()
        let sampleRate = format.sampleRate
        let duration: Double = sound == .delete ? 0.08 : 0.12
        let length = Int(sampleRate * duration)
        let frequency = frequencies[min(sound.rawValue, frequencies.count - 1)]
        guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(length)) else { return }
        buffer.frameLength = AVAudioFrameCount(length)
        let channelData = buffer.floatChannelData![0]
        for i in 0..<length {
            let t = Double(i) / sampleRate
            let envelope = exp(-t * 25)
            let sample = sin(2.0 * .pi * frequency * t) * envelope * 0.15
            channelData[i] = Float(sample)
        }
        DispatchQueue.global(qos: .userInteractive).async {
            self.playerNode.scheduleBuffer(buffer, at: nil, options: [], completionHandler: nil)
            if !self.playerNode.isPlaying { self.playerNode.play() }
        }
    }
}
