
# Timer Patterns Reference

Complete API reference for iOS timer mechanisms. For decision trees and crash prevention, see `skills/timer-patterns.md`.

---

## Part 1: Timer API

### Timer.scheduledTimer (Block-Based)

```swift
// Most common — block-based, auto-added to current RunLoop
let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
    self?.updateProgress()
}
```

**Key detail**: Added to `.default` RunLoop mode. Stops during scrolling. See Part 1 RunLoop modes table below.

### Timer.scheduledTimer (Selector-Based)

```swift
// Objective-C style — RETAINS TARGET (leak risk)
let timer = Timer.scheduledTimer(
    timeInterval: 1.0,
    target: self,       // Timer retains self!
    selector: #selector(update),
    userInfo: nil,
    repeats: true
)
```

**Danger**: This API retains `target`. If `self` also holds the timer, you have a retain cycle. The block-based API with `[weak self]` is always safer.

**Async contexts**: the `target:selector:` and `invocation:` variants are compile errors from any `async` context (`class method 'scheduledTimer' is unavailable from asynchronous contexts; Timers scheduled in an async context may never fire.`) — `NSTimer.h` annotates exactly those two with `NS_SWIFT_UNAVAILABLE_FROM_ASYNC`. The block-based variants carry no such annotation, but they share the runtime hazard the message names: a timer added to a run loop that never runs never fires.

### Timer.init (Manual RunLoop Addition)

```swift
// Create timer without adding to RunLoop
let timer = Timer(timeInterval: 1.0, repeats: true) { [weak self] _ in
    self?.updateProgress()
}

// Add to specific RunLoop mode
RunLoop.main.add(timer, forMode: .common)  // Survives scrolling
```

**`RunLoop.current` is unavailable from async contexts** (`currentRunLoop cannot be used from async contexts.`), so a recipe that has to work in both sync and `async` code uses `RunLoop.main` — which is also what a UI timer wants. A background thread's own run loop is reachable only as `RunLoop.current`, so that variant belongs in synchronous code only.

### timer.tolerance

```swift
timer.tolerance = 0.1  // Allow 100ms flexibility for system coalescing
```

System batches timers with similar fire dates when tolerance is set. Minimum recommended: 10% of interval. Reduces CPU wakes and energy consumption.

### RunLoop Modes

| Mode | Constant | When Active | Timer Fires? |
|------|----------|-------------|--------------|
| Default | `.default` / `RunLoop.Mode.default` | Normal user interaction | Yes |
| Tracking | `.tracking` / `RunLoop.Mode.tracking` | Scroll/drag gesture active | Only if added to `.common` |
| Common | `.common` / `RunLoop.Mode.common` | Pseudo-mode (default + tracking) | Yes (always) |

### timer.invalidate()

```swift
timer.invalidate()  // Stops timer, removes from RunLoop
// Timer is NOT reusable after invalidate — create a new one
timer = nil          // Release reference
```

**Key detail**: `invalidate()` must be called from the same thread that created the timer (usually main thread).

### timer.isValid

```swift
if timer.isValid {
    // Timer is still active
}
```

Returns `false` after `invalidate()` or after a non-repeating timer fires.

### Timer.publish (Combine)

```swift
Timer.publish(every: 1.0, tolerance: 0.1, on: .main, in: .common)
    .autoconnect()
    .sink { [weak self] _ in
        self?.updateProgress()
    }
    .store(in: &cancellables)
```

See Part 3 for full Combine timer details.

---

## Part 2: DispatchSourceTimer API

### Creation

```swift
// Create timer source on a specific queue
let queue = DispatchQueue(label: "com.app.timer")
let timer = DispatchSource.makeTimerSource(flags: [], queue: queue)
```

**flags**: Usually empty (`[]`). Use `.strict` for precise timing (disables system coalescing, higher energy cost).

### Schedule

```swift
// Relative deadline (monotonic clock)
timer.schedule(
    deadline: .now() + 1.0,     // First fire
    repeating: .seconds(1),     // Interval
    leeway: .milliseconds(100)  // Tolerance (like Timer.tolerance)
)

// Wall clock deadline (survives device sleep)
timer.schedule(
    wallDeadline: .now() + 1.0,
    repeating: .seconds(1),
    leeway: .milliseconds(100)
)
```

**deadline vs wallDeadline**: `deadline` uses monotonic clock (pauses when device sleeps). `wallDeadline` uses wall clock (continues across sleep). Use `deadline` for most cases.

### Event Handler

```swift
timer.setEventHandler { [weak self] in
    self?.performWork()
}
```

**Before cancel**: Set handler to nil to break retain cycles:

```swift
timer.setEventHandler(handler: nil)
timer.cancel()
```

### Lifecycle Methods

```swift
timer.activate()   // Start (idle → running); a no-op on an already-active source
timer.suspend()    // Pause (running → suspended)
timer.resume()     // Unpause — consumes one suspension (over-resuming traps)
timer.cancel()     // Stop permanently — legal even while suspended
```

### State Machine Lifecycle

```
                    activate()
        idle ──────────────► running
                               │  ▲
                    suspend()  │  │  resume()
                               ▼  │
                            suspended
                               │
                    cancel()
                               │
                               ▼
                           cancelled
```

**Critical rules**:
- `activate()` is the idle → running transition and is idempotent — calling it on an active source is a documented no-op, not an error
- `cancel()` is safe on a suspended source: the source is marked cancelled and its cancel handler runs once the source is resumed
- `cancel()` does not clear a suspension — the suspend count must be back at zero before the last reference is released (`Release of a suspended object`)
- `cancelled` is terminal for firing, but it does not make `resume()` safe: `resume()` only consumes a suspension, so resume exactly as many times as you suspended (`Over-resume of an object`)
- A source that was never activated must not be released either (`Release of an inactive object`) — activate it first

### Leeway (Tolerance)

```swift
// Leeway values
timer.schedule(deadline: .now(), repeating: 1.0, leeway: .milliseconds(100))
timer.schedule(deadline: .now(), repeating: 1.0, leeway: .seconds(1))
timer.schedule(deadline: .now(), repeating: 1.0, leeway: .never)  // Largest possible leeway
```

Leeway is the DispatchSourceTimer equivalent of `Timer.tolerance`. Allows system to coalesce timer firings for energy efficiency.

**The leeway is clamped for every fire after the first**: the system may delay the first fire by up to `leeway`, but each subsequent fire by no more than `min(leeway, repeating/2)`. With `repeating: 1.0`, `.seconds(1)` and `.never` both mean "up to 500 ms late" — `.never` is the loosest timing and the lowest energy cost, not a strict setting. Strictness comes from `flags: .strict` (see Creation above), and only together with a small leeway: `.strict` makes the system observe your leeway instead of its own lower limit, so a huge leeway stays loose even with it.

### End-to-End Example

Complete DispatchSourceTimer lifecycle in one block:

```swift
let queue = DispatchQueue(label: "com.app.polling")
let timer = DispatchSource.makeTimerSource(queue: queue)
timer.schedule(deadline: .now() + 1.0, repeating: .seconds(5), leeway: .milliseconds(500))
timer.setEventHandler { [weak self] in
    self?.fetchUpdates()
}
timer.activate()  // idle → running

// Later — pause:
timer.suspend()   // running → suspended

// Later — resume:
timer.resume()    // suspended → running

// Cleanup — the source must not be released while suspended:
timer.setEventHandler(handler: nil)  // Break retain cycles
timer.resume()    // Consume the suspension — this is what makes the release legal
timer.cancel()    // running → cancelled (terminal)
```

For a safe wrapper that prevents all crash patterns, see `skills/timer-patterns.md` Part 4: SafeDispatchTimer.

---

## Part 3: Combine Timer

### Timer.publish

```swift
import Combine

// Create publisher — RunLoop mode matters here too
let publisher = Timer.publish(
    every: 1.0,          // Interval
    tolerance: 0.1,      // Optional tolerance
    on: .main,           // RunLoop
    in: .common          // Mode — use .common to survive scrolling
)
```

### .autoconnect()

```swift
// Starts immediately when first subscriber attaches
Timer.publish(every: 1.0, on: .main, in: .common)
    .autoconnect()
    .sink { date in
        print("Fired at \(date)")
    }
    .store(in: &cancellables)
```

### .connect() (Manual Start)

```swift
// Manual control over when timer starts
let timerPublisher = Timer.publish(every: 1.0, on: .main, in: .common)
let cancellable = timerPublisher
    .sink { date in
        print("Fired at \(date)")
    }

// Start later
let connection = timerPublisher.connect()

// Stop
connection.cancel()
```

### Cancellation

```swift
// Via AnyCancellable storage — cancelled when Set is cleared or object deallocs
private var cancellables = Set<AnyCancellable>()

// Manual cancellation
cancellables.removeAll()  // Cancels all subscriptions
```

### SwiftUI Integration

```swift
class TimerViewModel: ObservableObject {
    @Published var elapsed: Int = 0
    private var cancellables = Set<AnyCancellable>()

    func start() {
        Timer.publish(every: 1.0, tolerance: 0.1, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in
                self?.elapsed += 1
            }
            .store(in: &cancellables)
    }

    func stop() {
        cancellables.removeAll()
    }
}
```

---

## Part 4: AsyncTimerSequence (Swift Concurrency)

`AsyncTimerSequence` is **not in the SDK or the standard library** — it ships in the [swift-async-algorithms](https://github.com/apple/swift-async-algorithms) package. Add that package and `import AsyncAlgorithms`; there is no `Clock.timer(interval:)` method on `ContinuousClock`/`SuspendingClock`. Requires iOS 16 / macOS 13 / watchOS 9 / tvOS 16. Pick the clock with the `clock:` argument.

### ContinuousClock

```swift
import AsyncAlgorithms

// Monotonic clock — does NOT pause when app suspends
for await _ in AsyncTimerSequence(interval: .seconds(1), clock: .continuous) {
    await updateData()
}
// Loop exits when task is cancelled
```

### SuspendingClock

```swift
import AsyncAlgorithms

// Suspending clock — pauses when app suspends.
// `.repeating(every:)` defaults to SuspendingClock.
for await _ in AsyncTimerSequence.repeating(every: .seconds(1)) {
    await processItem()
}
```

**ContinuousClock vs SuspendingClock**:
- `ContinuousClock`: Time keeps advancing during app suspension. Use for absolute timing.
- `SuspendingClock`: Time pauses when app suspends. Use for "user-perceived" timing.

### Task Cancellation

```swift
import AsyncAlgorithms

// Timer automatically stops when task is cancelled
let timerTask = Task {
    for await _ in AsyncTimerSequence(interval: .seconds(1), clock: .continuous) {
        await fetchLatestData()
    }
}

// Later: cancel the timer
timerTask.cancel()
```

### Background Polling with Structured Concurrency

```swift
import AsyncAlgorithms

func startPolling() async {
    do {
        for try await _ in AsyncTimerSequence(interval: .seconds(30), clock: .continuous) {
            try Task.checkCancellation()
            let data = try await api.fetchUpdates()
            await MainActor.run { updateUI(with: data) }
        }
    } catch is CancellationError {
        // Clean exit
    } catch {
        // Handle fetch error
    }
}
```

---

## Part 5: Task.sleep Alternatives

### One-Shot Delay

```swift
// Simple delay — NOT a timer
try await Task.sleep(for: .seconds(1))

// Deadline-based
try await Task.sleep(until: .now + .seconds(1), clock: .continuous)
```

### When to Use Sleep vs Timer

| Need | Use |
|------|-----|
| One-shot delay before action | `Task.sleep(for:)` |
| Repeating action | `AsyncTimerSequence(interval:clock:)` (swift-async-algorithms) |
| Delay with cancellation | `Task.sleep(for:)` in a Task |
| Retry with backoff | `Task.sleep(for:)` in a loop |

### Retry with Exponential Backoff

```swift
func fetchWithRetry(maxAttempts: Int = 3) async throws -> Data {
    var delay: Duration = .seconds(1)
    for attempt in 1...maxAttempts {
        do {
            return try await api.fetch()
        } catch where attempt < maxAttempts {
            try await Task.sleep(for: delay)
            delay *= 2  // Exponential backoff
        }
    }
    throw FetchError.maxRetriesExceeded
}
```

---

## Part 6: LLDB Timer Inspection

### Timer (NSTimer) Commands

```lldb
# Check if timer is still valid
po timer.isValid

# See next fire date
po timer.fireDate

# See timer interval
po timer.timeInterval

# Run one bounded RunLoop iteration in .default mode (may fire a due timer)
# — `[[NSRunLoop mainRunLoop] run]` never returns; don't use it in a debug session
expression -l objc -- (BOOL)[[NSRunLoop mainRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate dateWithTimeIntervalSinceNow:0.1]]
```

### DispatchSourceTimer Commands

```lldb
# Inspect dispatch source
po timer

# Break on dispatch source cancel (all sources)
breakpoint set -n dispatch_source_cancel

# A state-machine trap is not an exception you can catch by name. On arm64 the
# report is EXC_BREAKPOINT (SIGTRAP) with a "BUG IN CLIENT OF LIBDISPATCH: …"
# message (Intel showed EXC_BAD_INSTRUCTION); the message names the broken rule.
# Read it, then break on the code that reaches the bad transition.

# Check if a DispatchSource is cancelled
expression -l objc -- (long)dispatch_source_testcancel((void*)timer)
```

### General Timer Debugging

```lldb
# When does the next main-RunLoop timer fire? (CFRunLoopGetMain() on its own
# only returns the run loop — there is no public API that lists run-loop timers)
expression -l objc -- (double)CFRunLoopGetNextTimerFireDate(CFRunLoopGetMain(), kCFRunLoopDefaultMode)

# Break when any Timer fires
breakpoint set -S "scheduledTimerWithTimeInterval:target:selector:userInfo:repeats:"
```

---

## Part 7: Platform Availability Matrix

| API | iOS | macOS | watchOS | tvOS |
|---|---|---|---|---|
| Timer | 2.0+ | 10.0+ | 2.0+ | 9.0+ |
| DispatchSourceTimer | 8.0+ (GCD) | 10.10+ | 2.0+ | 9.0+ |
| Timer.publish (Combine) | 13.0+ | 10.15+ | 6.0+ | 13.0+ |
| AsyncTimerSequence | 16.0+ | 13.0+ | 9.0+ | 16.0+ |
| Task.sleep(nanoseconds:) | 13.0+ | 10.15+ | 6.0+ | 13.0+ |
| Task.sleep(for:) / Task.sleep(until:) (Duration, Clock) | 16.0+ | 13.0+ | 9.0+ | 16.0+ |

---

## Related Skills

- `skills/timer-patterns.md` — Decision trees, crash patterns, SafeDispatchTimer wrapper
- `axiom-performance (skills/energy.md)` — Timer tolerance as energy optimization (Pattern 1)
- `axiom-performance (skills/energy-ref.md)` — Timer efficiency APIs with WWDC code examples
- `axiom-performance (skills/memory-debugging.md)` — Timer as Pattern 1 memory leak

## Resources

**Skills**: skills/timer-patterns.md, axiom-performance (skills/energy-ref.md), axiom-performance (skills/memory-debugging.md)
