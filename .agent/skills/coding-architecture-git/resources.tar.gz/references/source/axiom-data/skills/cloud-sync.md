
# Cloud Sync

## Overview

**Core principle**: Choose the right sync technology for the data shape, then implement offline-first patterns that handle network failures gracefully.

Two fundamentally different sync approaches:
- **CloudKit** — Structured data (records with fields and relationships)
- **iCloud Drive** — File-based data (documents, images, any file format)

## Quick Decision Tree

```
What needs syncing?

├─ Structured data (records, relationships)?
│  ├─ Using SwiftData? → SwiftData + CloudKit (easiest, iOS 17+)
│  ├─ Need shared/public database? → CKSyncEngine or raw CloudKit
│  └─ Custom persistence (GRDB, SQLite)? → CKSyncEngine (iOS 17+)
│
├─ Documents/files users expect in Files app?
│  └─ iCloud Drive (UIDocument or FileManager)
│
├─ Large binary blobs (images, videos)?
│  ├─ Associated with structured data? → CKAsset in CloudKit
│  └─ Standalone files? → iCloud Drive
│
└─ App settings/preferences?
   └─ NSUbiquitousKeyValueStore (simple key-value, 1MB limit)
```

## CloudKit vs iCloud Drive

| Aspect | CloudKit | iCloud Drive |
|--------|----------|--------------|
| **Data shape** | Structured records | Files/documents |
| **Query support** | Full query language | Filename only |
| **Relationships** | Native support | None (manual) |
| **Conflict resolution** | Record-level | File-level |
| **User visibility** | Hidden from user | Visible in Files app |
| **Sharing** | Record/database sharing | File sharing |
| **Offline** | Local cache required | Automatic download |

## Red Flags

If ANY of these appear, STOP and reconsider:

- ❌ "Store JSON files in CloudKit" — Wrong tool. Use iCloud Drive for files
- ❌ "Build relationships manually in iCloud Drive" — Wrong tool. Use CloudKit
- ❌ "Assume sync is instant" — Network fails. Design offline-first
- ❌ "Skip conflict handling" — Conflicts WILL happen on multiple devices
- ❌ "Use CloudKit for user documents" — Users can't see them. Use iCloud Drive
- ❌ "Sync on app launch only" — Users expect continuous sync

## Offline-First Pattern

**MANDATORY**: All sync code must work offline first.

```swift
// ✅ CORRECT: Offline-first architecture
class OfflineFirstSync {
    private let localStore: LocalDatabase  // GRDB, SwiftData, Core Data
    private let syncEngine: CKSyncEngine

    // Write to LOCAL first, sync to cloud in background
    func save(_ item: Item) async throws {
        // 1. Save locally (instant)
        try await localStore.save(item)

        // 2. Queue for sync (non-blocking)
        syncEngine.state.add(pendingRecordZoneChanges: [
            .saveRecord(item.recordID)
        ])
    }

    // Read from LOCAL (instant)
    func fetch() async throws -> [Item] {
        return try await localStore.fetchAll()
    }
}

// ❌ WRONG: Cloud-first (blocks on network)
func save(_ item: Item) async throws {
    // Fails when offline, slow on bad network
    try await cloudKit.save(item)
    try await localStore.save(item)
}
```

## Conflict Resolution Strategies

Conflicts occur when two devices edit the same data before syncing.

### Strategy 1: Last-Writer-Wins (Simplest)

```swift
// Server always has latest, client accepts it
func resolveConflict(local: CKRecord, server: CKRecord) -> CKRecord {
    return server  // Accept server version
}
```

**Use when**: Data is non-critical, user won't notice overwrites

### Strategy 2: Merge (Most Common)

```swift
// Combine changes from both versions
func resolveConflict(local: CKRecord, server: CKRecord) -> CKRecord {
    let merged = server.copy() as! CKRecord

    // For each field, apply custom merge logic
    merged["notes"] = mergeText(
        local["notes"] as? String,
        server["notes"] as? String
    )
    merged["tags"] = mergeSets(
        local["tags"] as? [String] ?? [],
        server["tags"] as? [String] ?? []
    )

    return merged
}
```

**Use when**: Both versions contain valuable changes

### Strategy 3: User Choice

```swift
// Present conflict to user
func resolveConflict(local: CKRecord, server: CKRecord) async -> CKRecord {
    let choice = await presentConflictUI(local: local, server: server)
    return choice == .keepLocal ? local : server
}
```

**Use when**: Data is critical, user must decide

## Common Patterns

### Pattern 1: SwiftData + CloudKit (Recommended for New Apps)

```swift
import SwiftData

// Automatic CloudKit sync with zero configuration
@Model
class Note {
    var title: String
    var content: String
    var createdAt: Date

    init(title: String, content: String) {
        self.title = title
        self.content = content
        self.createdAt = Date()
    }
}

// Container automatically syncs if CloudKit entitlement present
let container = try ModelContainer(for: Note.self)
```

**Limitations**:
- Private database only (no public/shared)
- Automatic sync (less control over timing)
- No custom conflict resolution
- `@Attribute(.unique)` not supported with CloudKit sync — remove if using CloudKit

### Pattern 2: CKSyncEngine (Custom Persistence)

```swift
// For GRDB, SQLite, or custom databases
final class MySyncManager: CKSyncEngineDelegate {
    private let database: GRDBDatabase

    init(database: GRDBDatabase) {
        self.database = database
    }

    func handleEvent(_ event: CKSyncEngine.Event, syncEngine: CKSyncEngine) async {
        switch event {
        case .stateUpdate(let update):
            // Persist sync state
            await saveSyncState(update.stateSerialization)

        case .fetchedDatabaseChanges(let changes):
            // Apply changes to local DB
            for modification in changes.modifications {
                await handleZoneChanges(modification.zoneID)
            }

        case .sentRecordZoneChanges(let sent):
            // Mark records as synced
            for saved in sent.savedRecords {
                await markSynced(saved.recordID)
            }

        case .accountChange, .fetchedRecordZoneChanges, .sentDatabaseChanges,
             .willFetchChanges, .willFetchRecordZoneChanges, .didFetchRecordZoneChanges,
             .didFetchChanges, .willSendChanges, .didSendChanges:
            break

        @unknown default:
            break
        }
    }

    func nextRecordZoneChangeBatch(
        _ context: CKSyncEngine.SendChangesContext,
        syncEngine: CKSyncEngine
    ) async -> CKSyncEngine.RecordZoneChangeBatch? {
        let changes = syncEngine.state.pendingRecordZoneChanges
            .filter { context.options.scope.contains($0) }
        return await CKSyncEngine.RecordZoneChangeBatch(pendingChanges: changes) { recordID in
            await self.record(for: recordID)   // CKRecord to save, or nil to skip
        }
    }
}
```

See `skills/cloudkit-ref.md` for complete CKSyncEngine setup.

### Pattern 3: iCloud Drive Documents

```swift
import UIKit

class MyDocument: UIDocument {
    var content: Data?

    override func contents(forType typeName: String) throws -> Any {
        return content ?? Data()
    }

    override func load(fromContents contents: Any, ofType typeName: String?) throws {
        content = contents as? Data
    }
}

// Save to iCloud Drive (visible in Files app)
let url = FileManager.default.url(forUbiquityContainerIdentifier: nil)?
    .appendingPathComponent("Documents")
    .appendingPathComponent("MyFile.txt")

let doc = MyDocument(fileURL: url!)
doc.content = "Hello".data(using: .utf8)
doc.save(to: url!, for: .forCreating)
```

See `skills/icloud-drive-ref.md` for NSFileCoordinator and conflict handling.

## Anti-Patterns

### 1. Ignoring Sync State

```swift
// ❌ WRONG: No awareness of pending changes
var items: [Item] = []  // Are these synced? Pending? Conflicted?

// ✅ CORRECT: Track sync state
struct SyncableItem {
    let item: Item
    let syncState: SyncState  // .synced, .pending, .conflict
}
```

### 2. Blocking UI on Sync

```swift
// ❌ WRONG: UI blocks until sync completes
func viewDidLoad() async {
    items = try await cloudKit.fetchAll()  // Spinner forever on airplane
    tableView.reloadData()
}

// ✅ CORRECT: Show local data immediately
func viewDidLoad() {
    items = localStore.fetchAll()  // Instant
    tableView.reloadData()

    Task {
        try? await syncEngine.fetchChanges()  // Background update
    }
}
```

### 3. CloudKit Schema Not Deployed to Production

CloudKit has **separate schemas for Development and Production**, and the production schema is never created for you. Your app in the App Store can only access the Production environment, so anything you added in Development but never deployed fails there:

- An undeployed **record type** → `CKError.unknownItem`
- An undeployed or non-queryable **field** → `CKError.invalidArguments` ("Field X is not marked queryable")
- A **subscription** created directly in Production → error at creation

The SDK documents the rejection but not the code that carries it, so treat these as the codes seen in practice rather than a guarantee.

```
❌ Works in Xcode/TestFlight (Development) → hard errors in App Store (Production)
   Queries and saves fail against a schema the server does not have.

✅ Before every App Store submission:
   1. CloudKit Console → Select container
   2. "Deploy Schema Changes" → Review changes → Deploy
   3. Test with Production environment in Xcode scheme settings
```

**Time cost of skipping**: 3-7 days (rejection cycle + debugging "why does it work in TestFlight but not production?"). This is the #1 CloudKit gotcha for first-time submitters.

### 4. No Retry Logic

```swift
// ❌ WRONG: Single attempt
try await cloudKit.save(record)

// ✅ CORRECT: Exponential backoff
func saveWithRetry(_ record: CKRecord, attempts: Int = 3) async throws {
    // Only these are worth retrying — a conflict or a schema error never is
    let retryable: Set<CKError.Code> = [
        .networkUnavailable, .networkFailure, .serviceUnavailable,
        .requestRateLimited, .zoneBusy, .accountTemporarilyUnavailable
    ]

    for attempt in 0..<attempts {
        do {
            try await cloudKit.save(record)
            return
        } catch let error as CKError where retryable.contains(error.code) {
            // Server-supplied wait when it sent one, exponential backoff otherwise
            let delay = error.retryAfterSeconds ?? pow(2.0, Double(attempt))
            try await Task.sleep(for: .seconds(delay))
        }
    }
    throw SyncError.maxRetriesExceeded
}
```

## Sync State Indicators

Always show users the sync state:

```swift
enum SyncState {
    case synced       // ✓ (checkmark)
    case pending      // ↻ (arrows)
    case conflict     // ⚠ (warning)
    case offline      // ☁ with X
}

// In SwiftUI
HStack {
    Text(item.title)
    Spacer()
    SyncIndicator(state: item.syncState)
}
```

## Entitlement Checklist

Before sync will work:

1. **Xcode → Signing & Capabilities**
   - ✓ iCloud capability added
   - ✓ CloudKit checked (for CloudKit)
   - ✓ iCloud Documents checked (for iCloud Drive)
   - ✓ Container selected/created

2. **Apple Developer Portal**
   - ✓ App ID has iCloud capability
   - ✓ CloudKit container exists (for CloudKit)

3. **CloudKit Console (before App Store submission)**
   - ✓ Schema deployed to Production (record types, fields, indexes)
   - ✓ Test with Production environment in Xcode scheme to verify queries work

4. **Device**
   - ✓ Signed into iCloud
   - ✓ iCloud Drive enabled (Settings → [Name] → iCloud)

## Large Dataset Sync

When syncing 10,000+ records, naive approaches cause timeouts and launch slowdowns.

### Initial Sync Strategy

```swift
// ❌ WRONG: Fetch everything at once
let allRecords = try await database.fetchAll()
syncEngine.state.add(pendingRecordZoneChanges: allRecords.map { .saveRecord($0.recordID) })

// ✅ CORRECT: Batch initial sync
func performInitialSync(batchSize: Int = 200) async throws {
    var page = try await database.records(
        matching: query, desiredKeys: nil, resultsLimit: batchSize
    )

    while true {
        // Process batch
        try await localStore.saveBatch(page.matchResults.compactMap { try? $0.1.get() })

        // records(continuingMatchFrom:) is the cursor form — there is no continuationCursor: label
        guard let cursor = page.queryCursor else { break }
        page = try await database.records(
            continuingMatchFrom: cursor, desiredKeys: nil, resultsLimit: batchSize
        )
    }
}
```

### Incremental Sync (After Initial)

CKSyncEngine handles incremental sync automatically — it fetches only changes since the last sync token. Ensure you persist `stateSerialization` so the engine doesn't re-fetch everything on next launch.

### CKSyncEngine change-batch cap (250 records)

Each request the engine sends is bounded by a **server limit of 250 records — saves plus deletes combined**. A hand-assembled batch that exceeds it fails the whole request with `CKError.limitExceeded`. In `nextRecordZoneChangeBatch(_:syncEngine:)`, build the batch with the failable initializer that stops at the limit instead of assembling one yourself — the remainder stays in `pendingRecordZoneChanges` and the engine requests it in the next batch.

```swift
func nextRecordZoneChangeBatch(
    _ context: CKSyncEngine.SendChangesContext,
    syncEngine: CKSyncEngine
) async -> CKSyncEngine.RecordZoneChangeBatch? {
    let changes = syncEngine.state.pendingRecordZoneChanges
        .filter { context.options.scope.contains($0) }
    // Failable async init — stops when the 250-record cap is reached.
    return await CKSyncEngine.RecordZoneChangeBatch(pendingChanges: changes) { recordID in
        self.record(for: recordID)   // CKRecord to save, or nil to skip
    }
}
```

This cap is a server-side limit (applies on every CKSyncEngine OS version, iOS 17+), not new-in-27 API — it was merely undocumented before. The 200-record `resultsLimit` in the initial-sync **query** above is a fetch limit on a different axis; it sits under 250 by coincidence, not because one bound implies the other.

### Performance Guidelines

| Dataset Size | Strategy | Notes |
|-------------|----------|-------|
| < 1,000 records | Default CKSyncEngine | Works out of the box |
| 1,000–10,000 | Batch initial sync | 200-record batches, show progress UI |
| 10,000+ | Pagination + background | Use BGProcessingTask for initial sync |
| 100,000+ | Server-side filtering | Only sync what user needs, lazy-load rest |

**Key insight**: Initial sync is the bottleneck. After initial sync, CKSyncEngine's incremental approach handles large datasets efficiently because it only fetches deltas.

## Pressure Scenarios

### Scenario 1: "Just skip conflict handling for v1"

**Situation**: Deadline pressure to ship without conflict resolution.

**Risk**: Users WILL edit on multiple devices. Data WILL be lost silently.

**Response**: "Minimum viable conflict handling takes 2 hours. Silent data loss costs users and generates 1-star reviews."

### Scenario 2: "Sync on app launch is enough"

**Situation**: Avoiding continuous sync complexity.

**Risk**: Users expect changes to appear within seconds, not on next launch.

**Response**: Use CKSyncEngine or SwiftData which handle continuous sync automatically.

## Related Skills

- `skills/cloudkit-ref.md` — Complete CloudKit API reference
- `skills/icloud-drive-ref.md` — File-based sync with NSFileCoordinator
- `skills/cloud-sync-diag.md` — Debugging sync failures
- `skills/storage.md` — Choosing where to store data locally
