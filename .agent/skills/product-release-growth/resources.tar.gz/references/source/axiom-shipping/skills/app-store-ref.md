
# App Store Submission Reference

## Overview

Complete reference for every App Store submission requirement:

- **Part 1** — Required metadata fields (descriptions, screenshots, keywords, App Review info)
- **Part 2** — Privacy requirements (manifest schema, nutrition labels, ATT, Required Reason APIs)
- **Part 3** — App Review Guidelines quick reference (all sections 1-5)
- **Part 4** — Age rating system (5-tier, capabilities, regional variations)
- **Part 5** — Export compliance (encryption decision tree)
- **Part 6** — Account and authentication requirements (deletion, SIWA)
- **Part 7** — Monetization and IAP submission pipeline
- **Part 8** — EU-specific compliance (DSA trader status)
- **Part 9** — Build upload and processing
- **Part 10** — WWDC25 changes (draft submissions, accessibility labels, tags)
- **Part 11** — WWDC26 changes (Product Page Header + Asset Library, Retention Messaging, group/volume subscriptions, enhanced IAP submissions)

## When to Use This Skill

#### Use when
- Looking up specific metadata field requirements or character limits
- Checking App Review guideline numbers for a specific topic
- Verifying privacy manifest schema fields or Required Reason API categories
- Understanding age rating tiers and new capability declarations
- Checking EU compliance requirements for DSA trader status
- Understanding IAP submission pipeline and review flow
- Preparing builds for upload (SDK requirements, encryption, signing)

#### Do NOT use when
- Deciding if your app is ready to submit (use **app-store-submission**)
- Troubleshooting a rejection (use **app-store-diag**)
- Implementing in-app purchases (use **storekit-ref**)
- Writing privacy manifest code (use **privacy-ux**)
- Auditing accessibility compliance (use **accessibility-diag**)

## Related Skills

- **app-store-submission** — Discipline skill with pre-flight checklist and workflow
- **app-store-diag** — Rejection troubleshooting and appeal guidance
- **privacy-ux** — Privacy manifest implementation, ATT UX, permission requests
- **storekit-ref** — StoreKit 2 API reference for IAP implementation
- **accessibility-diag** — Accessibility compliance scanning and VoiceOver testing

## Key Terminology

| Term | Definition |
|------|-----------|
| **App Store Connect** | Web portal and API for managing app metadata, builds, pricing, TestFlight, and analytics |
| **App Review** | Apple's human review process that evaluates every app update against the App Review Guidelines |
| **Privacy Manifest** | `PrivacyInfo.xcprivacy` file declaring data collection, tracking domains, and Required Reason API usage |
| **Required Reason API** | System APIs (file timestamps, disk space, user defaults, etc.) that require declared usage reasons |
| **Privacy Nutrition Label** | App Store privacy cards showing what data your app collects and how it uses it |
| **DSA Trader Status** | EU Digital Services Act classification determining if you are a "trader" selling to EU consumers |
| **Build String** | Unique identifier for each uploaded build (e.g., "1.2.3.4"), separate from version number |
| **Bundle ID** | Reverse-domain identifier (e.g., "com.company.app") uniquely identifying your app across Apple's ecosystem |

---

## Part 1: Required Metadata Fields

### Immutable Fields (Cannot Change After Creation)

These fields are locked once set. Choose carefully:
- **Bundle ID** — must match Xcode project exactly
- **SKU** — internal identifier, never shown to users
- **IAP Product ID** — cannot be changed or reused after creation
- **Subscription Duration** — locked after subscription is created

### App Information

| Field | Required | Localizable | Max Length | Notes |
|-------|----------|-------------|------------|-------|
| App Name | Yes | Yes | 30 chars | Must be unique on the App Store |
| Subtitle | No | Yes | 30 chars | Appears below app name in search results |
| Description | Yes | Yes | 4000 chars | Plain text, no HTML or rich formatting |
| Promotional Text | No | Yes | 170 chars | Editable without new submission |
| Keywords | Yes | Yes | 100 bytes | Comma-separated, each keyword >2 chars |
| What's New | Yes* | Yes | 4000 chars | *Required for all versions except first |
| Copyright | Yes | No | — | Format: "YYYY Company Name" |
| Support URL | Yes | Yes | — | Must link to actual contact information |
| Marketing URL | No | Yes | — | Optional promotional page |
| Privacy Policy URL | Yes | Yes | — | HTTPS, publicly accessible |

### Visual Assets

| Asset | Required | Localizable | Specification |
|-------|----------|-------------|---------------|
| App Icon | Yes | No | 1024x1024 PNG, no alpha, no rounded corners |
| Screenshots | Yes | Yes | Per device size, 1–10 per locale per device |
| App Preview | No | Yes | Up to 3 videos per device size per locale |

#### Screenshot Requirements

Format: `.jpeg`, `.jpg`, `.png`. Min 1, max 10 per device size per locale.

**Fallback**: Provide highest resolution only — App Store auto-scales to smaller sizes.

**Required — Apple's page contradicts itself**: "Required device sizes" = ≥1 iPhone Dynamic Island medium (6.3") + iPad 13" for iPad apps; per-row notes still call 6.9" (or 6.5") the required iPhone set → confirm in App Store Connect's media manager. iPhone Duo: required from April 2027 for apps using the iOS 27.1 SDK or later.

| Device | Portrait | Landscape |
|--------|----------|-----------|
| iPhone 6.9" (Air, 17 Pro Max, 16 Pro Max, 15 Pro Max) | 1260x2736, 1290x2796, or 1320x2868 | 2736x1260, 2796x1290, or 2868x1320 |
| iPhone 6.5" (14 Plus, 13 Pro Max, XS Max) | 1284x2778 or 1242x2688 | 2778x1284 or 2688x1242 |
| iPhone 6.3" (17 Pro, 16 Pro, 16, 15 Pro) | 1179x2556 or 1206x2622 | 2556x1179 or 2622x1206 |
| iPhone 6.1" (17e, 16e, 14, 13, 12) | 1170x2532, 1125x2436, or 1080x2340 | 2532x1170, 2436x1125, or 2340x1080 |
| iPhone 5.5" (8 Plus, 7 Plus) | 1242x2208 | 2208x1242 |
| iPhone Duo inner display | 2007x2853 | 2853x2007 |
| iPhone Duo outer display | 1398x2034 | 2034x1398 |
| iPad 13" (Pro M5/M4, Air M4/M3) | 2064x2752 or 2048x2732 | 2752x2064 or 2732x2048 |
| iPad 11" (Pro, Air, mini, 10th gen) | 1488x2266, 1668x2420, 1668x2388, or 1640x2360 | 2266x1488, 2420x1668, 2388x1668, or 2360x1640 |
| Mac | 1280x800, 1440x900, 2560x1600, or 2880x1800 | — |
| Apple TV | 1920x1080 or 3840x2160 | — |
| Apple Vision Pro | 3840x2160 | — |

Screenshots must show the app in actual use. Not permitted: title art alone, login screens, splash screens, or screens from other platforms. Cannot update screenshots on an approved version — must create a new version.

#### App Preview Video Specifications

| Spec | Value |
|------|-------|
| Duration | 15-30 seconds |
| Max file size | 500 MB |
| Max frame rate | 30 fps |
| Max per device/locale | 3 |
| H.264 | 10-12 Mbps, `.mov`/`.m4v`/`.mp4`, 256 kbps AAC stereo |
| ProRes 422 HQ | ~220 Mbps VBR, `.mov` only, PCM or 256 kbps AAC stereo |
| Audio sample rate | 44.1 or 48 kHz |
| Orientation | Portrait or landscape (Mac/tvOS/visionOS: landscape only) |

**Gotchas**: Processing can take up to 24 hours — do not submit for review immediately after uploading previews. All audio tracks must be enabled (disabled tracks cause rejection). Previews always appear before screenshots on the product page.

#### App Icon Requirements

| Specification | Requirement |
|---------------|-------------|
| Size | 1024 x 1024 pixels |
| Format | PNG |
| Color space | sRGB or P3 |
| Alpha channel | Not allowed |
| Rounded corners | Not allowed (system applies automatically) |
| Layers/transparency | Not allowed |
| Content | Must be appropriate for 4+ rating regardless of app's actual rating |

### App Review Information

| Field | Required | Notes |
|-------|----------|-------|
| Contact First Name | Yes | Reviewer contact |
| Contact Last Name | Yes | Reviewer contact |
| Contact Email | Yes | Must be monitored |
| Contact Phone | Yes | Include country code |
| Notes for Review | No | Up to 4000 bytes; explain non-obvious features |
| Sign-in Username | If login required | Must not expire during review |
| Sign-in Password | If login required | Must not expire during review |
| Attachment | No | Up to 10 files, max 512 MB total |

### Metadata Rules (Guideline 2.3)

- App names must be unique, max 30 characters
- Keywords must not include trademarked terms, popular app names, or pricing terms ("free", "sale")
- Screenshots must show the app in use, not just marketing art
- Icons, screenshots, and previews must be appropriate for a 4+ rating even if the app is rated higher
- "For Kids" and "For Children" are reserved for the Kids category
- No other mobile platform names or imagery in screenshots (no Android phones, Windows logos)
- Metadata must accurately reflect app functionality; misleading metadata is grounds for rejection

### Localization Requirements

| Aspect | Details |
|--------|---------|
| Minimum | Primary language required; all other localizations optional |
| Per-locale metadata | App name, subtitle, description, keywords, What's New, screenshots |
| Promotional Text | Localizable and editable without new submission |
| Screenshots | Can differ per locale (show localized UI) |
| App Previews | Can differ per locale (show localized audio/UI) |
| URL fields | Support URL and Marketing URL can differ per locale |

When localizing, provide screenshots that match the localized UI. Reviewers check that screenshots accurately represent the app in each locale.

### Category Selection

| Primary Category | Secondary Category | Rules |
|-----------------|-------------------|-------|
| Required | Optional | Choose the category that best describes your app |
| Must be accurate | Can complement primary | If the category is way off, Apple may change it for you (2.3.5) |
| Games have subcategories | — | Games must also select up to 2 game subcategories |

Available categories: Books, Business, Developer Tools, Education, Entertainment, Finance, Food & Drink, Games, Graphics & Design, Health & Fitness, Lifestyle, Magazines & Newspapers, Medical, Music, Navigation, News, Photo & Video, Productivity, Reference, Shopping, Social Networking, Sports, Travel, Utilities, Weather.

---

## Part 2: Privacy Requirements

### Privacy Policy (Guideline 5.1.1(i))

Required in BOTH locations:
1. **App Store Connect** metadata (Privacy Policy URL field)
2. **Within the app** itself (accessible from settings or equivalent)

The privacy policy must identify:
- What data is collected and by what means
- All uses of collected data
- Third-party sharing practices
- Data retention and deletion policies
- How users can revoke consent

### Privacy Manifest Schema (PrivacyInfo.xcprivacy)

```xml
<!-- Top-level keys -->
NSPrivacyTracking              <!-- Boolean: Does app track users? -->
NSPrivacyTrackingDomains       <!-- Array<String>: Domains used for tracking -->
NSPrivacyCollectedDataTypes    <!-- Array<Dictionary>: Data collected -->
NSPrivacyAccessedAPITypes      <!-- Array<Dictionary>: Required Reason APIs -->
```

#### NSPrivacyCollectedDataTypes Entry

Each dictionary in the array contains:

| Key | Type | Description |
|-----|------|-------------|
| `NSPrivacyCollectedDataType` | String | Category key (e.g., "NSPrivacyCollectedDataTypeName") |
| `NSPrivacyCollectedDataTypePurposes` | Array&lt;String&gt; | Purpose keys for this data type |
| `NSPrivacyCollectedDataTypeLinked` | Boolean | Is this data linked to user identity? |
| `NSPrivacyCollectedDataTypeTracking` | Boolean | Is this data used for tracking? |

#### NSPrivacyAccessedAPITypes Entry

Each dictionary in the array contains:

| Key | Type | Description |
|-----|------|-------------|
| `NSPrivacyAccessedAPIType` | String | API category identifier |
| `NSPrivacyAccessedAPITypeReasons` | Array&lt;String&gt; | Approved reason codes for usage |

#### Complete PrivacyInfo.xcprivacy Example

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>NSPrivacyTracking</key>
    <false/>
    <key>NSPrivacyTrackingDomains</key>
    <array/>
    <key>NSPrivacyCollectedDataTypes</key>
    <array>
        <dict>
            <key>NSPrivacyCollectedDataType</key>
            <string>NSPrivacyCollectedDataTypeEmailAddress</string>
            <key>NSPrivacyCollectedDataTypeLinked</key>
            <true/>
            <key>NSPrivacyCollectedDataTypeTracking</key>
            <false/>
            <key>NSPrivacyCollectedDataTypePurposes</key>
            <array>
                <string>NSPrivacyCollectedDataTypePurposeAppFunctionality</string>
            </array>
        </dict>
    </array>
    <key>NSPrivacyAccessedAPITypes</key>
    <array>
        <dict>
            <key>NSPrivacyAccessedAPIType</key>
            <string>NSPrivacyAccessedAPICategoryUserDefaults</string>
            <key>NSPrivacyAccessedAPITypeReasons</key>
            <array>
                <string>CA92.1</string>
            </array>
        </dict>
    </array>
</dict>
</plist>
```

#### API Category Identifiers

| Category | Identifier String |
|----------|------------------|
| File timestamp | `NSPrivacyAccessedAPICategoryFileTimestamp` |
| System boot time | `NSPrivacyAccessedAPICategorySystemBootTime` |
| Disk space | `NSPrivacyAccessedAPICategoryDiskSpace` |
| Active keyboard | `NSPrivacyAccessedAPICategoryActiveKeyboards` |
| User defaults | `NSPrivacyAccessedAPICategoryUserDefaults` |

#### Generating Aggregate Privacy Report

```
Xcode > Product > Archive > Generate Privacy Report
```

This produces a PDF summarizing privacy manifests from your app and all embedded frameworks.

**Privacy manifest gotchas**:
- Custom string values for `NSPrivacyCollectedDataType` or `NSPrivacyCollectedDataTypePurposes` are silently rejected by Xcode — must use Apple's predefined constants
- iOS 17 automatically blocks connections to declared tracking domains when user denies tracking
- IP address collection must be declared (as location, device ID, or diagnostics)
- Web view data collection must be declared
- You are responsible for ALL data collected by third-party SDKs in your app
- Some SDKs default to tracking unless explicitly disabled — creates unintentional tracking
- Fingerprinting is NEVER allowed, regardless of ATT permission
- Since May 1, 2024: missing required-reason API declarations cause automatic rejection (no human review)

### Required Reason API Categories

| Category | APIs Covered | Approved Reason Codes |
|----------|-------------|----------------------|
| File timestamp | `NSFileCreationDate`, `NSFileModificationDate`, `NSURLContentModificationDateKey` | DDA9.1 (display to user), C617.1 (inside app or group container), 3B52.1 (files provided to the app by the user), 0A2A.1 (third-party SDK wrapper) |
| System boot time | `systemUptime`, `mach_absolute_time` | 35F9.1 (measure elapsed time), 8FFB.1 (calculate a timestamp for an in-app event), 3D61.1 (user-initiated bug report) |
| Disk space | `NSFileSystemFreeSize`, `NSFileSystemSize`, `volumeAvailableCapacityKey` | E174.1 (write or delete a file), 85F4.1 (display to user), 7D9E.1 (user-initiated bug report), B728.1 (health research app) |
| Active keyboard | `activeInputModes` | 54BD.1 (customize UI for keyboard), 3EC4.1 (custom keyboard app) |
| User defaults | `UserDefaults` (all access requires declaration) | CA92.1 (access info from same app), 1C8F.1 (same App Group), C56D.1 (third-party SDK wrapper), AC6B.1 (managed app configuration) |

That is the complete set in Xcode 27.2's `.xcprivacy` schema — five categories, 17 codes. Declare the code that matches the actual use, not the most familiar one.

### App Privacy Details (Nutrition Labels)

#### Data Type Categories

| Category | Examples |
|----------|---------|
| Contact Info | Name, email address, phone number, physical address |
| Health & Fitness | Health data, fitness data |
| Financial Info | Payment info, credit info |
| Location | Precise location, coarse location |
| Sensitive Info | Racial or ethnic data, sexual orientation, religion, biometrics |
| Contacts | Address book contacts |
| User Content | Photos, videos, audio, gameplay content, customer support messages |
| Browsing History | Web browsing history |
| Search History | In-app search history |
| Identifiers | User ID, device ID |
| Purchases | Purchase history |
| Usage Data | Product interaction, advertising data, app launches, taps, scrolls |
| Diagnostics | Crash data, performance data |
| Surroundings | Environment scanning (e.g., AR data) |
| Body | Hands, head (e.g., hand tracking in visionOS) |

#### Purpose Categories

| Purpose | Description |
|---------|-------------|
| Third-Party Advertising | Displaying third-party ads or sharing with ad networks |
| Developer's Advertising/Marketing | Your own marketing campaigns |
| Analytics | Understanding user behavior and measuring effectiveness |
| Product Personalization | Customizing features, content recommendations |
| App Functionality | Required for app to work (e.g., authentication, data sync) |
| Other | Any purpose not listed above |

### Tracking and Collection Definitions

**"Collected"** means data is transmitted off-device and accessible beyond what is needed to service the current request. On-device-only processing is NOT collection.

**"Tracking"** means:
- Linking user/device data from your app with data from other companies' apps, websites, or offline properties for targeted advertising or advertising measurement, OR
- Sharing user/device data with a data broker

Not tracking: first-party analytics or ads based solely on your own company's data, when no tracking as defined above occurs; linkage done solely on-device whose result never leaves the device identifiably; sharing with a broker solely for fraud detection, fraud prevention, or security; sharing with a consumer reporting agency for a credit determination. A fraud/security use doesn't exempt other tracking by the app or its SDKs. Full rules: `axiom-integration (skills/privacy-ux.md)` Part 3.

### App Tracking Transparency (ATT)

Required if your app "tracks" per Apple's definition above.

- Add `NSUserTrackingUsageDescription` to Info.plist (explains why tracking is needed)
- Call `ATTrackingManager.requestTrackingAuthorization()` before tracking
- Respect the result:
  - `.authorized` — User granted permission to track
  - `.denied` — User denied tracking; do not track
  - `.notDetermined` — No authorization decision recorded; the prompt may not have appeared, or the user may have dismissed the iOS 27.2 expanded prompt through "Additional Information". Do not track or automatically retry
  - `.restricted` — Device-level restriction prevents tracking

Request at a contextually appropriate moment, not at first launch.

From iOS 27.2, EU users can receive an expanded prompt; France, Germany, Italy, Poland, and Romania use it regardless of the interface preference. The new `requestTrackingAuthorization(preferExpandedInterface:additionalInformationAction:completionHandler:)` requires the 27.2 SDK and an iOS 27.2 availability gate, with the classic call as the earlier-OS fallback. `NSUserTrackingMarkdownUsageDescription` supplies rich text for the expanded prompt; keep the required `NSUserTrackingUsageDescription` as well.

Eligible EU users may be re-prompted one year after either an approval or a denial, unless device settings prevent tracking requests. Let ATT enforce eligibility instead of assuming a request can only happen once. See `axiom-integration (skills/privacy-ux.md)` for the callback flow, consent handling, and older-SDK fallback.

### Common Purpose Strings (NS*UsageDescription)

These Info.plist keys must be present for each system permission your app requests:

| Permission | Info.plist Key |
|------------|---------------|
| Camera | `NSCameraUsageDescription` |
| Microphone | `NSMicrophoneUsageDescription` |
| Photo Library (read) | `NSPhotoLibraryUsageDescription` |
| Photo Library (write) | `NSPhotoLibraryAddUsageDescription` |
| Location (when in use) | `NSLocationWhenInUseUsageDescription` |
| Location (always) | `NSLocationAlwaysAndWhenInUseUsageDescription` |
| Contacts | `NSContactsUsageDescription` |
| Calendars (full access) | `NSCalendarsFullAccessUsageDescription` |
| Reminders (full access) | `NSRemindersFullAccessUsageDescription` |
| Health | `NSHealthShareUsageDescription`, `NSHealthUpdateUsageDescription` |
| Motion | `NSMotionUsageDescription` |
| Bluetooth | `NSBluetoothAlwaysUsageDescription` |
| Face ID | `NSFaceIDUsageDescription` |
| Local Network | `NSLocalNetworkUsageDescription` |
| Tracking | `NSUserTrackingUsageDescription` |
| Speech Recognition | `NSSpeechRecognitionUsageDescription` |
| Apple Music | `NSAppleMusicUsageDescription` |

Missing purpose strings cause immediate rejection. Purpose string text must clearly explain why the permission is needed in the context of your app's functionality.

### Third-Party SDK Privacy Manifests

Apple maintains a list of commonly used SDKs that require privacy manifests. Starting spring 2024, if your app includes these SDKs without privacy manifests, it will be flagged during submission.

Third-party SDKs should include their own `PrivacyInfo.xcprivacy` in their framework bundle. The aggregate privacy report combines all manifests from your app and embedded frameworks.

If a third-party SDK does not include a privacy manifest, you must declare its data collection in your app's privacy manifest.

---

## Part 3: App Review Guidelines Quick Reference

For the complete guideline index (Sections 1-5), see `skills/app-review-guidelines.md`.

### Most Common Rejection Reasons

See `skills/app-review-guidelines.md` for the full top-10 rejection causes table with percentages.

### App Review Timeline

| Stage | Typical Duration |
|-------|-----------------|
| Waiting for Review | Minutes to hours |
| In Review | Minutes to 24 hours |
| Total (90th percentile) | Under 24 hours |
| Total (edge cases) | Up to 7 days |
| Expedited Review | Same day to 24 hours (if approved) |

Review times increase during holidays and major iOS release periods. Plan submissions accordingly.

---

## Part 4: Age Rating System

### Five-Tier Rating System (Updated January 31, 2026)

| Rating | Triggers |
|--------|----------|
| **4+** | No objectionable material |
| **9+** | Infrequent or mild: profanity, cartoon/fantasy violence, horror/fear themes. Loot boxes present |
| **13+** | Frequent or intense: profanity or crude humor. Infrequent: alcohol/tobacco/drugs references, sexual content/nudity, realistic violence |
| **16+** | Unrestricted web access, frequent medical/treatment info, mature/suggestive themes |
| **18+** | Frequent or intense: alcohol/tobacco/drugs use, sexual content/nudity, realistic violence. Simulated gambling with real-money elements |
| **Unrated** | App cannot be published without completing the questionnaire |

### Capability Declarations (New, WWDC25)

Apps must declare if they include these capabilities:

| Capability | When to Declare |
|------------|----------------|
| Messaging/chat | Any in-app messaging between users |
| User-generated content | Users can post, share, or upload content visible to others |
| Advertising | App displays ads from any ad network |
| Parental controls | App has parental restrictions or family features |
| Age assurance | App verifies user age for restricted content |

These declarations appear alongside the age rating on the App Store product page, giving parents and users additional transparency.

### Regional Variations

Age ratings map differently across regions:

| Apple Rating | Australia | Brazil | Korea | Germany (USK) |
|-------------|-----------|--------|-------|----------------|
| 4+ | 4+ | L (All ages) | All | 0 |
| 9+ | 9+ | A10 | 12+ | 6 |
| 13+ | 13+ | A12 | 15+ | 12 |
| 16+ | 15+ | A16 | 19+ | 16 |
| 18+ | R 18+ | A18 | 19+ | 18 |

The age rating questionnaire automatically generates the appropriate regional ratings based on your answers.

### Age Rating Best Practices

- Answer the questionnaire conservatively; under-rating leads to rejection
- If your app accesses unrestricted web content (WebView without content filter), it will be rated 16+ minimum
- UGC apps typically need 13+ minimum due to moderation requirements
- Simulated gambling (even without real money) requires at least 9+
- Realistic violence in gameplay requires at least 13+

### Age Rating Questionnaire Topics

The questionnaire covers these content categories:

| Category | Options |
|----------|---------|
| Cartoon or Fantasy Violence | None, Infrequent/Mild, Frequent/Intense |
| Realistic Violence | None, Infrequent/Mild, Frequent/Intense |
| Profanity or Crude Humor | None, Infrequent/Mild, Frequent/Intense |
| Mature/Suggestive Themes | None, Infrequent/Mild, Frequent/Intense |
| Alcohol, Tobacco, or Drug Use or References | None, Infrequent/Mild, Frequent/Intense |
| Sexual Content and Nudity | None, Infrequent/Mild, Frequent/Intense |
| Horror/Fear Themes | None, Infrequent/Mild, Frequent/Intense |
| Simulated Gambling | None, Infrequent/Mild, Frequent/Intense |
| Medical/Treatment Information | None, Infrequent/Mild, Frequent/Intense |
| Unrestricted Web Access | Yes/No |

The system automatically calculates your app's age rating across all regions based on your answers.

---

## Part 5: Export Compliance

### Three-Tier Encryption System

| Tier | Encryption Type | Documentation Required |
|------|----------------|----------------------|
| **Exempt** | Apple OS built-in (HTTPS via URLSession, AES data protection, CryptoKit, Keychain, Secure Enclave) | None — set `ITSAppUsesNonExemptEncryption = NO` |
| **Standard** | Industry-standard algorithms (IEEE, IETF, ISO, ITU, ETSI, 3GPP approved) | French ANSSI declaration only (if distributing in France) |
| **Proprietary** | Custom/unpublished algorithms not adopted by standards bodies | US CCATS + French declaration (if France) |

### Encryption Decision Tree

```
Does your app use encryption?
├── No → ITSAppUsesNonExemptEncryption = NO → Done
├── Only Apple OS encryption (HTTPS, Keychain, CryptoKit)?
│   ├── Yes → ITSAppUsesNonExemptEncryption = NO → Done
│   │         (May need annual BIS self-classification report)
│   └── No → Industry-standard algorithm (AES, RSA, etc.)?
│       ├── Yes → ITSAppUsesNonExemptEncryption = YES
│       │         French declaration if distributing in France
│       │         Upload docs → receive ITSEncryptionExportComplianceCode
│       └── No (custom/proprietary) →
│           ITSAppUsesNonExemptEncryption = YES
│           US CCATS required (~2 business days)
│           French declaration if France
│           Upload docs → receive ITSEncryptionExportComplianceCode
```

### Info.plist Keys

```xml
<!-- Most apps: only Apple OS encryption -->
<key>ITSAppUsesNonExemptEncryption</key>
<false/>

<!-- Apps with non-exempt encryption (bypasses questionnaire on future submissions) -->
<key>ITSAppUsesNonExemptEncryption</key>
<true/>
<key>ITSEncryptionExportComplianceCode</key>
<string>YOUR_COMPLIANCE_CODE</string>
```

Setting `ITSAppUsesNonExemptEncryption` in Info.plist skips the encryption questionnaire on every submission.

### Exempt Encryption Uses

No documentation needed:
- HTTPS/TLS (URLSession, Network.framework, WKWebView)
- Secure Enclave, Keychain, biometric auth
- CryptoKit, Security.framework per Apple docs
- Password hashing (bcrypt, scrypt, PBKDF2)

### Non-Exempt Encryption Uses

Documentation required:
- Custom encryption algorithms
- OpenSSL, libsodium for non-standard purposes
- End-to-end encrypted messaging
- VPN implementations
- Custom DRM systems

### France-Specific

Import/export controlled by ANSSI. Banking and medical apps are exempt. Applies to: secure storage, secure communications, security/antivirus apps.

---

## Part 6: Account and Authentication

### Account Deletion (Required Since June 2022)

Apps that support account creation must offer account deletion. Requirements:

| Requirement | Details |
|-------------|---------|
| Full deletion | Must fully delete the account, not just deactivate |
| Easy to find | Must be accessible from app settings; not buried behind support tickets |
| Inform timeline | Tell user how long deletion takes |
| Confirm completion | Notify user when deletion is complete |
| Delete shared UGC | Must handle user-generated content shared with others |
| Revoke SIWA tokens | Call Apple's revoke token endpoint for Sign in with Apple accounts |
| Handle subscriptions | Warn about active subscriptions; direct to subscription management |

#### Sign in with Apple Token Revocation

```swift
// Server-side: revoke SIWA tokens when account deleted
// POST https://appleid.apple.com/auth/revoke
// Parameters: client_id, client_secret, token, token_type_hint
```

Failing to revoke SIWA tokens during account deletion is a common rejection reason.

### Sign in with Apple (Guideline 4.8)

**Required when:** Your app offers ANY third-party or social login option (Google, Facebook, Twitter, email/password via third-party provider).

#### Exceptions — SIWA not required when
- App is for company employees only (internal enterprise app)
- App is for education or enterprise with existing institutional auth
- App uses government or industry-backed citizen ID systems
- App is a client for a specific third-party service (e.g., Gmail app, Slack)

When SIWA is required, it must be offered as an equally prominent option alongside other sign-in methods. It cannot be hidden or given less visual weight.

### Account Deletion Implementation Checklist

| Step | Details |
|------|---------|
| 1. Add UI entry point | Settings screen, clearly labeled "Delete Account" |
| 2. Explain consequences | Show what will be deleted (data, subscriptions, purchases) |
| 3. Require confirmation | User must explicitly confirm deletion |
| 4. Handle active subscriptions | Direct user to cancel active subscriptions before deletion |
| 5. Process deletion | Delete all user data from your servers |
| 6. Revoke SIWA tokens | Call Apple's revoke endpoint if SIWA was used |
| 7. Confirm to user | Send email or in-app confirmation when deletion is complete |
| 8. Define timeline | State how long deletion takes (immediately, 30 days, etc.) |

Apple specifically rejects apps that:
- Require users to call a phone number to delete their account
- Require users to send an email to request deletion
- Only offer account deactivation (hiding profile) instead of full deletion
- Don't handle SIWA token revocation

---

## Part 7: Monetization and IAP

### IAP Submission Pipeline

In-app purchases have a separate review process from app submissions:

| Scenario | Behavior |
|----------|----------|
| First IAP ever | Must be bundled with a new app version submission |
| Subsequent IAPs | Can be submitted independently of app updates |
| IAP metadata change | Submitted for review independently |
| IAP price change | Takes effect without review |

#### Required IAP Metadata

| Field | Required | Notes |
|-------|----------|-------|
| Reference Name | Yes | Internal name (not visible to users) |
| Product ID | Yes | Unique, cannot be reused after deletion |
| Type | Yes | Consumable, non-consumable, auto-renewable, non-renewing |
| Price | Yes | Select from Apple's price tiers |
| Display Name | Yes | Localizable, shown to users |
| Description | Yes | Localizable, shown to users |
| Screenshot | Yes | One screenshot showing the IAP in context |
| Review Notes | No | Explain what the IAP unlocks |

#### IAP Status Flow

```
Missing Metadata → Ready to Submit → Waiting for Review → In Review → Approved
                                                                    → Rejected
```

IAP must be in "Ready to Submit" status before it can be included in an app submission.

### Subscription Rules (Guideline 3.1.2)

| Rule | Details |
|------|---------|
| Ongoing value | Subscriptions must provide continuing value over time |
| Minimum duration | 7 days minimum subscription period |
| Cross-device | Must work across all user's devices where app is available |
| Transparent terms | Clearly state price, duration, auto-renewal, and cancellation |
| No removing features | Cannot remove previously paid functionality to force subscription |
| Grace period | Support billing grace period (user retains access during retry) |
| Upgrade/downgrade | Must support plan changes within subscription group |

### Loot Boxes (Guideline 3.1.1)

Apps offering loot boxes or random item mechanics must disclose the odds of receiving each type of item before purchase.

### External Payment Eligibility

| Category | Guideline | What's Allowed |
|----------|-----------|----------------|
| Reader apps | 3.1.3(a) | Link to website for previously purchased content (magazines, newspapers, books, audio, music, video) |
| Multiplatform services | 3.1.3(b) | Cross-platform subscriptions (e.g., Netflix, Spotify) |
| Enterprise services | 3.1.3(c) | B2B apps for organizations, not individual consumers |
| Person-to-person | 3.1.3(d) | Real-time one-to-one services (tutoring, consulting, ride-sharing) |
| Physical goods/services | 3.1.3(e) | Goods consumed outside the app (food delivery, clothing, physical subscriptions) |

Apps in these categories may accept payment outside the IAP system.

### Subscription Group Architecture

| Concept | Details |
|---------|---------|
| Subscription Group | Collection of related subscription tiers (e.g., Basic, Pro, Premium) |
| Service Level | Rank within a group; determines upgrade/downgrade behavior |
| Upgrade | Moving to higher service level (immediate, prorated) |
| Downgrade | Moving to lower service level (effective at next renewal) |
| Crossgrade | Same service level, different duration (monthly ↔ annual) |
| Family Sharing | Can be enabled per subscription group |

#### Subscription Pricing

| Feature | Details |
|---------|---------|
| Price tiers | Apple provides 900+ price points across 175+ storefronts |
| Price equalization | Apple auto-equalizes prices across currencies |
| Custom pricing | Set custom prices per storefront |
| Introductory offers | Free trial, pay-as-you-go, pay-up-front |
| Promotional offers | For existing/lapsed subscribers; requires server-signed JWS |
| Win-back offers | For lapsed subscribers; displayed by system automatically |
| Offer codes | Distributable codes for free/discounted access |

#### Subscription Restore Purchases

All subscription apps must implement Restore Purchases functionality. This is tested during App Review. Implement via:

```swift
try await AppStore.sync()
```

If Restore Purchases is missing or non-functional, the app will be rejected.

### Free Trial Best Practices

| Practice | Details |
|----------|---------|
| Duration display | Clearly show trial length before user commits |
| Post-trial pricing | Show what price will be charged after trial ends |
| Cancellation | Explain how to cancel before trial ends |
| No dark patterns | Don't make cancellation difficult or hard to find |
| Reminder | Consider sending a push notification before trial ends |

---

## Part 8: EU-Specific Compliance

### Digital Services Act (DSA) Trader Status

**Applies to:** ALL apps distributed in the EU (27 member states)

**Timeline:** Since February 17, 2025, apps without declared trader status are subject to removal from the EU App Store.

#### What is Trader Status?

A self-assessment: are you acting as a "trader" (selling goods/services to EU consumers) or a non-trader (hobby, open-source, non-commercial)? Apple cannot determine this for you.

#### Trader Requirements

If you declare as a trader, you must provide:

| Field | Required | Verification |
|-------|----------|-------------|
| Legal name | Yes | — |
| Address | Yes | — |
| Phone number | Yes | Verified via 2FA |
| Email address | Yes | Verified via 2FA |
| Company registration | Where applicable | — |
| VAT ID | Where applicable | — |

This contact information is displayed on your EU product page.

#### Declaring in App Store Connect

```
App Store Connect > Users and Access > Developer Profile > Trader Status
```

Select your trader status for each app. If you have both paid and free apps, each app may have a different trader classification.

### EU Alternative Distribution

Under the Digital Markets Act (DMA), Apple allows alternative app distribution in the EU:
- Alternative app marketplaces
- Web distribution (notarized apps)
- Alternative payment processing

These require separate business terms (Alternative Terms Addendum) and additional compliance steps. See Apple's EU developer documentation for details.

### EU 27 Member States

Apps distributed in any of these territories require DSA compliance:

Austria, Belgium, Bulgaria, Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy, Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden.

If your app is available in "All Territories" (the default), it is available in the EU and DSA compliance is required.

---

## Part 9: Build Upload and Processing

### Upload Methods

| Method | Best For |
|--------|---------|
| **Xcode** (recommended) | Most developers; integrated with Archive workflow |
| **Xcode Cloud** | CI/CD with automatic builds and distribution |
| **Transporter** | Standalone macOS app for batch uploads |
| **altool** (CLI) | Scripted CI/CD pipelines |
| **App Store Connect API** | Fully automated workflows |

### Build Identifiers

| Identifier | Purpose | Example | Rules |
|------------|---------|---------|-------|
| Bundle ID | Uniquely identifies your app | `com.company.app` | Set once, cannot change |
| Version Number | User-facing version | `2.1.0` | Must increment for each release |
| Build String | Distinguishes builds of same version | `2.1.0.42` | Must be unique per version per platform |

### Build Selection

- Only one build can be selected per version
- Build selection can be changed until the version is submitted for review
- "Missing Compliance" status blocks build selection until export compliance questions are answered

### SDK Requirements

| Effective Date | Requirement |
|----------------|-------------|
| April 2025 (current) | Xcode 16, iOS 18 SDK |
| April 28, 2026 (upcoming) | Xcode 26, iOS 26 SDK |

Apps built with outdated SDKs will be rejected after the effective date for new submissions. Existing apps on the store are not affected until they submit an update.

### Build Processing

After upload, Apple processes your build:

1. **Upload** — Binary transferred to Apple (5-30 minutes depending on size)
2. **Processing** — Apple validates binary, runs automated checks (15-60 minutes)
3. **Available** — Build appears in App Store Connect, ready for TestFlight or submission
4. **Email notification** — Sent when processing completes or fails

Common processing failures:
- Missing required architectures (arm64 required)
- Invalid provisioning profile or signing identity
- Missing privacy manifest for third-party SDKs on Apple's list
- Info.plist missing required keys
- Binary too large (OTA download limit: 200 MB over cellular)

### IPv6 Compatibility

All apps must work on IPv6-only networks. Apple's review environment uses IPv6. Common issues:
- Hard-coded IPv4 addresses
- Using low-level socket APIs instead of high-level networking
- Third-party SDKs with IPv4-only code

Use `URLSession` or `Network.framework` to ensure IPv6 compatibility automatically.

### App Thinning and Bitcode

| Topic | Status |
|-------|--------|
| Bitcode | Deprecated since Xcode 14; no longer accepted |
| App Thinning | Active; Apple generates device-specific variants |
| On-Demand Resources | Active; tag resources for download on demand |
| Asset catalogs | Used for app thinning of images (1x/2x/3x) |

### Entitlements and Capabilities

Certain features require entitlements configured in Xcode and provisioning profiles:

| Capability | Entitlement | Common Issues |
|------------|-------------|---------------|
| Push Notifications | `aps-environment` | Certificate expiry, missing provisioning |
| App Groups | `com.apple.security.application-groups` | Shared container ID mismatch |
| Associated Domains | `com.apple.developer.associated-domains` | AASA file not served correctly |
| HealthKit | `com.apple.developer.healthkit` | Missing required capabilities |
| Background Modes | `UIBackgroundModes` | Using modes without justification |
| Sign in with Apple | `com.apple.developer.applesignin` | Missing from provisioning profile |
| CloudKit | `com.apple.developer.icloud-services` | Container ID mismatch |
| In-App Purchase | — | Enabled by default; StoreKit config needed for testing |

### TestFlight Submission

| Aspect | Internal Testing | External Testing |
|--------|-----------------|-----------------|
| Testers | Up to 100 ASC users | Up to 10,000 via email/public link |
| Review required | No | Yes (first build per version, full App Review) |
| Review time | — | Usually under 24 hours |
| Build expiry | 90 days from upload | 90 days from upload |
| Groups | Automatic (ASC roles) | Custom groups with "What to Test" notes |
| Feedback | Crash reports | Screenshots, text feedback, crash reports |
| Submission limit | — | Max 6 builds per 24-hour period |

**TestFlight readiness checklist**:
- [ ] Internal tester group exists (required before creating external groups)
- [ ] Beta App Description set (can differ from production)
- [ ] Feedback email configured
- [ ] "What to Test" notes written for each external group
- [ ] Export compliance answered (required for beta builds too)
- [ ] Demo credentials included (if login required)
- [ ] First external build: expect full App Review (guideline compliance checked)

**Gotchas**:
- Builds uploaded as "TestFlight Internal Only" from Xcode/Xcode Cloud can only go to internal groups
- Managed Apple Accounts (School/Business Manager) cannot be testers
- Public link tester cap is configurable (1-10,000) per link
- Builds remain testable even after the app goes live on the App Store
- Developer can manually expire builds before 90 days

### Xcode Cloud (CI/CD)

Xcode Cloud is Apple's CI/CD service built into Xcode — it builds and tests in the cloud in parallel across multiple devices and OS versions, then feeds distribution to TestFlight and the App Store. Builds run on **ephemeral VMs**: source is fetched only when a build starts and discarded afterward (never stored; Apple has no access to it).

#### Onboarding

| Step | Where |
|---|---|
| Start | Report navigator → Cloud tab → Get Started |
| Team | Auto-matched to your Signing & Distribution settings |
| Source | Onboarding assistant connects your repo (steps vary by provider) |
| First build | Default workflow created; one click to run |

Add a second app from the same workspace (e.g. a macOS target sharing a framework) via the Report navigator's More button → Create Workflow — there is no repeat repository-connection step once access is granted. The Cloud section then shows builds and workflows for every onboarded app.

#### Distribution setup

Two paths, both from the Cloud navigator (secondary-click the app):
- **Set Up Distribution** — provide app name, Bundle ID, and SKU (with live "already taken" checks). Xcode Cloud creates the App Store Connect app record, verifies it, and registers the Bundle ID + SKU in the background, then auto-creates an internal-TestFlight distribution workflow.
- **Manage Workflows → add an archive action** — the archive action is required to distribute to TestFlight; setup is offered inline.

#### Webhooks

Configure under Manage Webhooks (a name plus a publicly resolvable Payload URL). Xcode Cloud POSTs a build-info payload at each lifecycle stage — useful for dashboards and external automation:

| Event | Fires when |
|---|---|
| Created | A build is created |
| Started | The build starts running |
| Completed | The build finishes |

The webhook list shows delivery history per send, with a success indicator.

#### Additional repositories

For modular, multi-repo codebases (e.g. a shared framework split into its own repository), add it under Manage Repositories → Add with the Git remote URL. The primary repository stays at the top; additional repositories reuse existing remote authorization, so cloud builds resolve all dependencies.

---

## Part 10: WWDC25 Changes

### Draft Submissions

Group multiple items into a single draft submission:
- App version + new IAPs + product page changes
- Review everything together instead of separate submissions
- Draft state: prepare items over time, submit when ready

### Reusable Build Numbers on Failure

When a build is rejected due to metadata issues (not binary issues), you can reuse the same build without re-uploading. Previously, rejected builds required a new build string.

### Builds Retained After Error Rejection

Builds are no longer removed from App Store Connect after certain rejection types. You can fix metadata issues and resubmit with the same build.

### Accessibility Nutrition Labels

New App Store metadata for accessibility features:
- Declare which accessibility features your app supports
- Displayed on your App Store product page
- Categories include VoiceOver support, Dynamic Type, Switch Control, etc.
- Helps users find apps that meet their accessibility needs

### App Store Tags (LLM-Generated, Editable)

Apple generates descriptive tags for your app using AI:
- Tags appear on your product page
- You can review and edit suggested tags
- Tags improve discoverability in search
- Based on app metadata, description, and functionality

### Custom Product Page Keywords

Product pages can now have unique keywords:
- Different keywords per custom product page
- Improves targeting for different audiences
- Each custom page can appear in different search results

### Offer Codes Expanded

Offer codes now support all IAP types:
- Consumables
- Non-consumables
- Non-renewing subscriptions
- Auto-renewable subscriptions (existing)

### Review Summaries (AI-Generated)

Apple generates AI summaries of user reviews:
- Summarizes common themes across reviews
- Displayed on the product page
- Updated as new reviews come in
- Helps users quickly understand app quality and common feedback

### Analytics Enhancements

100+ new analytics metrics including:
- Pre-order conversion funnels
- Custom product page performance comparison
- Subscription lifecycle metrics (trial to paid conversion, churn timing)
- Peer group benchmarking (compare performance against similar apps)
- Download source attribution refinements

### Age Rating Overhaul

Five-tier system with new capability declarations (see Part 4 for full details).

### Custom Product Pages (Existing, Enhanced in WWDC25)

Custom product pages allow different App Store presentations for different audiences:

| Feature | Details |
|---------|---------|
| Maximum | Up to 35 custom product pages per app |
| Customizable | Screenshots, app previews, promotional text |
| NOT customizable | App name, icon, description, What's New |
| URL | Unique URL per custom page for attribution |
| Keywords | New in WWDC25: unique keywords per custom product page |
| Analytics | Impressions, downloads, conversion rates per page |

### App Store Pricing Changes

| Feature | Details |
|---------|---------|
| 900+ price points | Expanded from original 87 tiers |
| Global equalization | Automatic currency conversion with regional pricing |
| Custom pricing | Override auto-equalization for specific storefronts |
| Price increases | Existing subscribers notified; must consent for >50% increase |
| Regional pricing | Set prices optimized for each market's purchasing power |

---

## Part 11: WWDC26 Changes `OS27`

### Product Page Header and Search Results Visuals

Two new App Store surfaces (WWDC 2026-205), available on iOS 27 and iPadOS 27 (the session names no other platforms):
- **Product Page Header** — images or videos as the first visual element on your product page, expressing brand identity
- **Custom Search Results visuals** — replace the default screenshot display in search

Both draw from the new **Asset Library**, a centralized App Store Connect area managing screenshots, preview videos, in-app event media, and the new marketing images/videos — which ASC calls "creative assets". Two submission paths:
1. The familiar version-page flow — now with a **Preview** function showing iPhone/iPad, orientations, and languages before submitting
2. **Standalone Asset Library review** — submit creative assets *without a version update*

Assets approved via either path can then be swapped onto the Product Page Header or Search Results in real time with no additional review.

Creative assets compose with Custom Product Pages (deep-link-on-install), Product Page Optimization A/B tests, and Apple Ads placements. Upload and submission are automatable via the App Store Connect API; the Apple Ads Platform API ships open-source client libraries including Swift.

### Retention Messaging

A new App Store Connect / App Store Server API feature (WWDC 2026-309; the session states no OS gate) that shows your value-proposition message in the subscription **cancellation flow** — three views: message only, message + image, or message + offer. Message text is required; image and offer are optional, and an eligible offer takes the image's place. Apple cites average save-rate lifts of +1.4 points, up to +5.5 with promotional-offer messages, noting results vary across developers.

- **Configuration**: a new area on the ASC Subscriptions page — named messages with localized text and live preview, Asset Library images, mapping to one or more subscriptions, and attachable **retention offers** (a new offer type appearing as `offerType: 5` in signed transaction/renewal info; the App Store auto-picks the best eligible offer). Also configurable via the App Store Connect API; fully testable in sandbox.
- **Real-time Retention Messaging** (access via interest form): the App Store sends a server-to-server request (`originalTransactionId`, `productId`, `userLocale`, `requestIdentifier`, `environment`, `signedDate`, and more) and you respond with `message`, `alternateProduct` (switch-plan — exclusive to real-time), or `promotionalOffer` (with `promotionalOfferSignatureV2` — a signature is still required for promotional offers used in retention messages).
- **Retention Messaging API** (`/inApps/v1/messaging` on the App Store Server API host): realtime-URL config, message/default/image management, and a sandbox-only `performanceTest` you must pass before production. Fallback chain: real-time response → ASC message → API default. Apple recommends configuring ASC Retention Messaging as a fallback even when using real-time.
- Related: iOS 26.5 introduced monthly subscriptions with a 12-month commitment; the real-time API can offer that plan type as a switch plan (`billingPlanType`).

### Group and Volume Subscription Purchasing

Two new purchase paths for auto-renewable subscriptions (WWDC 2026-391; StoreKit 2 required; the session states no numeric OS availability):
- **Group purchases** — in-app: a buyer purchases multiple seats and shares an invite link (small teams, social groups)
- **Volume purchasing** — organizations buy via Apple Business Manager / Apple School Manager and assign seats through MDM, like app distribution

ASC controls: on by default for most new and existing StoreKit 2 subscriptions, but **opted out by default if Family Sharing is enabled**; you can restrict selling to Apple School Manager only (education pricing) or disable group/org selling entirely while still selling to individuals. **Volume pricing**: up to 5 price bands with custom seat-quantity thresholds and per-seat prices. Seat lifecycle for group purchases (invite links, acceptance, cancellation) is system-managed by default, with each member getting their own transaction. Custom invitation flows are powered by new (unnamed in the session) App Store Server API endpoints; the separate **Group management endpoints** query a customer's groups and a group's members, and are supported for volume purchasing and group purchases that use the included seat-management flows. For the in-app purchase-request side (seat counts in StoreKit 2 purchases), see axiom-integration (skills/in-app-purchases.md, skills/storekit-ref.md).

### Enhanced In-App Purchase Submissions

App Store Connect unifies IAP review into the standard submission workflow (WWDC 2026-210):

- Group multiple IAP products as review items into a **single App Review submission**, combinable with other review items — in-app events, custom product pages, and product page optimizations — with a centralized status view for all items.
- Flow: from a product (or multi-selected products in the IAP list), use the **Add for Review** drop-down to attach to an in-draft submission.
- App Store Connect API: **`reviewSubmissions` is expanding** to support In-App Purchase, subscription, and subscription-group resources, automating all review items through a single interface. The existing IAP, subscription, and subscription-group review resources **will be deprecated** in favor of `reviewSubmission` and `reviewSubmissionItems` — Apple says to start migrating now.

---

## Expert Review Checklist

For the comprehensive 9-section submission checklist, see `skills/expert-review-checklist.md`.
For the discipline-focused pre-flight workflow, see `app-store-submission`.

---

## Troubleshooting

### 10 Common Submission Issues

| # | Issue | Cause | Fix |
|---|-------|-------|-----|
| 1 | "Missing Compliance" on build | Export compliance questions not answered | App Store Connect > build > answer encryption questions |
| 2 | Build not appearing in ASC | Processing delay or failure | Wait 15-60 min; check email for processing errors |
| 3 | "Add for Review" button grayed | Missing required metadata | Check all required fields in App Information and Version Information |
| 4 | Screenshots wrong size | Device spec mismatch | Use exact pixel dimensions for each device size class |
| 5 | Privacy policy URL invalid | Not HTTPS or not publicly accessible | Must be `https://` URL accessible without login |
| 6 | IAP not available for review | IAP not in "Ready to Submit" status | Complete all IAP metadata including screenshot; set status |
| 7 | Age rating warnings | Questionnaire incomplete or capabilities not declared | Complete questionnaire; answer new capability questions |
| 8 | DSA trader status incomplete | Email or phone not verified | Complete 2FA verification for both email and phone |
| 9 | Build string conflict | Duplicate build string for same version | Each build upload must have a unique build string |
| 10 | "In Review" for extended period | Complex review or holiday backlog | 90% of apps reviewed in <24h; use expedited review for critical/urgent issues |

For rejection handling (expedited review, appeals, Resolution Center), see `app-store-diag` Pattern 7.
For pre-submission testing checklists, see `app-store-diag` or `app-store-submission`.

### App Store Connect API for Submissions

For automated submission workflows:

| Endpoint | Purpose |
|----------|---------|
| `POST /v1/appStoreVersions` | Create new version |
| `PATCH /v1/appStoreVersions/{id}` | Update version metadata |
| `POST /v1/appStoreVersionSubmissions` | Submit version for review |
| `GET /v1/apps/{id}/appStoreVersions` | List all versions |
| `POST /v1/appScreenshots` | Upload screenshots |
| `POST /v1/appPreviews` | Upload app preview videos |
| `GET /v1/apps/{id}/builds` | List processed builds |

Authentication requires an API key from App Store Connect (Users and Access > Integrations > App Store Connect API).

---

## Resources

**WWDC**: 2022-10166, 2025-224, 2025-241, 2025-252, 2025-328, 2026-205, 2026-210, 2026-261, 2026-309, 2026-391

**Docs**: /app-store/review/guidelines, /app-store/submitting, /app-store/app-privacy-details, /help/app-store-connect

**Skills**: app-store-submission, app-store-diag, privacy-ux, storekit-ref, accessibility-diag
