
# StoreKit 2 — Complete API Reference

> StoreKit is for digital content + subscriptions for digital content. For physical / service payments, see `axiom-payments`.

## Overview

StoreKit 2 is Apple's modern in-app purchase framework with async/await APIs, automatic receipt validation, and SwiftUI integration. This reference covers every API, the iOS 18.4 and 26.4 additions, and the 27-cycle (WWDC 2026) changes.

### Product Types Supported

**Consumable**:
- Products that can be purchased multiple times
- Examples: coins, hints, temporary boosts
- Do NOT restore on new devices

**Non-Consumable**:
- Products purchased once, owned forever
- Examples: premium features, level packs, remove ads
- MUST restore on new devices

**Auto-Renewable Subscription**:
- Subscriptions that renew automatically
- Organized into subscription groups
- MUST restore on new devices
- Support: free trials, intro offers, promotional offers, win-back offers

**Non-Renewing Subscription**:
- Fixed duration subscriptions (no auto-renewal)
- Examples: seasonal passes
- MUST restore on new devices

### Key Improvements Over StoreKit 1

- **Async/Await**: Modern concurrency instead of delegates/closures
- **Automatic Verification**: JSON Web Signature (JWS) verification built-in
- **Transaction Types**: Strong Swift types instead of SKPaymentTransaction
- **Testing**: StoreKit configuration files for local testing
- **SwiftUI Views**: Pre-built purchase UIs (ProductView, SubscriptionStoreView)
- **Server APIs**: App Store Server API and Server Notifications


### Advanced Commerce & AppTransaction Additions OS27

New in the 27 cycle — all platforms and `@available(anyAppleOS 27, *)` (Swift 6.4 / Xcode 27) unless a bullet notes otherwise:

- **Subscription Bundles and Suites** — two new `Product.ProductType` values, `.subscriptionBundle` and `.subscriptionSuite`, plus `Product.SubscriptionInfo.bundledSubscriptions: [BundledSubscription]` (non-empty only for a `.subscriptionBundle` product; each `BundledSubscription` carries `id` / `displayName` / `description` / `price` / `displayPrice` / `isFamilyShareable` / `subscriptionGroupID` / `subscriptionGroupLevel` / `subscriptionGroupDisplayName`). A *Bundle* is a group of subscriptions that can be purchased individually but are sold together in a single purchase at a better price; a *Suite* is a group of subscriptions that exist only in the context of the Suite — not purchasable individually, typically serving a related set of apps. The API is testable in Xcode 27; Apple says more details on the program are coming later in 2026.
- **Bundle transaction fields** (back-deployed in the 27 SDK): `Transaction.bundleProductID` / `bundleSubscriptionGroupID` / `bundleTransactionID` / `bundleOriginalTransactionID` / `previousOriginalTransactionID` (all optional), `Transaction.RevocationReason.upgradedToBundle`; `SubscriptionRenewalInfo.bundleProductID` / `bundleSubscriptionGroupID` / `bundleOriginalTransactionID` / `willUnbundle`, `SubscriptionRenewalInfo.ExpirationReason.unbundled`.
- **Advanced Commerce partners** — `Transaction.AdvancedCommerceInfo.Partner` (`id`, `name: String?`) and `Item.Details.partners: [Partner]`.
- **Offer code redemption rework** — redemption APIs now return the redeemed transaction and accept `RedeemOption` values; iOS / macCatalyst / macOS / visionOS 27 only (not tvOS / watchOS, unlike the rest of this list); see Offer Codes below.
- **`AppTransaction.all`** — an `AppTransaction.AppTransactions` async sequence yielding every `VerificationResult<AppTransaction>` for this app version, alongside the existing single `AppTransaction.shared`.
- **`AppTransaction.storeType`** — `StoreType.consumer` / `.education` / `.enterprise`, distinguishing the storefront an install came through. A back-deployed `storeTypeStringRepresentation` accessor covers pre-27 OSes and is deprecated at 27 in favor of `storeType`.
- **New error cases** — `RefundRequestError.ineligible` and `StoreKitError.invalidPresentationContext`; handle both in existing `catch` blocks.

This is a what's-new pointer — full Advanced Commerce adoption (server-side commerce, partner / redeem flows) is its own subject; WWDC 2026-210 covers the client-visible delta.

### Group and Volume Subscription Purchasing (WWDC 2026)

Subscriptions can now be sold to groups (a customer buys multiple seats and shares an invite link) and to organizations (volume purchasing via Apple Business Manager / Apple School Manager, seats assigned through device management). StoreKit-side facts from WWDC 2026-391:

- **Requires StoreKit 2**; available for all auto-renewable subscriptions.
- **On by default** for most new and existing StoreKit 2 subscriptions. If your subscription has Family Sharing enabled, group/organization sales are **opted out by default** so you control how the two options interact.
- For group purchases, your own in-app UI triggers the StoreKit 2 purchase flow: get the number of seats requested from the customer and pass it into the StoreKit 2 purchase request. **No dedicated purchase-option symbol for the seat count ships as of the Xcode 27.0 SDK** (only the general `.quantity(_:)` option) — check newer SDKs before writing code against this.
- When seat assignments complete (either purchase type), **the App Store assigns a transaction for each member** — your existing `Transaction.updates` / entitlement flow grants access per member. Member transactions surface as `Transaction.OwnershipType.assigned` (`"ASSIGNED"`); seat revocations as `Transaction.revocationType == .assignmentRevocation` (`"ASSIGNMENT_REVOKE"`; `revocationType` is a 26.4 field); the storefront platform for managed distribution appears as `AppStore.Platform.managed`. `assigned` and `AppStore.Platform.managed` ship back-deployed in the 27 SDK; reading `revocationType` / `.assignmentRevocation` requires an iOS 26.4+ deployment target (or an availability guard).
- By default group purchases use Apple's included seat management (invite-link generation, acceptance tracking, seat lifecycle such as cancellations). Custom invitation flows will be powered by new App Store Server API endpoints (not yet named).
- App Store Server API **Group management endpoints** let you query all the groups a customer is in and all the members in a group — supported for volume purchasing and for group purchases using the included seat management flows.

ASC configuration (volume pricing bands, ASM-only restriction, availability) is covered in `axiom-shipping (skills/app-store-ref.md)` Part 11 — cross-reference, don't duplicate.

---

## When to Use This Reference

Use this reference when:
- Implementing in-app purchases with StoreKit 2
- Understanding new iOS 18.4 fields (appTransactionID, offerPeriod, etc.)
- Adding commitment billing plans, subscription bundles/suites, or group/volume selling
- Looking up specific API signatures and parameters
- Planning subscription architecture
- Debugging transaction issues
- Implementing StoreKit Views
- Integrating with App Store Server APIs

**Related Skills**:
- `skills/in-app-purchases.md` — Discipline skill with testing-first workflow, architecture patterns
- `iap-auditor` agent — audits existing IAP code
- `iap-implementation` agent — implements IAP from scratch

---

## Product

### Overview

`Product` represents an in-app purchase item configured in App Store Connect or StoreKit configuration file.

### Loading Products

**Basic Loading**:
```swift
import StoreKit

let productIDs = [
    "com.app.coins_100",
    "com.app.premium",
    "com.app.pro_monthly"
]

let products = try await Product.products(for: productIDs)
```

#### From WWDC 2021-10114

**Handling Missing Products**:
```swift
let products = try await Product.products(for: productIDs)

// Check what loaded
let loadedIDs = Set(products.map { $0.id })
let missingIDs = Set(productIDs).subtracting(loadedIDs)

if !missingIDs.isEmpty {
    print("Missing products: \(missingIDs)")
    // Products not configured in App Store Connect or .storekit file
}
```

### Product Properties

**Basic Properties**:
```swift
let product: Product

product.id // "com.app.premium"
product.displayName // "Premium Upgrade"
product.description // "Unlock all features"
product.displayPrice // "$4.99"
product.price // Decimal(4.99)
product.type // .nonConsumable
```

**Product Type Enum**:
```swift
switch product.type {
case .consumable:
    // Coins, hints, boosts
    break
case .nonConsumable:
    // Premium features, level packs
    break
case .autoRenewable:
    // Monthly/annual subscriptions
    break
case .nonRenewable:
    // Seasonal passes
    break
// OS27 also adds .subscriptionBundle / .subscriptionSuite — see the
// Advanced Commerce additions in the Overview
default:
    break
}
```

### Subscription-Specific Properties

**Check if Product is Subscription**:
```swift
if let subscriptionInfo = product.subscription {
    // Product is auto-renewable subscription
    let groupID = subscriptionInfo.subscriptionGroupID
    let period = subscriptionInfo.subscriptionPeriod
}
```

**Subscription Period**:
```swift
let period = product.subscription?.subscriptionPeriod

switch period?.unit {
case .day:
    print("\(period?.value ?? 0) days")
case .week:
    print("\(period?.value ?? 0) weeks")
case .month:
    print("\(period?.value ?? 0) months")
case .year:
    print("\(period?.value ?? 0) years")
default:
    break
}
```

**Introductory Offer**:
```swift
if let introOffer = product.subscription?.introductoryOffer {
    print("Free trial: \(introOffer.period.value) \(introOffer.period.unit)")
    print("Price: \(introOffer.displayPrice)")

    switch introOffer.paymentMode {
    case .freeTrial:
        print("Free trial - no charge")
    case .payAsYouGo:
        print("Discounted price per period")
    case .payUpFront:
        print("One-time discounted price")
    default:
        break
    }
}
```

**Promotional Offers**:
```swift
let offers = product.subscription?.promotionalOffers ?? []

for offer in offers {
    print("Offer ID: \(offer.id)")
    print("Price: \(offer.displayPrice)")
    print("Period: \(offer.period.value) \(offer.period.unit)")
}
```

### Purchase Methods

**Purchase with UI Context (iOS 18.2+)**:
```swift
let product: Product
let scene: UIWindowScene

let result = try await product.purchase(confirmIn: scene)
```

#### From WWDC 2025-241:9:32

**Purchase with Options**:
```swift
let accountToken = UUID()

let result = try await product.purchase(
    confirmIn: scene,
    options: [
        .appAccountToken(accountToken)
    ]
)
```

#### From WWDC 2025-241:11:01

**Purchase with Promotional Offer (JWS Format)**:
```swift
let jwsSignature: String // From your server

let result = try await product.purchase(
    confirmIn: scene,
    options: Set(
        Product.PurchaseOption.promotionalOffer("promo_winback", compactJWS: jwsSignature)
    )
)
```

#### From WWDC 2025-241:10:55

**Purchase with Custom Intro Eligibility**:
```swift
let jwsSignature: String // From your server

let result = try await product.purchase(
    confirmIn: scene,
    options: [
        .introductoryOfferEligibility(compactJWS: jwsSignature)
    ]
)
```

#### From WWDC 2025-241:10:42

**SwiftUI Purchase (Using Environment)**:
```swift
struct ProductView: View {
    let product: Product
    @Environment(\.purchase) private var purchase

    var body: some View {
        Button("Buy \(product.displayPrice)") {
            Task {
                do {
                    let result = try await purchase(product)
                    // Handle result
                } catch {
                    print("Purchase failed: \(error)")
                }
            }
        }
    }
}
```

#### From WWDC 2025-241:9:50

### Product.PurchaseResult

**Handling Purchase Results**:
```swift
let result = try await product.purchase(confirmIn: scene)

switch result {
case .success(let verificationResult):
    // Purchase succeeded - verify transaction
    guard let transaction = try? verificationResult.payloadValue else {
        print("Transaction verification failed")
        return
    }

    // Grant entitlement
    await grantEntitlement(for: transaction)
    await transaction.finish()

case .userCancelled:
    // User tapped "Cancel" in payment sheet
    print("User cancelled purchase")

case .pending:
    // Purchase requires action (Ask to Buy, payment issue)
    // Transaction will arrive via Transaction.updates when approved
    print("Purchase pending approval")

@unknown default:
    break
}
```

#### From WWDC 2025-241

---

## Transaction

### Overview

`Transaction` represents a successful in-app purchase. Contains purchase metadata, product ID, purchase date, and for subscriptions, expiration date.

### New Fields (iOS 18.4)

**appTransactionID**:
```swift
let transaction: Transaction
let appTransactionID = transaction.appTransactionID
// Unique ID for app download (same across all purchases by same Apple Account)
```

#### From WWDC 2025-241:4:13

**offer.period**:
```swift
if let offerPeriod = transaction.offer?.period {
    print("Offer duration: \(offerPeriod)")
    // Product.SubscriptionPeriod (unit + value); an ISO 8601 string comes from offerPeriodStringRepresentation
}
```

#### From WWDC 2025-249:3:11

**advancedCommerceInfo**:
```swift
if let advancedInfo = transaction.advancedCommerceInfo {
    // Only present for Advanced Commerce API purchases
    // nil for standard IAP
}
```

#### From WWDC 2025-241:4:42

### Essential Properties

**Basic Fields**:
```swift
let transaction: Transaction

transaction.id // Unique transaction ID
transaction.originalID // Original transaction ID (consistent across renewals)
transaction.productID // "com.app.pro_monthly"
transaction.productType // .autoRenewable
transaction.purchaseDate // Date of purchase
transaction.appAccountToken // UUID set at purchase time (if provided)
```

**Subscription Fields**:
```swift
transaction.expirationDate // When subscription expires
transaction.isUpgraded // true if user upgraded to higher tier
transaction.revocationDate // Date of refund (nil if not refunded)
transaction.revocationReason // .developerIssue, .other, or .upgradedToBundle (27 SDK)
```

**Offer Fields**:
```swift
if let offer = transaction.offer {
    offer.type // .introductory, .promotional, .code, .winBack (iOS 18+)
    offer.id // Offer identifier from App Store Connect
    offer.paymentMode // .freeTrial, .payAsYouGo, .payUpFront, .oneTime
}
```

#### From WWDC 2025-241:8:00

Server-signed payloads can additionally carry `offerType: 5` (retention offer, WWDC 2026) — no client `OfferType` case exists for it as of the 27.0 SDK (`.winBack` = 4 is still the last); see Retention Messaging API below.

### Current Entitlements

**Get All Current Entitlements**:
```swift
var purchasedProductIDs: Set<String> = []

for await result in Transaction.currentEntitlements {
    guard let transaction = try? result.payloadValue else {
        continue
    }

    purchasedProductIDs.insert(transaction.productID)
}
```

#### From WWDC 2025-241

**Get Entitlements for Specific Product (iOS 18.4+)**:
```swift
let productID = "com.app.premium"

for await result in Transaction.currentEntitlements(for: productID) {
    if let transaction = try? result.payloadValue,
       transaction.revocationDate == nil {
        // User owns this product
        return true
    }
}
```

#### From WWDC 2025-241:3:31

**Deprecated API (iOS 18.4)**:
```swift
// ❌ Deprecated in iOS 18.4
let entitlement = await Transaction.currentEntitlement(for: productID)

// ✅ Use this instead (returns sequence, handles Family Sharing)
for await result in Transaction.currentEntitlements(for: productID) {
    // ...
}
```

#### From WWDC 2025-241:3:31

### Transaction History

**Get All Transactions**:
```swift
for await result in Transaction.all {
    guard let transaction = try? result.payloadValue else {
        continue
    }

    print("Transaction: \(transaction.productID) on \(transaction.purchaseDate)")
}
```

**Get Transactions for Product (iOS 18.4+)**:
```swift
for await result in Transaction.all(for: productID) {
    guard let transaction = try? result.payloadValue else {
        continue
    }

    // All transactions for this product
}
```

### Transaction Listener

**Listen for Real-Time Updates (REQUIRED)**:
```swift
func listenForTransactions() -> Task<Void, Never> {
    Task.detached {
        for await verificationResult in Transaction.updates {
            await handleTransaction(verificationResult)
        }
    }
}

func handleTransaction(_ result: VerificationResult<Transaction>) async {
    guard let transaction = try? result.payloadValue else {
        return
    }

    // Grant or revoke entitlement
    if transaction.revocationDate != nil {
        await revokeEntitlement(for: transaction.productID)
    } else {
        await grantEntitlement(for: transaction)
    }

    // CRITICAL: Always finish transaction
    await transaction.finish()
}
```

#### From WWDC 2021-10114

**Transaction Sources**:
- In-app purchases completed on another device (same-device purchases arrive through `Product.PurchaseResult.success(_:)`, not `updates`)
- Purchases from App Store (promoted IAP)
- Offer code redemptions
- Subscription renewals
- Family Sharing transactions
- Pending purchases (Ask to Buy) that complete
- Refund notifications

### Verification

**VerificationResult**:
```swift
let result: VerificationResult<Transaction>

switch result {
case .verified(let transaction):
    // ✅ Transaction signed by App Store
    await grantEntitlement(for: transaction)
    await transaction.finish()

case .unverified(let transaction, let error):
    // ❌ Transaction signature invalid
    print("Unverified: \(error)")
    // DO NOT grant entitlement
    await transaction.finish() // Still finish to clear queue
}
```

**What Verification Checks**:
- Transaction signed by App Store (not fraudulent)
- Transaction belongs to this app (bundle ID match)
- Transaction belongs to this device

### Finishing Transactions

**Always Call finish()**:
```swift
await transaction.finish()
```

**When to finish**:
- ✅ After granting entitlement to user
- ✅ After storing transaction receipt/ID
- ✅ Even for unverified transactions (to clear queue)
- ✅ Even for refunded transactions

**What happens if you don't finish**:
- Transaction redelivered on next app launch
- `Transaction.updates` re-emits transaction
- Queue builds up over time

---

## AppTransaction

### Overview

`AppTransaction` represents the original app download. Available via `AppTransaction.shared`; OS27 adds `AppTransaction.all` and `storeType` — see the Advanced Commerce additions in the Overview.

### New Fields (iOS 18.4)

**appTransactionID**:
```swift
let appTransaction = try await AppTransaction.shared

switch appTransaction {
case .verified(let transaction):
    let appTransactionID = transaction.appTransactionID
    // Globally unique ID for this Apple Account + app
    // Same value appears in Transaction and Product.SubscriptionInfo.RenewalInfo

case .unverified(_, let error):
    print("AppTransaction verification failed: \(error)")
}
```

#### From WWDC 2025-241:1:42

**originalPlatform**:
```swift
if let appTransaction = try? await AppTransaction.shared.payloadValue {
    let platform = appTransaction.originalPlatform

    switch platform {
    case .iOS:
        print("Originally downloaded on iPhone/iPad")
    case .macOS:
        print("Originally downloaded on Mac")
    case .tvOS:
        print("Originally downloaded on Apple TV")
    case .visionOS:
        print("Originally downloaded on Vision Pro")
    default:
        break
    }
}
```

#### From WWDC 2025-241:2:11

**Note**: Apps downloaded on watchOS show `originalPlatform = .iOS`

### Essential Properties

```swift
let appTransaction: AppTransaction

appTransaction.appVersion // "1.2.3"
appTransaction.originalAppVersion // "1.0.0"
appTransaction.originalPurchaseDate // First download date
appTransaction.bundleID // "com.company.app"
appTransaction.deviceVerification // UUID for device
appTransaction.deviceVerificationNonce // Nonce for verification
```

### Use Cases

**Check App Version**:
```swift
if let appTransaction = try? await AppTransaction.shared.payloadValue {
    if appTransaction.appVersion != currentVersion {
        // Prompt user to update
    }
}
```

#### From WWDC 2025-241:0:51

**Business Model Migration**:
```swift
// Moving from paid app to free app with IAP
if appTransaction.originalPlatform == .iOS,
   appTransaction.originalPurchaseDate < migrationDate {
    // User paid for app before migration - grant premium
    await grantPremiumAccess()
}
```

#### From WWDC 2025-241:2:32

---

## Product.SubscriptionInfo.RenewalInfo

### Overview

`SubscriptionRenewalInfo` (the shipped alias for `Product.SubscriptionInfo.RenewalInfo`) provides information about auto-renewable subscription renewal state, including whether it will renew, expiration reason, and upcoming offers.

### New Fields (iOS 18.4)

**appTransactionID**:
```swift
let renewalInfo: Product.SubscriptionInfo.RenewalInfo
let appTransactionID = renewalInfo.appTransactionID
```

#### From WWDC 2025-241:6:40

**offer.period**:
```swift
if let offerPeriod = renewalInfo.offer?.period {
    print("Next renewal offer period: \(offerPeriod)")
    // Product.SubscriptionPeriod (unit + value); applies at the next renewal
}
```

#### From WWDC 2025-249:3:11

**appAccountToken**:
```swift
if let token = renewalInfo.appAccountToken {
    // UUID associating subscription with your server account
}
```

#### From WWDC 2025-241:6:56

**advancedCommerceInfo**:
```swift
if let advancedInfo = renewalInfo.advancedCommerceInfo {
    // Only for Advanced Commerce API subscriptions
}
```

#### From WWDC 2025-241:6:50

### Essential Properties

**Renewal State**:
```swift
let renewalInfo: Product.SubscriptionInfo.RenewalInfo

renewalInfo.willAutoRenew // true if subscription will renew
renewalInfo.autoRenewPreference // Product ID customer will renew to
renewalInfo.expirationReason // Why subscription expired (if expired)
```

**Expiration Reasons**:
```swift
switch renewalInfo.expirationReason {
case .autoRenewDisabled:
    // User turned off auto-renewal
    break
case .billingError:
    // Payment method issue
    break
case .didNotConsentToPriceIncrease:
    // User didn't accept price increase - show win-back offer!
    break
case .productUnavailable:
    // Product no longer available
    break
case .unknown:
    // Unknown reason
    break
// The 27 SDK also adds .unbundled — see the Advanced Commerce additions
default:
    break
}
```

#### From WWDC 2025-241:5:38

**Grace Period**:
```swift
if let gracePeriodExpiration = renewalInfo.gracePeriodExpirationDate {
    // Subscription in grace period - billing issue
    // Show update payment method UI
}
```

**Price Increase Consent**:
```swift
switch renewalInfo.priceIncreaseStatus {
case .noIncreasePending:
    // No price increase awaiting consent
    break
case .pending:
    // Price increase waiting on the customer - show consent UI
    break
case .agreed:
    // User accepted price increase
    break
}
```

### Accessing SubscriptionRenewalInfo

**From SubscriptionStatus**:
```swift
let statuses = try await Product.SubscriptionInfo.status(for: groupID)

for status in statuses {
    switch status.renewalInfo {
    case .verified(let renewalInfo):
        print("Will renew: \(renewalInfo.willAutoRenew)")
    case .unverified(_, let error):
        print("Renewal info verification failed: \(error)")
    }
}
```

---

## Product.SubscriptionInfo.Status

### Overview

`SubscriptionStatus` represents the current state of an auto-renewable subscription, including whether it's active, expired, in grace period, or in billing retry.

### Subscription States

**State Enum**:
```swift
let status: Product.SubscriptionInfo.Status

switch status.state {
case .subscribed:
    // User has active subscription - full access
    break

case .expired:
    // Subscription expired - show resubscribe/win-back offer
    break

case .inGracePeriod:
    // Billing issue but access maintained - show update payment UI
    break

case .inBillingRetryPeriod:
    // Apple retrying payment - maintain access
    break

case .revoked:
    // App Store revoked access to the subscription group (e.g. a refund or a Family Sharing revocation) - revoke access
    break

default:
    break
}
```

#### From WWDC 2025-241

### Getting Subscription Status

**For Subscription Group**:
```swift
let groupID = "pro_tier"

let statuses = try await Product.SubscriptionInfo.status(for: groupID)

// Find highest service level
let activeStatus = statuses
    .filter { $0.state == .subscribed }
    .compactMap { try? $0.transaction.payloadValue }
    .max { $0.productID < $1.productID }
```

#### From WWDC 2025-241:6:22

**For Specific Transaction (iOS 18.4+)**:
```swift
let transactionID = transaction.id

let status = try await Product.SubscriptionInfo.status(transactionID: transactionID)
```

#### From WWDC 2025-241:6:40

**Listen for Status Updates**:
```swift
for await (groupID, statuses) in Product.SubscriptionInfo.Status.all {
    // Process updated statuses for this group
    for status in statuses {
        print("Status: \(groupID): \(status.state)")
    }
}
```

### Status Properties

```swift
let status: Product.SubscriptionInfo.Status

status.state // .subscribed, .expired, etc.
status.transaction // VerificationResult<Transaction>
status.renewalInfo // VerificationResult<Product.SubscriptionInfo.RenewalInfo>
```

---

## Monthly Subscriptions with a 12-Month Commitment (from 26.4)

The 26.5 SDK introduced monthly subscriptions with a 12-month commitment: customers pay monthly for an annual subscription. Billing plans are added to new or existing one-year auto-renewable subscriptions in App Store Connect, with offers configurable per billing plan type (e.g. a free trial only on the commitment plan). Compile against the 26.5 SDK; customers can subscribe on devices running iOS / iPadOS / macOS / tvOS / visionOS 26.4. All the client API below is available from 26.4.

### PricingTerms

`Product.SubscriptionInfo.pricingTerms: [PricingTerms]` lists every available billing plan for a product. Every auto-renewable subscription carries at least one entry with the default `billingPlanType` of `.upFront`; a configured commitment plan adds a second entry with `.monthly` (which only applies to monthly subscriptions with a 12-month commitment).

`PricingTerms` members: `billingPrice: Decimal`, `billingDisplayPrice: String`, `billingPeriod` (a `SubscriptionPeriod` typealias), `billingPlanType`, `commitmentInfo` (non-optional: `price` / `displayPrice` / `period`), `subscriptionOffers: [SubscriptionOffer]`, and a `subscript(offers:)` filtered by offer type. The session notes billing-plan metadata is only returned when available in the customer's storefront — expect the commitment entry to be absent in storefronts where the plan isn't offered.

### Merchandising with StoreKit Views

```swift
SubscriptionStoreView(groupID: "pro_tier") {
    // Custom marketing content
}
.preferredSubscriptionPricingTerms { _, subscriptionInfo in
    subscriptionInfo.pricingTerms.first {
        $0.billingPlanType == .monthly
    }
}
```

### Custom UI and Purchase

```swift
// Merchandise the monthly billing plan
let product: Product // Already loaded via Product.products(for:)
let pricingTerms = product.subscription?.pricingTerms
    .first(where: { $0.billingPlanType == .monthly })
if let pricingTerms {
    let monthlyPrice = pricingTerms.billingDisplayPrice
    let totalCommitmentPrice = pricingTerms.commitmentInfo.price
    // Display both monthly and total commitment price to the customer
}

// Purchase with the billing plan purchase option
// (use confirmIn: — the bare purchase(options:) overload is unavailable on visionOS)
let scene: UIWindowScene // Current scene
let result = try await product.purchase(confirmIn: scene, options: [.billingPlanType(.monthly)])
// Verify, grant access, finish — as with any purchase
```

Before a customer subscribes to a commitment plan for the first time, the App Store automatically presents a one-time-per-Apple-Account disclosure sheet (number of payments required plus cancellation guidance). While the subscription is active, the system manage-subscriptions UI shows available plans, remaining payments, and when the commitment renews — present it with the existing `.manageSubscriptionsSheet(isPresented:subscriptionGroupID:)` SwiftUI modifier or UIKit `try await AppStore.showManageSubscriptions(in: scene)`.

### Transaction and SubscriptionRenewalInfo Fields

- `Transaction.billingPlanType: BillingPlanType?` — `.upFront` or `.monthly`
- `Transaction.commitmentInfo: CommitmentInfo?` — `nil` for `.upFront`; for `.monthly` carries `billingPeriodNumber`, `totalBillingPeriods`, `expirationDate`, `price`. Always use the latest transaction for an accurate `expirationDate`.
- `SubscriptionRenewalInfo.renewalBillingPlanType: BillingPlanType?` and `SubscriptionRenewalInfo.commitmentInfo` (`autoRenewPreference`, `renewalBillingPlanType`, `renewalDate`, `renewalPrice`, `willAutoRenew`) — describe the renewal after the current commitment ends. Both are optional; Apple documents the matching *server* fields as present only while the subscription is in a commitment, so expect `nil` outside one.

### Server-Side JWS Fields

Decoded `JWSTransaction` adds `billingPlanType` (`"MONTHLY"`) and a `commitmentInfo` object (`billingPeriodNumber`, `totalBillingPeriods`, `commitmentExpiresDate`, `commitmentPrice`). Decoded `JWSRenewalInfo` adds `renewalBillingPlanType` and a `commitmentInfo` object (`commitmentAutoRenewProductId`, `commitmentAutoRenewStatus`, `commitmentRenewalDate`, `commitmentRenewalPrice`, `commitmentRenewalBillingPlanType`, e.g. `"BILLED_UPFRONT"` — both server enums use the same two raw values (`"BILLED_UPFRONT"` and `"MONTHLY"`); the example values above come from the session) — present only while in a commitment. App Store Server Notifications V2 continues to deliver lifecycle updates (such as monthly renewals) throughout the commitment.

### Testing Billing Plans

StoreKit Testing in Xcode 26.5 adds a Billing Plan picker to the StoreKit configuration file: select a one-year auto-renewable subscription, choose "Monthly with a 12-month commitment", configure per-plan pricing and offers, then verify `commitmentInfo` in the Transaction inspector.

---

## StoreKit Views

### ProductView (iOS 17+)

**Basic Usage**:
```swift
import StoreKit

struct ContentView: View {
    let productID = "com.app.premium"

    var body: some View {
        ProductView(id: productID)
    }
}
```

#### From WWDC 2023-10013

**With Loaded Product**:
```swift
struct ContentView: View {
    let product: Product

    var body: some View {
        ProductView(product)
    }
}
```

**Custom Icon**:
```swift
ProductView(id: productID) {
    Image(systemName: "star.fill")
        .foregroundStyle(.yellow)
}
```

**Control Styles**:
```swift
ProductView(id: productID)
    .productViewStyle(.regular)  // Default

ProductView(id: productID)
    .productViewStyle(.compact)  // Smaller

ProductView(id: productID)
    .productViewStyle(.large)  // Prominent
```

### StoreView (iOS 17+)

**Basic Store**:
```swift
struct ContentView: View {
    let productIDs = [
        "com.app.coins_100",
        "com.app.coins_500",
        "com.app.coins_1000"
    ]

    var body: some View {
        StoreView(ids: productIDs)
    }
}
```

#### From WWDC 2023-10013

**With Loaded Products**:
```swift
struct ContentView: View {
    let products: [Product]

    var body: some View {
        StoreView(products: products)
    }
}
```

### SubscriptionStoreView (iOS 17+)

**Basic Subscription Store**:
```swift
struct SubscriptionView: View {
    let groupID = "pro_tier"

    var body: some View {
        SubscriptionStoreView(groupID: groupID) {
            // Marketing content above subscription options
            VStack {
                Image("app-icon")
                Text("Go Pro")
                    .font(.largeTitle.bold())
                Text("Unlock all features")
            }
        }
    }
}
```

#### From WWDC 2023-10013

**Control Style**:
```swift
SubscriptionStoreView(groupID: groupID) {
    // Marketing content
}
.subscriptionStoreControlStyle(.automatic)    // Default
.subscriptionStoreControlStyle(.picker)       // Horizontal picker
.subscriptionStoreControlStyle(.buttons)      // Stacked buttons
.subscriptionStoreControlStyle(.prominentPicker) // Large picker (iOS 17+)
```

#### From WWDC 2025-241

### SubscriptionOfferView (iOS 26.0+)

Available on iOS and visionOS 26.0+; unavailable on macOS, macCatalyst, tvOS and watchOS.

**Basic Offer View**:
```swift
struct ContentView: View {
    let productID = "com.app.pro_monthly"

    var body: some View {
        SubscriptionOfferView(id: productID)
    }
}
```

#### From WWDC 2025-241:14:27

**With Loaded Product**:
```swift
let product: Product // Already loaded via Product.products(for:)

SubscriptionOfferView(product)
```

**With Promotional Icon**:
```swift
SubscriptionOfferView(
    id: productID,
    prefersPromotionalIcon: true
)
```

**With Custom Icon**:
```swift
SubscriptionOfferView(id: productID) {
    Image("custom-icon")
        .resizable()
        .frame(width: 60, height: 60)
} placeholderIcon: {
    Image(systemName: "photo")
        .foregroundStyle(.gray)
}
```

#### From WWDC 2025-241:15:14

**With Detail Action**:
```swift
@State private var showStore = false

var body: some View {
    SubscriptionOfferView(id: productID)
        .subscriptionOfferViewDetailAction {
            showStore = true
        }
        .sheet(isPresented: $showStore) {
            SubscriptionStoreView(groupID: "pro_tier")
        }
}
```

#### From WWDC 2025-241:15:38

**Visible Relationship**:
```swift
// Only show if customer can upgrade
SubscriptionOfferView(
    groupID: "pro_tier",
    visibleRelationship: .upgrade
)

// Only show if customer can downgrade
SubscriptionOfferView(
    groupID: "pro_tier",
    visibleRelationship: .downgrade
)

// Show crossgrade options (same tier, different billing period)
SubscriptionOfferView(
    groupID: "pro_tier",
    visibleRelationship: .crossgrade
)

// Show current subscription (only if offer available)
SubscriptionOfferView(
    groupID: "pro_tier",
    visibleRelationship: .current
)

// Show any plan in group
SubscriptionOfferView(
    groupID: "pro_tier",
    visibleRelationship: .all
)
```

#### From WWDC 2025-241:17:44

**With App Icon**:
```swift
SubscriptionOfferView(
    groupID: groupID,
    visibleRelationship: .all,
    useAppIcon: true
)
```

#### From WWDC 2025-241:19:06

### Offer Modifiers

**Promotional Offer (JWS)**:
```swift
SubscriptionStoreView(groupID: groupID)
    .subscriptionPromotionalOffer(
        offer: { _, subscriptionInfo in
            // Return the offer to apply for this subscription
            return subscriptionInfo.promotionalOffers.first
        },
        compactJWS: { product, _, offer in
            // Get the compact-JWS signature from your server
            let signature = try await server.signOffer(
                productID: product.id,
                offerID: offer.id ?? ""
            )
            return signature
        }
    )
```

#### From WWDC 2025-241:12:17

### subscriptionStatusTask Modifier (iOS 17.0+)

Track subscription status at the app level with a SwiftUI modifier. Eliminates manual polling by reacting to status changes automatically.

**Basic Usage**:
```swift
@main
struct MyApp: App {
    @State private var customerStatus: CustomerStatus = .unknown

    var body: some Scene {
        WindowGroup {
            ContentView()
                .subscriptionStatusTask(for: "your.group.id") { statuses in
                    if statuses.value?.contains(where: { $0.state == .subscribed }) == true {
                        customerStatus = .subscribed
                    } else if statuses.value?.contains(where: { $0.state == .expired }) == true {
                        customerStatus = .expired
                    } else {
                        customerStatus = .notSubscribed
                    }
                }
        }
    }
}
```

**Key behavior**:
- Fires on app launch with current statuses
- Fires again when subscription status changes (renewal, expiration, upgrade)
- Translate StoreKit statuses to your app's model — keep your domain model simple
- Attach at the top of your view hierarchy (App or root WindowGroup)

---

## Offer Codes (iOS 18.2+)

### Overview

Offer codes now support all product types (previously subscription-only):
- Consumables
- Non-consumables
- Non-renewing subscriptions
- Auto-renewable subscriptions

### Redeem in App

**UIKit**:
```swift
@MainActor
func showOfferCodeSheet() async throws {
    guard let scene = view.window?.windowScene else { return }

    try await StoreKit.AppStore.presentOfferCodeRedeemSheet(in: scene)
}
```

#### From WWDC 2025-241:7:38

**SwiftUI**:
```swift
.offerCodeRedemption(isPresented: $showRedeemSheet)
```

### Redemption Rework OS27

The redemption APIs now return the redeemed transaction and accept a set of `RedeemOption` values configuring the redemption. On success you receive the transaction in the `verificationResult`; on failure, an error describing why. The pre-27 variants above are deprecated in 27 in favor of these. Testable in Xcode 27 on all applicable product types (consumable, non-consumable, auto-renewable, non-renewing).

**SwiftUI** (iOS / macOS / macCatalyst / visionOS 27):
```swift
@State private var showRedeemSheet = false

// ...
.offerCodeRedemption(options: [], isPresented: $showRedeemSheet) { result in
    switch result {
    case .success(let verificationResult):
        // VerificationResult<Transaction> — verify, grant access, finish
        break
    case .failure(let error):
        // Handle error
        break
    }
}
```

**UIKit / AppKit** (`async throws -> VerificationResult<Transaction>`):
```swift
let viewController: UIViewController // Presenting view controller
let window: NSWindow                 // Presenting window (macOS)

// iOS / macCatalyst / visionOS 27 — replaces presentOfferCodeRedeemSheet(in: scene)
let result = try await AppStore.presentOfferCodeRedeemSheet(
    from: viewController, options: []
)

// macOS 27 — replaces presentOfferCodeRedeemSheet(from: NSViewController)
let result = try await AppStore.presentOfferCodeRedeemSheet(
    from: window, options: []
)
```

`RedeemOption` is `Equatable` / `Hashable` / `Sendable`, but **no public option values ship as of the Xcode 27.0 SDK** — pass `[]` (the UIKit/AppKit variants default it) and re-check 27.x SDKs for concrete options. Not available on tvOS or watchOS.

### Payment Mode

**New: .oneTime**:
```swift
let transaction: Transaction

if let offer = transaction.offer {
    switch offer.paymentMode {
    case .freeTrial:
        // No charge during offer period
        break
    case .payAsYouGo:
        // Discounted price per billing period
        break
    case .payUpFront:
        // One-time discounted price for entire duration
        break
    case .oneTime:
        // ✨ New: One-time offer code redemption (iOS 17.2+)
        break
    default:
        break
    }
}
```

#### From WWDC 2025-241:8:17

---

## App Store Server Library

### Overview

Open-source library for signing IAP requests and decoding server API responses. Available in Swift, Java, Python, Node.js.

### Create Promotional Offer Signature

**Swift Example**:
```swift
import AppStoreServerLibrary

// Configure signing
let signingKey = "YOUR_PRIVATE_KEY"
let keyID = "YOUR_KEY_ID"
let issuerID = "YOUR_ISSUER_ID"
let bundleID = "com.app.bundle"

let creator = try PromotionalOfferV2SignatureCreator(
    signingKey: signingKey,
    keyId: keyID,
    issuerId: issuerID,
    bundleId: bundleID
)

// Create signature
let productID = "com.app.pro_monthly"
let offerID = "promo_winback"
let transactionID = String(transaction.id) // Optional but recommended

let signature = try await creator.createSignature(
    productId: productID,
    offerIdentifier: offerID,
    transactionId: transactionID
)

// Send signature to app
return signature // Compact JWS string
```

#### From WWDC 2025-241:12:44, 2025-249

**Server Endpoint Example**:
```swift
app.get("promo-offer") { req async throws -> String in
    let productID = try req.query.get(String.self, at: "productID")
    let offerID = try req.query.get(String.self, at: "offerID")

    let signature = try await creator.createSignature(
        productId: productID,
        offerIdentifier: offerID
    )

    return signature
}
```

#### From WWDC 2025-241:12:52

---

## App Store Server API

### Set App Account Token

**Endpoint**:
```
PUT /inApps/v1/transactions/{originalTransactionId}/appAccountToken
```

**Request Body**:
```json
{
  "appAccountToken": "550e8400-e29b-41d4-a716-446655440000"
}
```

**Usage**:
- Set appAccountToken for purchases made outside your app (offer codes, App Store)
- Update appAccountToken when account ownership changes
- Associates transaction with customer account on your server

#### From WWDC 2025-249:5:19

### Get App Transaction Info

**Endpoint**:
```
GET /inApps/v1/transactions/appTransactions/{transactionId}
```

The path accepts any `transactionId`, `originalTransactionId` or `appTransactionId`.

**Response**:
```json
{
  "signedAppTransactionInfo": "eyJhbGc..."
}
```

**Usage**:
- Get app download information on server
- Check app version, platform, environment

#### From WWDC 2025-249:10:48

### Send Consumption Information V2

**Endpoint**:
```
PUT /inApps/v2/transactions/consumption/{transactionId}
```

**Request Body**:
```json
{
  "customerConsented": true,
  "sampleContentProvided": false,
  "deliveryStatus": "DELIVERED",
  "refundPreference": "GRANT_PRORATED",
  "consumptionPercentage": 25000
}
```

**Fields**:
- `customerConsented` (required): User consented to send consumption data
- `sampleContentProvided` (optional): Sample provided before purchase
- `deliveryStatus` (required): "DELIVERED" or various UNDELIVERED statuses
- `refundPreference` (optional): "DECLINE", "GRANT_FULL", "GRANT_PRORATED"
- `consumptionPercentage` (optional): 0-100000 (millipercent, e.g., 25000 = 25%)

**Prorated Refund**:
- New in 2025
- Supports partial consumption (consumables, non-consumables, non-renewing)
- For auto-renewable subscriptions, App Store calculates based on time remaining

#### From WWDC 2025-249:16:09

### Refund Notifications

**REFUND Notification**:
```json
{
  "notificationType": "REFUND",
  "data": {
    "signedTransactionInfo": "..."
  }
}
```

The revocation fields are not siblings of `signedTransactionInfo` — they live inside the decoded transaction payload:

```json
{
  "revocationType": "REFUND_PRORATED",
  "revocationPercentage": 75000
}
```

**revocationType Values**:
- `REFUND_FULL`: 100% refund - revoke all access
- `REFUND_PRORATED`: Partial refund - revoke proportional access
- `FAMILY_REVOKE`: Family Sharing removed - revoke access

`revocationPercentage` is the refunded/revoked share in milliunits (`75000` = 75%).

Seat revocations from group/volume purchasing surface as `ASSIGNMENT_REVOKE` — see Group and Volume Subscription Purchasing.

#### From WWDC 2025-249:20:17

### Retention Messaging API (WWDC 2026)

Retention messages appear in the subscription cancellation flow. The ASC-configuration side (views, message/image rules, retention offers, save-rate guidance) lives in `axiom-shipping (skills/app-store-ref.md)` Part 11; this is the server surface.

**Retention offers in signed payloads** — redeeming a retention offer surfaces as a new `offerType` value of `5` in the signed transaction and renewal info, with the usual offer fields (`offerIdentifier`, `offerDiscountType`, `offerPeriod`) populated as expected. There is no corresponding `Transaction.OfferType` case as of the Xcode 27.0 SDK (`.winBack`, raw value 4, is the last named case) — match the raw value server-side.

**Real-time Retention Messaging** — your server answers a server-to-server HTTP request from the App Store at cancellation time. Requires passing a sandbox performance test before production, and access is granted via an interest form. The Retention Messaging API lives at `https://api.storekit.apple.com/inApps/v1/messaging`:

```
// URL configuration
PUT/GET/DELETE /realtime/url

// Message configuration
PUT/DELETE /message/{messageIdentifier}
GET /message/list
PUT/DELETE/GET /default/{productId}/{locale}

// Image configuration
PUT/DELETE /image/{imageIdentifier}
GET /image/list

// Performance testing — sandbox only
POST /performanceTest
GET /performanceTest/result/{requestId}
```

The App Store's real-time request carries `originalTransactionId`, `appAppleId`, `productId`, `userLocale`, `requestIdentifier`, `environment`, and `signedDate`. You respond in one of three formats:

```json
{ "message": { "messageIdentifier": "..." } }

{ "alternateProduct": { "messageIdentifier": "...", "productId": "..." } }

{ "promotionalOffer": { "messageIdentifier": "...", "promotionalOfferSignatureV2": "eyJhbGciOiJFUzI..." } }
```

- The `alternateProduct` (switch plan) response also accepts a `billingPlanType` field to offer a monthly-with-12-month-commitment plan as the switch target.
- A signature is still required for promotional offers used in retention messages (`promotionalOfferSignatureV2` — the compact-JWS V2 signature; see App Store Server Library above).
- If your server doesn't respond in time or the response is malformed, the App Store falls back to your ASC Retention Messaging preference (including eligible offers), then to default messaging configured with this API. Apple recommends configuring ASC Retention Messaging even when using the real-time variant.

---

## Edge Cases

### Family Sharing

**Detect Family Shared Transactions**:
```swift
// appAccountToken is NOT available for family shared transactions
let transaction: Transaction

if transaction.appAccountToken == nil {
    // Might be family shared (or appAccountToken not set)
    // Check ownershipType (if available)
}
```

**Subscription Status for Family Sharing**:
```swift
// Each family member has unique appTransactionID
// Use appTransactionID to identify individual family members
```

#### From WWDC 2025-241:1:54

### Refunds

**Handle Refund**:
```swift
func handleTransaction(_ transaction: Transaction) async {
    if let revocationDate = transaction.revocationDate {
        // Transaction was refunded
        print("Refunded on \(revocationDate)")

        switch transaction.revocationReason {
        case .developerIssue:
            // Refund due to app issue
            break
        case .other:
            // Other refund reason
            break
        default:
            break
        }

        // Revoke entitlement
        await revokeEntitlement(for: transaction.productID)
    }
}
```

### Advanced Commerce API

The Advanced Commerce API enables support for:
- In-app purchases for large content catalogs
- Creator experiences (tipping, patronage)
- Subscriptions with optional add-ons

**Check if Transaction Uses Advanced Commerce**:
```swift
if transaction.advancedCommerceInfo != nil {
    // Transaction from Advanced Commerce API
    // Large catalogs, creator experiences, subscriptions with add-ons
}
```

Accessible through the `advancedCommerceInfo` field on both `Transaction` and `SubscriptionRenewalInfo`. Returns `nil` for standard IAP transactions.

#### From WWDC 2025-241:4:51

### Win-Back Offers

**Show Win-Back for Expired Subscription**:
```swift
let renewalInfo: Product.SubscriptionInfo.RenewalInfo

if renewalInfo.expirationReason == .didNotConsentToPriceIncrease {
    // Perfect time for win-back offer!
    SubscriptionOfferView(
        groupID: groupID,
        visibleRelationship: .current
    )
    .preferredSubscriptionOffer { _, _, eligibleOffers in
        // Win-back offer for this subscription, if the customer is eligible
        eligibleOffers.first
    }
}
```

#### From WWDC 2025-241:5:38

---

## Testing

### StoreKit Configuration File

**Create**:
1. Xcode → File → New → StoreKit Configuration File
2. Add products (consumables, non-consumables, subscriptions)
3. Configure prices, images, descriptions

**Enable in Scheme**:
1. Scheme → Edit Scheme → Run → Options
2. StoreKit Configuration: Select .storekit file

**Test Scenarios**:
- Successful purchases
- Cancelled purchases
- Subscription renewals (accelerated time)
- Subscription expirations
- Upgrades/downgrades
- Offer code redemptions
- Family Sharing (enable in config file)

### Transaction Manager

Use the Transaction Manager window in Xcode to inspect and manipulate transactions during testing:

- Create transactions manually (test specific purchase flows)
- Modify transaction properties (expiration, renewal state)
- Test subscription offer scenarios
- Inspect transaction details and verification status

**Open**: Debug → StoreKit → Manage Transactions (while running with StoreKit configuration)

### Sandbox Testing

**Create Sandbox Account**:
1. App Store Connect → Users and Access → Sandbox Testers
2. Create test Apple ID
3. Sign in on device Settings → App Store → Sandbox Account

**Clear Purchase History**:
- Settings → App Store → Sandbox Account → Clear Purchase History

---

## Migration from StoreKit 1

### Key Changes

**Delegates → Async/Await**:
```swift
// StoreKit 1
class StoreObserver: NSObject, SKPaymentTransactionObserver {
    func paymentQueue(_ queue: SKPaymentQueue, updatedTransactions transactions: [SKPaymentTransaction]) {
        // Handle transactions
    }
}

// StoreKit 2
for await result in Transaction.updates {
    // Handle transactions
}
```

**Receipt → Transaction**:
```swift
// StoreKit 1
let receiptURL = Bundle.main.appStoreReceiptURL
let receipt = try Data(contentsOf: receiptURL!)

// StoreKit 2
let transaction: Transaction // Automatically verified!
```

**Products → Product.products(for:)**:
```swift
// StoreKit 1
let request = SKProductsRequest(productIdentifiers: Set(productIDs))
request.delegate = self
request.start()

// StoreKit 2
let products = try await Product.products(for: productIDs)
```

---

## Resources

**WWDC**: 2026-210, 2026-309, 2026-391, 2025-241, 2025-249, 2024-10061, 2024-10062, 2024-10110, 2023-10013, 2023-10140, 2022-10007, 2022-110404, 2021-10114

**Docs**: /storekit, /storekit/product/subscriptioninfo/bundledsubscriptions, /storekit/product/subscriptioninfo/pricingterms, /storekit/apptransaction/all, /storekit/apptransaction/storetype

**Skills**: skills/in-app-purchases.md, axiom-shipping (skills/app-store-ref.md)

---

## Quick Reference

### Product Types
- `.consumable` - Can purchase multiple times (coins, boosts)
- `.nonConsumable` - Purchase once, own forever (premium, level packs)
- `.autoRenewable` - Auto-renewing subscriptions
- `.nonRenewable` - Fixed duration subscriptions

### Transaction States
- `success` - Purchase completed
- `userCancelled` - User tapped cancel
- `pending` - Requires action (Ask to Buy)

### Subscription States
- `.subscribed` - Active subscription
- `.expired` - Subscription ended
- `.inGracePeriod` - Billing issue, access maintained
- `.inBillingRetryPeriod` - Apple retrying payment
- `.revoked` - App Store revoked access to the subscription group

### Essential Calls
```swift
// Load products
try await Product.products(for: productIDs)

// Purchase
try await product.purchase(confirmIn: scene)

// Current entitlements (iOS 18.4+)
Transaction.currentEntitlements(for: productID)

// Transaction listener
Transaction.updates

// Subscription status
try await Product.SubscriptionInfo.status(for: groupID)

// Restore purchases
try await AppStore.sync()

// Finish transaction (REQUIRED)
await transaction.finish()
```
